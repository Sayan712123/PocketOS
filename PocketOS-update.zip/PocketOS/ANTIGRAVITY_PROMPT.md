# Google Antigravity prompt — POCO M4 5G: remove default apps, use PocketOS

Before starting: enable Developer options, USB debugging and "USB debugging (Security settings)", connect USB, accept the RSA prompt.
Copy everything in the box below into Antigravity (agent mode, terminal enabled).

```
You are my careful Android assistant. Goal: on my POCO M4 5G (Xiaomi, MIUI/HyperOS, no root)
replace some default apps with my own app PocketOS (package com.pocketos), using only adb.

HARD RULES
- No root, no bootloader/flash, no factory reset, no `pm clear`, no data wipe.
- Remove only with: adb shell pm uninstall -k --user 0 <package>
  (reversible: adb shell cmd package install-existing <package>).
- Before ANY removal show the exact command list and wait for my "yes".
- Never touch: com.android.systemui, com.android.settings, com.android.phone,
  com.android.server.telecom, com.android.providers.*, com.google.android.gms, com.android.vending,
  com.miui.securitycenter, com.miui.home (until PocketOS Launcher is default AND I confirm),
  keyboard/IME, WebView, camera and gallery system apps (PocketOS versions are basic).
- If a command fails: stop, show the error, do not try workarounds.

STEPS
1. `adb devices`; print model + Android version.
2. `adb install -r <PocketOS apk>`.
3. Backup: `adb shell pm list packages -s --user 0 > backup_system_packages.txt`
4. Find the real package names on THIS phone (they differ per MIUI/HyperOS version) and report them:
   calculator (com.miui.calculator | com.android.calculator2), notes (com.miui.notes),
   recorder (com.android.soundrecorder), compass (com.miui.compass), weather (com.miui.weather2),
   music (com.miui.player), file manager (com.mi.android.globalFileexplorer | com.android.fileexplorer),
   clock (com.android.deskclock), calendar (com.android.calendar | com.xiaomi.calendar),
   browser (com.android.browser | com.mi.globalbrowser).
5. TIER A (PocketOS replacement is complete): calculator, notes, compass, recorder, weather, music.
   Propose commands, wait for "yes", run, then ask me to open each PocketOS app to verify.
6. TIER B (use `pm disable-user --user 0 <pkg>` first, only after I confirm the PocketOS app works):
   file manager, calendar, browser, clock (first confirm a PocketOS alarm actually rings).
7. TIER C (do NOT remove): dialer/contacts (com.android.contacts), SMS (com.android.mms) until I make
   PocketOS the default SMS app and confirm receiving works, camera, gallery.
8. Try to set defaults (if it fails tell me which Settings screen to use):
   `adb shell cmd role add-role-holder --user 0 android.app.role.HOME com.pocketos`
   `adb shell cmd role add-role-holder --user 0 android.app.role.SMS com.pocketos`
9. Write rollback.sh with one `adb shell cmd package install-existing <pkg>` per removed package.

Reply in Bengali. Keep messages short. Ask before every destructive step.
```
