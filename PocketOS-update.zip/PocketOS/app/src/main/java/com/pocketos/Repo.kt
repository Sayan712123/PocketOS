package com.pocketos

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone

class Contact(val id: Long, val name: String, val numbers: List<String>, val starred: Boolean)

object Repo {
    private val nameCache = HashMap<String, String>()

    fun contacts(c: Context): List<Contact> {
        val map = LinkedHashMap<Long, Triple<String, ArrayList<String>, Boolean>>()
        try {
            c.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER, ContactsContract.Contacts.STARRED),
                null, null, Phone.DISPLAY_NAME + " COLLATE NOCASE ASC")?.use { q ->
                while (q.moveToNext()) {
                    val id = q.getLong(0)
                    val e = map.getOrPut(id) { Triple(q.getString(1) ?: "", ArrayList<String>(), q.getInt(3) == 1) }
                    val n = q.getString(2) ?: ""
                    if (n.isNotEmpty() && !e.second.contains(n)) e.second.add(n)
                }
            }
        } catch (e: Exception) { }
        return map.map { Contact(it.key, it.value.first, it.value.second, it.value.third) }
    }

    fun nameFor(c: Context, number: String): String? {
        if (number.isEmpty()) return null
        nameCache[number]?.let { return it.ifEmpty { null } }
        var r = ""
        try {
            val u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            c.contentResolver.query(u, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) r = it.getString(0) ?: "" }
        } catch (e: Exception) { }
        nameCache[number] = r
        return r.ifEmpty { null }
    }
}
