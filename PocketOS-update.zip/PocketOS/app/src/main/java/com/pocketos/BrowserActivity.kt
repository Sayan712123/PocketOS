package com.pocketos

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import java.net.URLEncoder

class BrowserActivity : Base() {
    private class Tab(val web: WebView, var title: String = "New Tab", var url: String = "")
    private val tabs = ArrayList<Tab>()
    private var cur = 0
    private lateinit var prefs: Prefs
    private lateinit var content: FrameLayout
    private lateinit var addr: EditText
    private lateinit var progress: ProgressBar
    private var desktop = false
    private var switcher = false
    private lateinit var start: View

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        prep()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(T.bg)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        root.addView(progress, lp(MATCH, dp(3)))
        content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, 1f))
        start = startPage()
        // bottom bar
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setBackgroundColor(T.card)
        bar.setPadding(dp(10), dp(6), dp(10), dp(6))
        addr = EditText(this)
        addr.hint = "Search or enter website"
        addr.setSingleLine()
        addr.gravity = Gravity.CENTER
        addr.textSize = 16f
        addr.setTextColor(T.label); addr.setHintTextColor(T.sub)
        addr.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        addr.imeOptions = EditorInfo.IME_ACTION_GO
        addr.background = shape(T.fill, dpf(12f))
        addr.setOnEditorActionListener { v, a, e -> if (a == EditorInfo.IME_ACTION_GO || (e != null && e.keyCode == KeyEvent.KEYCODE_ENTER)) { go(v.text.toString()); true } else false }
        addr.setOnFocusChangeListener { _, f -> if (f) addr.selectAll() }
        bar.addView(addr, lp(MATCH, dp(40)))
        val btns = LinearLayout(this)
        btns.gravity = Gravity.CENTER
        btns.addView(glyphBtn("back") { val t = tab(); if (t != null && t.web.canGoBack()) t.web.goBack() else if (t != null) showStart() }, lp(0, WRAP, 1f))
        btns.addView(glyphBtn("fwd") { tab()?.web?.let { if (it.canGoForward()) it.goForward() } }, lp(0, WRAP, 1f))
        btns.addView(glyphBtn("share") { tab()?.let { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, it.url), "Share")) } }, lp(0, WRAP, 1f))
        btns.addView(glyphBtn("bookmark") { bookmarks() }, lp(0, WRAP, 1f))
        btns.addView(glyphBtn("tabs") { switcher = true; showSwitcher() }, lp(0, WRAP, 1f))
        btns.addView(glyphBtn("more") { menu() }, lp(0, WRAP, 1f))
        bar.addView(btns)
        root.addView(bar)
        setContentView(root)
        val u = intent?.dataString
        newTab(u)
    }

    private fun tab(): Tab? = tabs.getOrNull(cur)

    private fun newTab(url: String?) {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true; w.settings.builtInZoomControls = true; w.settings.displayZoomControls = false
        w.settings.setSupportZoom(true)
        val t = Tab(w)
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme
                if (s == "http" || s == "https") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                return true
            }
            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) { t.url = u; if (tab() === t) addr.setText(host(u)) }
            override fun onPageFinished(v: WebView, u: String) {
                t.url = u; t.title = v.title ?: host(u)
                val h = prefs.s("history").split("\n").filter { it.isNotEmpty() }.toMutableList(); h.add(0, t.title + "|" + u); prefs.put("history", h.distinct().take(100).joinToString("\n"))
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { if (tab() === t) { progress.progress = p; progress.visibility = if (p >= 100) View.INVISIBLE else View.VISIBLE } }
        }
        w.setDownloadListener { u, ua, cd, mime, _ ->
            try {
                val rq = DownloadManager.Request(Uri.parse(u)); rq.setMimeType(mime); rq.addRequestHeader("User-Agent", ua)
                rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                rq.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(u, cd, mime))
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(rq); toast("Downloading…")
            } catch (e: Exception) { toast("Download failed") }
        }
        tabs.add(t); cur = tabs.size - 1
        if (url.isNullOrEmpty()) showStart() else { show(t); w.loadUrl(url) }
    }

    private fun host(u: String) = Uri.parse(u).host?.removePrefix("www.") ?: u

    private fun show(t: Tab) { content.removeAllViews(); content.addView(t.web, FrameLayout.LayoutParams(MATCH, MATCH)); addr.setText(if (t.url.isEmpty()) "" else host(t.url)); switcher = false }

    private fun showStart() { content.removeAllViews(); content.addView(start, FrameLayout.LayoutParams(MATCH, MATCH)); addr.setText(""); tab()?.url = "" }

    private fun go(q: String) {
        val s = q.trim()
        if (s.isEmpty()) return
        val url = if (s.startsWith("http://") || s.startsWith("https://")) s
            else if (!s.contains(" ") && s.contains(".")) "https://$s"
            else "https://www.google.com/search?q=" + URLEncoder.encode(s, "UTF-8")
        val t = tab() ?: return
        show(t); t.web.loadUrl(url)
        addr.clearFocus()
    }

    private fun startPage(): View = page {
        addView(largeTitle("Favorites"))
        val favs = listOf("Google" to "https://www.google.com", "YouTube" to "https://www.youtube.com", "Wikipedia" to "https://www.wikipedia.org", "GitHub" to "https://github.com",
            "Reddit" to "https://www.reddit.com", "News" to "https://news.google.com", "Maps" to "https://maps.google.com", "Weather" to "https://weather.com")
        for (row in favs.chunked(4)) {
            val r = LinearLayout(this@BrowserActivity)
            for ((n, u) in row) {
                val c = LinearLayout(this@BrowserActivity); c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.CENTER
                val ic = txt(n.take(1), 24f, Color.WHITE, true); ic.gravity = Gravity.CENTER
                ic.background = shape(listOf(0xFF0A84FF, 0xFFFF3B30, 0xFF8E8E93, 0xFF1C1C1E, 0xFFFF9500, 0xFF34C759, 0xFF30B0C7, 0xFF5E5CE6)[favs.indexOfFirst { it.first == n }].toInt(), dpf(14f))
                c.addView(ic, lp(dp(60), dp(60)))
                c.addView(txt(n, 12f, T.label), lp(WRAP, WRAP, 0f, 0, dp(4), 0, 0))
                c.onTap { go(u) }
                r.addView(c, lp(0, WRAP, 1f, 0, 0, 0, dp(16)))
            }
            repeat(4 - row.size) { r.addView(View(this@BrowserActivity), lp(0, 1, 1f)) }
            addView(r)
        }
    }

    private fun showSwitcher() {
        content.removeAllViews()
        content.addView(page {
            addView(navRow(btn("Close All") { tabs.forEach { it.web.destroy() }; tabs.clear(); newTab(null) }, btn("Done", T.blue, true) { cur = cur.coerceIn(0, tabs.size - 1); tabs[cur].let { if (it.url.isEmpty()) showStart() else show(it) } }))
            addView(largeTitle("${tabs.size} Tabs"))
            for (row in (tabs.indices).toList().chunked(2)) {
                val r = LinearLayout(this@BrowserActivity)
                for (i in row) {
                    val t = tabs[i]
                    val c = LinearLayout(this@BrowserActivity); c.orientation = LinearLayout.VERTICAL; c.setPadding(dp(12), dp(12), dp(12), dp(12)); c.background = shape(T.card, dpf(14f))
                    val top = LinearLayout(this@BrowserActivity); top.gravity = Gravity.CENTER_VERTICAL
                    top.addView(txt(t.title, 14f, T.label, true).apply { maxLines = 1 }, lp(0, WRAP, 1f))
                    top.addView(glyphBtn("close", T.sub) { t.web.destroy(); tabs.removeAt(i); if (tabs.isEmpty()) newTab(null); cur = cur.coerceIn(0, tabs.size - 1); showSwitcher() }, lp(dp(32), dp(32)))
                    c.addView(top)
                    c.addView(txt(if (t.url.isEmpty()) "Favorites" else host(t.url), 12f, T.sub), lp(MATCH, dp(80)))
                    c.onTap { cur = i; if (t.url.isEmpty()) showStart() else show(t) }
                    r.addView(c, lp(0, WRAP, 1f, dp(4), dp(4), dp(4), dp(4)))
                }
                if (row.size == 1) r.addView(View(this@BrowserActivity), lp(0, 1, 1f))
                addView(r)
            }
            addView(btn("+ New Tab", Color.WHITE, true) { newTab(null) }.apply { gravity = Gravity.CENTER; background = shape(T.blue, dpf(12f)) }, lp(MATCH, WRAP, 0f, 0, dp(12), 0, 0))
        })
    }

    private fun bookmarks() {
        val b = prefs.s("bookmarks").split("\n").filter { it.contains("|") }
        val h = prefs.s("history").split("\n").filter { it.contains("|") }
        fun pick(l: List<String>) = sheet(null, *l.take(15).map { e -> Act(e.substringBefore('|').ifEmpty { e.substringAfter('|') }.take(40)) { go(e.substringAfter('|')) } }.toTypedArray())
        sheet("Library", Act("Add Bookmark") { tab()?.let { if (it.url.isNotEmpty()) { prefs.put("bookmarks", (listOf(it.title + "|" + it.url) + b).distinct().joinToString("\n")); toast("Bookmark added") } } },
            Act("Bookmarks (${b.size})") { pick(b) }, Act("History") { pick(h) }, Act("Clear History", true) { prefs.put("history", "") })
    }

    private fun menu() {
        val t = tab()
        sheet(null,
            Act(if (desktop) "Request Mobile Site" else "Request Desktop Site") {
                desktop = !desktop
                t?.web?.settings?.userAgentString = if (desktop) "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36" else null
                t?.web?.settings?.useWideViewPort = desktop; t?.web?.reload()
            },
            Act("Find on Page") { prompt("Find on Page", "Text") { q -> t?.web?.findAllAsync(q) } },
            Act("Reload") { t?.web?.reload() },
            Act("Add to Home Screen") { if (t != null && t.url.isNotEmpty()) { prefs.addWeb(t.title, t.url); Thread { val f = Shortcuts.favicon(Uri.parse(t.url).host ?: ""); runOnUiThread { Shortcuts.pinWeb(this, t.title, t.url, IconFactory.webIcon(t.title, f, prefs.pack, 192)) } }.start() } },
            Act("Clear Cookies", true) { CookieManager.getInstance().removeAllCookies(null); toast("Cookies cleared") })
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val t = tab()
        if (switcher) { cur = cur.coerceIn(0, tabs.size - 1); tabs[cur].let { if (it.url.isEmpty()) showStart() else show(it) } }
        else if (t != null && t.web.canGoBack()) t.web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() { tabs.forEach { it.web.destroy() }; super.onDestroy() }
}
