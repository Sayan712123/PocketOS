package com.pocketos

import android.content.Context

class Prefs(c: Context) {
    val sp = c.getSharedPreferences("pocketos", Context.MODE_PRIVATE)
    var pack: String
        get() = sp.getString("pack", "default") ?: "default"
        set(v) { sp.edit().putString("pack", v).apply() }
    fun s(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun webApps(): List<Pair<String, String>> =
        s("web").split("\n").filter { it.contains("|") }.map { val i = it.indexOf('|'); it.substring(0, i) to it.substring(i + 1) }
    private fun saveWeb(l: List<Pair<String, String>>) =
        put("web", l.joinToString("\n") { it.first.replace("|", " ").replace("\n", " ") + "|" + it.second })
    fun addWeb(t: String, u: String) = saveWeb(webApps().filter { it.second != u } + (t to u))
    fun removeWeb(u: String) = saveWeb(webApps().filter { it.second != u })
}
