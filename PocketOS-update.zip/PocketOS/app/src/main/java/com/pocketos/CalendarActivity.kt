package com.pocketos

import android.Manifest
import android.app.TimePickerDialog
import android.content.ContentUris
import android.content.ContentValues
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.CalendarContract
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class CalendarActivity : Base() {
    private class Ev(val id: Long, val title: String, val begin: Long, val end: Long, val allDay: Boolean, val color: Int)
    private val month = Calendar.getInstance()
    private var selDay = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
    private var events: List<Ev> = emptyList()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prep()
        ask(listOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)) { render() }
    }

    private fun loadMonth() {
        val s = month.clone() as Calendar
        s.set(Calendar.DAY_OF_MONTH, 1); s.set(Calendar.HOUR_OF_DAY, 0); s.set(Calendar.MINUTE, 0); s.set(Calendar.SECOND, 0)
        val e = s.clone() as Calendar
        e.add(Calendar.MONTH, 1)
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, s.timeInMillis); ContentUris.appendId(b, e.timeInMillis)
        val out = ArrayList<Ev>()
        try {
            contentResolver.query(b.build(), arrayOf(CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.CALENDAR_COLOR),
                null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
                while (c.moveToNext()) out.add(Ev(c.getLong(0), c.getString(1) ?: "(No title)", c.getLong(2), c.getLong(3), c.getInt(4) == 1, c.getInt(5)))
            }
        } catch (e: Exception) { }
        events = out
    }

    private fun dayOf(t: Long, allDay: Boolean): Int {
        val c = Calendar.getInstance(if (allDay) TimeZone.getTimeZone("UTC") else TimeZone.getDefault()); c.timeInMillis = t
        return c.get(Calendar.DAY_OF_MONTH)
    }

    private fun render() {
        loadMonth()
        setContentView(page {
            val today = Calendar.getInstance()
            addView(navRow(btn(SimpleDateFormat("yyyy", Locale.getDefault()).format(month.time)) { }, null).also {
                it.addView(btn("Today") { month.timeInMillis = System.currentTimeMillis(); selDay = today.get(Calendar.DAY_OF_MONTH); render() })
                it.addView(glyphBtn("plus") { addEvent() })
            })
            val head = LinearLayout(this@CalendarActivity)
            head.gravity = Gravity.CENTER_VERTICAL
            head.addView(txt(SimpleDateFormat("MMMM", Locale.getDefault()).format(month.time), 34f, T.label, true), lp(0, WRAP, 1f))
            head.addView(glyphBtn("back") { month.add(Calendar.MONTH, -1); selDay = 1; render() })
            head.addView(glyphBtn("fwd") { month.add(Calendar.MONTH, 1); selDay = 1; render() })
            addView(head)
            val wk = LinearLayout(this@CalendarActivity)
            val first = month.firstDayOfWeek
            for (i in 0..6) wk.addView(txt(SimpleDateFormat("EEEEE", Locale.getDefault()).format(Calendar.getInstance().apply { set(Calendar.DAY_OF_WEEK, (first - 1 + i) % 7 + 1) }.time), 12f, T.sub).apply { gravity = Gravity.CENTER }, lp(0, WRAP, 1f))
            addView(wk, lp(MATCH, WRAP, 0f, 0, dp(8), 0, dp(4)))
            val c0 = month.clone() as Calendar
            c0.set(Calendar.DAY_OF_MONTH, 1)
            val offset = (c0.get(Calendar.DAY_OF_WEEK) - first + 7) % 7
            val days = c0.getActualMaximum(Calendar.DAY_OF_MONTH)
            val dotDays = events.map { dayOf(it.begin, it.allDay) }.toSet()
            val isCur = today.get(Calendar.MONTH) == month.get(Calendar.MONTH) && today.get(Calendar.YEAR) == month.get(Calendar.YEAR)
            var d = 1 - offset
            while (d <= days) {
                val row = LinearLayout(this@CalendarActivity)
                for (i in 0..6) {
                    val cell = LinearLayout(this@CalendarActivity)
                    cell.orientation = LinearLayout.VERTICAL
                    cell.gravity = Gravity.CENTER
                    if (d in 1..days) {
                        val day = d
                        val sel = day == selDay
                        val isToday = isCur && day == today.get(Calendar.DAY_OF_MONTH)
                        val t = txt(day.toString(), 18f, if (sel) Color.WHITE else if (isToday) T.red else T.label, sel || isToday)
                        t.gravity = Gravity.CENTER
                        if (sel) t.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (isToday) T.red else T.label.let { if (T.dark) 0xFF636366.toInt() else 0xFF1C1C1E.toInt() }) }
                        cell.addView(t, lp(dp(36), dp(36)))
                        val dot = View(this@CalendarActivity)
                        dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (day in dotDays) T.sub else Color.TRANSPARENT) }
                        cell.addView(dot, lp(dp(5), dp(5), 0f, 0, dp(2), 0, dp(4)))
                        cell.onTap { selDay = day; render() }
                    }
                    row.addView(cell, lp(0, WRAP, 1f))
                    d++
                }
                addView(row)
            }
            addView(section(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Calendar.getInstance().apply { time = month.time; set(Calendar.DAY_OF_MONTH, selDay) }.time)))
            val todays = events.filter { dayOf(it.begin, it.allDay) == selDay }
            if (todays.isEmpty()) addView(txt("No events", 15f, T.sub), lp(WRAP, WRAP, 0f, dp(8), 0, 0, 0))
            else {
                val g = Group(this@CalendarActivity)
                for (e in todays) {
                    val r = LinearLayout(this@CalendarActivity)
                    r.gravity = Gravity.CENTER_VERTICAL
                    r.setPadding(dp(16), dp(10), dp(16), dp(10))
                    val bar = View(this@CalendarActivity); bar.background = shape(if (e.color != 0) e.color else T.blue, dpf(2f))
                    r.addView(bar, lp(dp(4), dp(36), 0f, 0, 0, dp(12), 0))
                    val c = LinearLayout(this@CalendarActivity); c.orientation = LinearLayout.VERTICAL
                    c.addView(txt(e.title, 17f))
                    val f = SimpleDateFormat(if (DateFormat.is24HourFormat(this@CalendarActivity)) "HH:mm" else "h:mm a", Locale.getDefault())
                    c.addView(txt(if (e.allDay) "All-day" else f.format(e.begin) + " – " + f.format(e.end), 13f, T.sub))
                    r.addView(c, lp(0, WRAP, 1f))
                    g.add(r, 32) { sheet(e.title, Act("Delete Event", true) { contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, e.id), null, null); render() }) }
                }
                addView(g)
            }
        })
    }

    private fun calendarId(): Long {
        try {
            contentResolver.query(CalendarContract.Calendars.CONTENT_URI, arrayOf(CalendarContract.Calendars._ID), CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + ">=500 AND " + CalendarContract.Calendars.VISIBLE + "=1", null, null)?.use { if (it.moveToFirst()) return it.getLong(0) }
            val cv = ContentValues()
            cv.put(CalendarContract.Calendars.ACCOUNT_NAME, "PocketOS"); cv.put(CalendarContract.Calendars.ACCOUNT_TYPE, CalendarContract.ACCOUNT_TYPE_LOCAL)
            cv.put(CalendarContract.Calendars.NAME, "PocketOS"); cv.put(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME, "PocketOS")
            cv.put(CalendarContract.Calendars.CALENDAR_COLOR, 0xFF0A84FF.toInt()); cv.put(CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL, CalendarContract.Calendars.CAL_ACCESS_OWNER)
            cv.put(CalendarContract.Calendars.OWNER_ACCOUNT, "PocketOS"); cv.put(CalendarContract.Calendars.VISIBLE, 1); cv.put(CalendarContract.Calendars.SYNC_EVENTS, 1)
            val u = CalendarContract.Calendars.CONTENT_URI.buildUpon().appendQueryParameter(CalendarContract.CALLER_IS_SYNCADAPTER, "true")
                .appendQueryParameter(CalendarContract.Calendars.ACCOUNT_NAME, "PocketOS").appendQueryParameter(CalendarContract.Calendars.ACCOUNT_TYPE, CalendarContract.ACCOUNT_TYPE_LOCAL).build()
            val r = contentResolver.insert(u, cv)
            if (r != null) return ContentUris.parseId(r)
        } catch (e: Exception) { }
        return -1
    }

    private fun addEvent() {
        prompt("New Event", "Title") { title ->
            if (title.isEmpty()) return@prompt
            TimePickerDialog(this, { _, h, m ->
                sheet("Duration", Act("30 minutes") { save(title, h, m, 30, false) }, Act("1 hour") { save(title, h, m, 60, false) }, Act("2 hours") { save(title, h, m, 120, false) }, Act("All day") { save(title, 0, 0, 0, true) })
            }, 9, 0, DateFormat.is24HourFormat(this)).show()
        }
    }

    private fun save(title: String, h: Int, m: Int, mins: Int, allDay: Boolean) {
        val id = calendarId()
        if (id < 0) { toast("No writable calendar"); return }
        val c = month.clone() as Calendar
        c.set(Calendar.DAY_OF_MONTH, selDay); c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, m); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        val cv = ContentValues()
        cv.put(CalendarContract.Events.CALENDAR_ID, id); cv.put(CalendarContract.Events.TITLE, title)
        if (allDay) {
            val u = Calendar.getInstance(TimeZone.getTimeZone("UTC")); u.clear(); u.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), selDay)
            cv.put(CalendarContract.Events.DTSTART, u.timeInMillis); cv.put(CalendarContract.Events.DTEND, u.timeInMillis + 86400000L)
            cv.put(CalendarContract.Events.ALL_DAY, 1); cv.put(CalendarContract.Events.EVENT_TIMEZONE, "UTC")
        } else {
            cv.put(CalendarContract.Events.DTSTART, c.timeInMillis); cv.put(CalendarContract.Events.DTEND, c.timeInMillis + mins * 60000L)
            cv.put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }
        try { contentResolver.insert(CalendarContract.Events.CONTENT_URI, cv) } catch (e: Exception) { toast("Could not save event") }
        render()
    }
}
