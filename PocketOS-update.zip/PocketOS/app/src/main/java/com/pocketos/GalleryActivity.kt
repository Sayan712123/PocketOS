package com.pocketos

import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.format.DateUtils
import android.util.LruCache
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.VideoView
import androidx.viewpager.widget.ViewPager
import java.util.concurrent.Executors

class Media(val id: Long, val uri: Uri, val video: Boolean, val date: Long, val bucket: String, val name: String)

class ZoomImage(c: android.content.Context) : ImageView(c) {
    private val m = Matrix()
    private var scale = 1f
    private var base = 1f
    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val f = (scale * d.scaleFactor).coerceIn(1f, 6f) / scale
            scale *= f; m.postScale(f, f, d.focusX, d.focusY); imageMatrix = m; return true
        }
    })
    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean { reset(); if (scale == 1f) { m.postScale(2.5f, 2.5f, e.x, e.y); scale = 2.5f; imageMatrix = m }; return true }
        override fun onScroll(a: MotionEvent?, b: MotionEvent, dx: Float, dy: Float): Boolean { if (scale > 1f) { m.postTranslate(-dx, -dy); imageMatrix = m }; return true }
    })
    init { scaleType = ScaleType.MATRIX }
    fun reset() { fit(); scale = 1f }
    fun fit() {
        val d = drawable ?: return
        val s = Math.min(width.toFloat() / d.intrinsicWidth, height.toFloat() / d.intrinsicHeight)
        m.reset(); m.postScale(s, s); m.postTranslate((width - d.intrinsicWidth * s) / 2, (height - d.intrinsicHeight * s) / 2); base = s; imageMatrix = m
    }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); reset() }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e); gd.onTouchEvent(e)
        parent?.requestDisallowInterceptTouchEvent(scale > 1.02f)
        return true
    }
}

class GalleryActivity : Base() {
    private var items: List<Media> = emptyList()
    private val ex = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())
    private val cache = LruCache<Long, Bitmap>(300)
    private lateinit var shell: Shell
    private var tab = 0
    private var album: String? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        shell = Shell(this)
        shell.tabs(listOf("photo" to "Library", "folder" to "Albums"), 0) { tab = it; album = null; render() }
        setContentView(shell.root)
        ask(mediaPerms()) { load(); render() }
    }

    private fun load() {
        val out = ArrayList<Media>()
        val uri = MediaStore.Files.getContentUri("external")
        try {
            contentResolver.query(uri, arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.MEDIA_TYPE, MediaStore.Files.FileColumns.DATE_ADDED, "bucket_display_name", MediaStore.Files.FileColumns.DISPLAY_NAME),
                "media_type=1 OR media_type=3", null, "date_added DESC")?.use { c ->
                while (c.moveToNext()) {
                    val v = c.getInt(1) == 3
                    val id = c.getLong(0)
                    out.add(Media(id, ContentUris.withAppendedId(if (v) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), v, c.getLong(2) * 1000, c.getString(3) ?: "Other", c.getString(4) ?: ""))
                }
            }
        } catch (e: Exception) { }
        items = out
    }

    override fun onResume() { super.onResume(); if (checkSelfPermission(mediaPerms()[0]) == 0) { load(); render() } }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (album != null) { album = null; render() } else super.onBackPressed() }

    @Suppress("DEPRECATION")
    private fun oldThumb(m: Media): Bitmap? =
        if (m.video) MediaStore.Video.Thumbnails.getThumbnail(contentResolver, m.id, MediaStore.Video.Thumbnails.MINI_KIND, null)
        else MediaStore.Images.Thumbnails.getThumbnail(contentResolver, m.id, MediaStore.Images.Thumbnails.MINI_KIND, null)

    private fun thumb(m: Media, iv: ImageView) {
        cache.get(m.id)?.let { iv.setImageBitmap(it); return }
        iv.setImageBitmap(null)
        iv.tag = m.id
        ex.execute {
            var b: Bitmap? = null
            try {
                b = if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(m.uri, Size(256, 256), null) else oldThumb(m)
            } catch (e: Exception) { }
            if (b != null) { cache.put(m.id, b); val bb = b; ui.post { if (iv.tag == m.id) iv.setImageBitmap(bb) } }
        }
    }

    private fun render() {
        if (items.isEmpty()) { shell.show(page { addView(largeTitle("Photos")); addView(txt("No photos or videos", 15f, T.sub)) }); return }
        if (tab == 1 && album == null) { albums(); return }
        val list = if (album != null) items.filter { it.bucket == album } else items
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(T.bg)
        col.setPadding(dp(8), dp(8), dp(8), 0)
        col.addView(navRow(if (album != null) btn("‹ Albums") { album = null; render() } else null, null))
        col.addView(largeTitle(album ?: "Library"))
        val gv = GridView(this)
        gv.numColumns = 4
        gv.horizontalSpacing = dp(2); gv.verticalSpacing = dp(2)
        gv.clipToPadding = false
        gv.setPadding(0, 0, 0, dp(100))
        val size = (resources.displayMetrics.widthPixels - dp(16) - dp(6)) / 4
        gv.adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(p: Int) = list[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, par: ViewGroup?): View {
                val f = (v as? FrameLayout) ?: FrameLayout(this@GalleryActivity).also {
                    val iv = ImageView(this@GalleryActivity); iv.scaleType = ImageView.ScaleType.CENTER_CROP; iv.setBackgroundColor(T.fill)
                    it.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
                    it.addView(glyph("play", Color.WHITE, 18), FrameLayout.LayoutParams(dp(18), dp(18), Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(4), 0, 0, dp(4)) })
                }
                f.layoutParams = AbsListViewLP(size)
                val m = list[p]
                f.getChildAt(1).visibility = if (m.video) View.VISIBLE else View.GONE
                thumb(m, f.getChildAt(0) as ImageView)
                return f
            }
        }
        gv.setOnItemClickListener { _, _, p, _ -> viewer(list, p) }
        col.addView(gv, lp(MATCH, 0, 1f))
        shell.show(col)
    }

    @Suppress("FunctionName")
    private fun AbsListViewLP(s: Int) = android.widget.AbsListView.LayoutParams(s, s)

    private fun albums() {
        val groups = items.groupBy { it.bucket }
        shell.show(page {
            addView(largeTitle("Albums"))
            val g = Group(this@GalleryActivity)
            for ((n, l) in groups) {
                val r = LinearLayout(this@GalleryActivity)
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(12), dp(8), dp(12), dp(8))
                val iv = ImageView(this@GalleryActivity); iv.scaleType = ImageView.ScaleType.CENTER_CROP; iv.background = shape(T.fill, dpf(8f)); iv.clipToOutline = true
                thumb(l[0], iv)
                r.addView(iv, lp(dp(56), dp(56), 0f, 0, 0, dp(12), 0))
                val c = LinearLayout(this@GalleryActivity); c.orientation = LinearLayout.VERTICAL
                c.addView(txt(n, 17f)); c.addView(txt(l.size.toString(), 14f, T.sub))
                r.addView(c, lp(0, WRAP, 1f))
                g.add(r, 80) { album = n; render() }
            }
            addView(g)
        })
    }

    private fun viewer(list: List<Media>, start: Int) {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val pager = ViewPager(this)
        var cur = start
        pager.adapter = LazyAdapter(list.size) { i ->
            val m = list[i]
            if (m.video) {
                val f = FrameLayout(this)
                val vv = VideoView(this); vv.setVideoURI(m.uri)
                f.addView(vv, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
                f.setOnClickListener { if (vv.isPlaying) vv.pause() else vv.start() }
                f
            } else {
                val z = ZoomImage(this)
                ex.execute {
                    try {
                        val o = BitmapFactory.Options(); o.inJustDecodeBounds = true
                        contentResolver.openInputStream(m.uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                        o.inSampleSize = (Math.max(o.outWidth, o.outHeight) / 2048).coerceAtLeast(1); o.inJustDecodeBounds = false
                        val b = contentResolver.openInputStream(m.uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                        ui.post { z.setImageBitmap(b); z.reset() }
                    } catch (e: Exception) { }
                }
                z
            }
        }
        pager.currentItem = start
        pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() { override fun onPageSelected(p: Int) { cur = p } })
        root.addView(pager, FrameLayout.LayoutParams(MATCH, MATCH))
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER
        bar.setBackgroundColor(0x99000000.toInt())
        bar.addView(glyphBtn("share", Color.WHITE) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(if (list[cur].video) "video/*" else "image/*").putExtra(Intent.EXTRA_STREAM, list[cur].uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share"))
        }, lp(0, WRAP, 1f))
        bar.addView(glyphBtn("info", Color.WHITE) {
            val m = list[cur]; toast(m.name + "  ·  " + DateUtils.formatDateTime(this, m.date, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME))
        }, lp(0, WRAP, 1f))
        bar.addView(glyphBtn("trash", Color.WHITE) {
            val m = list[cur]
            try {
                if (Build.VERSION.SDK_INT >= 30) startIntentSenderForResult(MediaStore.createDeleteRequest(contentResolver, listOf(m.uri)).intentSender, 77, null, 0, 0, 0)
                else { contentResolver.delete(m.uri, null, null); load(); render(); setContentView(shell.root) }
            } catch (e: Exception) { toast("Cannot delete") }
        }, lp(0, WRAP, 1f))
        bar.addView(glyphBtn("close", Color.WHITE) { setContentView(shell.root); load(); render() }, lp(0, WRAP, 1f))
        root.addView(bar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        setContentView(root)
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 77) { load(); setContentView(shell.root); render() }
    }
}
