package com.pocketos

import android.Manifest
import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView

class ContactsActivity : Base() {
    private class Row(val header: String?, val c: Contact?)
    private var all: List<Contact> = emptyList()
    private var query = ""
    private var detail: Contact? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prep()
        ask(listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)) { reload() }
    }

    private fun reload() { all = Repo.contacts(this); val d = detail; if (d != null) { detail = all.firstOrNull { it.id == d.id }; if (detail != null) { showDetail(detail!!); return } }; showList() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (detail != null) { detail = null; showList() } else super.onBackPressed() }

    private fun showList() {
        detail = null
        val rows = ArrayList<Row>()
        var last = ""
        for (c in all.filter { query.isEmpty() || it.name.contains(query, true) || it.numbers.any { n -> n.contains(query) } }) {
            val h = c.name.trim().take(1).uppercase().let { if (it.isNotEmpty() && it[0].isLetter()) it else "#" }
            if (h != last) { rows.add(Row(h, null)); last = h }
            rows.add(Row(null, c))
        }
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(T.bg)
        root.setPadding(dp(16), dp(8), dp(16), 0)
        root.addView(navRow(null, glyphBtn("plus") { showEdit(null) }))
        root.addView(largeTitle("Contacts"))
        root.addView(searchBar("Search") { q -> query = q; showList() }, lp(MATCH, dp(44), 0f, 0, 0, 0, dp(8)))
        val lv = ListView(this)
        lv.divider = null
        lv.setBackgroundColor(T.bg)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(p: Int) = rows[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, par: ViewGroup?): View {
                val r = rows[p]
                if (r.header != null) return txt(r.header, 14f, T.sub, true).apply { setPadding(dp(8), dp(14), 0, dp(4)) }
                val c = r.c!!
                val row = LinearLayout(this@ContactsActivity)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(8), dp(8), dp(24), dp(8))
                row.addView(avatar(c.name), lp(dp(40), dp(40), 0f, 0, 0, dp(12), 0))
                row.addView(txt(c.name, 17f), lp(0, WRAP, 1f))
                return row
            }
        }
        lv.setOnItemClickListener { _, _, p, _ -> rows[p].c?.let { showDetail(it) } }
        val frame = FrameLayout(this)
        frame.addView(lv, FrameLayout.LayoutParams(MATCH, MATCH))
        // A-Z index bar
        val idx = LinearLayout(this)
        idx.orientation = LinearLayout.VERTICAL
        idx.gravity = Gravity.CENTER
        val letters = rows.mapNotNull { it.header }
        for (l in letters) idx.addView(txt(l, 10f, T.blue, true).apply { gravity = Gravity.CENTER }, lp(dp(20), 0, 1f))
        idx.setOnTouchListener { v, ev ->
            if (letters.isNotEmpty()) {
                val i = ((ev.y / v.height) * letters.size).toInt().coerceIn(0, letters.size - 1)
                val pos = rows.indexOfFirst { it.header == letters[i] }
                if (pos >= 0) lv.setSelection(pos)
            }
            true
        }
        frame.addView(idx, FrameLayout.LayoutParams(dp(24), MATCH, Gravity.END).apply { setMargins(0, dp(8), 0, dp(24)) })
        root.addView(frame, lp(MATCH, 0, 1f))
        setContentView(root)
    }

    private fun action(g: String, label: String, f: () -> Unit): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.background = shape(T.card, dpf(12f))
        c.setPadding(0, dp(10), 0, dp(8))
        c.addView(glyph(g, T.blue, 22), lp(dp(22), dp(22)))
        c.addView(txt(label, 11f, T.blue), lp(WRAP, WRAP, 0f, 0, dp(2), 0, 0))
        c.onTap(f)
        return c
    }

    private fun showDetail(c: Contact) {
        detail = c
        setContentView(page {
            addView(navRow(btn("‹ Contacts") { detail = null; showList() }, btn("Edit") { showEdit(c) }))
            val a = avatar(c.name); a.textSize = 44f
            addView(a, lp(dp(110), dp(110)).apply { gravity = Gravity.CENTER_HORIZONTAL })
            addView(txt(c.name, 28f, T.label, true).apply { gravity = Gravity.CENTER }, lp(MATCH, WRAP, 0f, 0, dp(10), 0, dp(14)))
            val r = LinearLayout(this@ContactsActivity)
            val n = c.numbers.firstOrNull()
            r.addView(action("msg", "message") { if (n != null) startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n)))) }, lp(0, WRAP, 1f, 0, 0, dp(6), 0))
            r.addView(action("call", "call") { if (n != null) startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n)))) }, lp(0, WRAP, 1f, dp(3), 0, dp(3), 0))
            r.addView(action(if (c.starred) "starf" else "star", "favorite") { setStar(c, !c.starred) }, lp(0, WRAP, 1f, dp(6), 0, 0, 0))
            addView(r)
            addView(section("Phone"))
            val g = Group(this@ContactsActivity)
            for (num in c.numbers) g.row("mobile", num, null, false, T.label) { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))) }
            addView(g)
            val d = Group(this@ContactsActivity)
            d.row("Delete Contact", null, null, false, T.red) {
                sheet("Delete ${c.name}?", Act("Delete Contact", true) {
                    contentResolver.delete(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, c.id), null, null); detail = null; reload()
                })
            }
            addView(d, lp(MATCH, WRAP, 0f, 0, dp(24), 0, 0))
        })
    }

    private fun setStar(c: Contact, v: Boolean) {
        try {
            val cv = ContentValues(); cv.put(ContactsContract.Contacts.STARRED, if (v) 1 else 0)
            contentResolver.update(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, c.id), cv, null, null)
        } catch (e: Exception) { toast("Cannot edit contact") }
        reload()
    }

    private fun showEdit(c: Contact?) {
        val name = EditText(this); name.hint = "Name"; name.setText(c?.name ?: ""); name.setSingleLine()
        val phone = EditText(this); phone.hint = "Phone"; phone.setText(c?.numbers?.firstOrNull() ?: ""); phone.setSingleLine()
        phone.inputType = android.text.InputType.TYPE_CLASS_PHONE
        setContentView(page {
            addView(navRow(btn("Cancel") { if (c != null) showDetail(c) else showList() }, btn("Done", T.blue, true) { save(c, name.text.toString().trim(), phone.text.toString().trim()) }))
            addView(largeTitle(if (c == null) "New Contact" else "Edit Contact"))
            val g = Group(this@ContactsActivity)
            name.background = null; phone.background = null
            name.setPadding(dp(16), dp(14), dp(16), dp(14)); phone.setPadding(dp(16), dp(14), dp(16), dp(14))
            g.add(name); g.add(phone)
            addView(g)
        })
    }

    private fun save(c: Contact?, name: String, phone: String) {
        if (name.isEmpty()) { toast("Enter a name"); return }
        try {
            if (c == null) {
                val ops = ArrayList<ContentProviderOperation>()
                ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null).withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
                ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name).build())
                if (phone.isNotEmpty()) ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                    .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                    .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE).build())
                contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            } else {
                val nv = ContentValues(); nv.put(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                contentResolver.update(ContactsContract.Data.CONTENT_URI, nv, ContactsContract.Data.CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=?",
                    arrayOf(c.id.toString(), ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE))
                if (phone.isNotEmpty() && c.numbers.isNotEmpty()) {
                    val pv = ContentValues(); pv.put(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                    contentResolver.update(ContactsContract.Data.CONTENT_URI, pv, ContactsContract.Data.CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=? AND " + ContactsContract.CommonDataKinds.Phone.NUMBER + "=?",
                        arrayOf(c.id.toString(), ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE, c.numbers[0]))
                }
            }
        } catch (e: Exception) { toast("Could not save contact") }
        detail = null
        reload()
    }
}
