package com.pocketos

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WaveView(c: Context) : View(c) {
    val amps = ArrayList<Int>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        p.color = T.red
        val bw = context.dpf(3f); val gap = context.dpf(3f)
        val n = (width / (bw + gap)).toInt()
        val l = amps.takeLast(n)
        for ((i, a) in l.withIndex()) {
            val h = Math.max(context.dpf(3f), height * (a / 32767f) * 0.95f)
            val x = width - (l.size - i) * (bw + gap)
            cv.drawRoundRect(RectF(x, (height - h) / 2, x + bw, (height + h) / 2), bw / 2, bw / 2, p)
        }
    }
}

class RecorderActivity : Base() {
    private var rec: MediaRecorder? = null
    private var paused = false
    private var startAt = 0L; private var accum = 0L
    private var player: MediaPlayer? = null
    private var playing: File? = null
    private val h = Handler(Looper.getMainLooper())
    private var wave: WaveView? = null
    private var timeView: TextView? = null
    private val dir: File get() = File(getExternalFilesDir(null), "Recordings").also { it.mkdirs() }
    private val tick = object : Runnable {
        override fun run() {
            val r = rec
            if (r != null && !paused) { try { wave?.amps?.add(r.maxAmplitude); wave?.invalidate() } catch (e: Exception) { }; timeView?.text = fmt(accum + System.currentTimeMillis() - startAt) }
            h.postDelayed(this, 60)
        }
    }
    private fun fmt(ms: Long) = String.format(Locale.US, "%02d:%02d.%d", ms / 60000, (ms / 1000) % 60, (ms / 100) % 10)

    override fun onCreate(b: Bundle?) { super.onCreate(b); prep(); render() }
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
    override fun onDestroy() { try { rec?.release() } catch (e: Exception) { }; player?.release(); super.onDestroy() }

    private fun render() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(T.bg)
        val recording = rec != null
        val list = page {
            addView(largeTitle("All Recordings"))
            val files = (dir.listFiles() ?: emptyArray()).filter { it.extension == "m4a" }.sortedByDescending { it.lastModified() }
            if (files.isEmpty()) addView(txt("No recordings yet", 15f, T.sub), lp(WRAP, WRAP, 0f, dp(4), dp(8), 0, 0))
            val g = Group(this@RecorderActivity)
            for (f in files) {
                val c = LinearLayout(this@RecorderActivity)
                c.orientation = LinearLayout.VERTICAL
                c.setPadding(dp(16), dp(12), dp(16), dp(12))
                val dur = try { val m = MediaPlayer(); m.setDataSource(f.path); m.prepare(); val d = m.duration; m.release(); d.toLong() } catch (e: Exception) { 0L }
                c.addView(txt(f.nameWithoutExtension, 17f, T.label, true))
                c.addView(txt(DateUtils.formatDateTime(this@RecorderActivity, f.lastModified(), DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME) + "   " + fmt(dur).substringBeforeLast('.'), 13f, T.sub))
                if (playing == f) {
                    val sb = SeekBar(this@RecorderActivity); sb.max = player?.duration ?: 0
                    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { if (u) player?.seekTo(p) }
                        override fun onStartTrackingTouch(s: SeekBar) {}
                        override fun onStopTrackingTouch(s: SeekBar) {}
                    })
                    h.post(object : Runnable { override fun run() { if (playing == f) { try { sb.progress = player?.currentPosition ?: 0 } catch (e: Exception) { }; h.postDelayed(this, 300) } } })
                    c.addView(sb)
                    val ctl = LinearLayout(this@RecorderActivity)
                    ctl.addView(glyphBtn(if (player?.isPlaying == true) "pause" else "play", T.label) { player?.let { if (it.isPlaying) it.pause() else it.start() }; render() })
                    ctl.addView(View(this@RecorderActivity), lp(0, 1, 1f))
                    ctl.addView(glyphBtn("share", T.blue) { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("audio/mp4").putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(this@RecorderActivity, "$packageName.files", f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share")) })
                    ctl.addView(glyphBtn("edit", T.blue) { prompt("Rename", "Name", f.nameWithoutExtension) { n -> if (n.isNotEmpty()) { f.renameTo(File(dir, "$n.m4a")); stopPlay(); render() } } })
                    ctl.addView(glyphBtn("trash", T.red) { stopPlay(); f.delete(); render() })
                    c.addView(ctl)
                }
                g.add(c, 16) { if (playing == f) stopPlay() else play(f); render() }
            }
            addView(g)
        }
        root.addView(list, lp(MATCH, 0, 1f))
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER
        panel.setBackgroundColor(T.card)
        panel.setPadding(dp(16), dp(12), dp(16), dp(20))
        if (recording) {
            val w = WaveView(this); wave = w
            panel.addView(w, lp(MATCH, dp(80)))
            val t = txt("00:00.0", 40f, T.label); timeView = t; panel.addView(t)
        }
        val inner = View(this)
        inner.background = shape(T.red, if (recording) dpf(6f) else dpf(26f))
        val ring = android.widget.FrameLayout(this)
        ring.background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setStroke(dp(3), T.sub); setColor(Color.TRANSPARENT) }
        ring.addView(inner, android.widget.FrameLayout.LayoutParams(if (recording) dp(26) else dp(52), if (recording) dp(26) else dp(52), Gravity.CENTER))
        ring.setOnClickListener { if (recording) stopRec() else ask(listOf(Manifest.permission.RECORD_AUDIO)) { startRec() } }
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER
        if (recording) row.addView(btn(if (paused) "Resume" else "Pause", T.blue, true) { togglePause() }, lp(dp(90), WRAP))
        row.addView(ring, lp(dp(70), dp(70), 0f, dp(16), dp(8), dp(16), 0))
        if (recording) row.addView(View(this), lp(dp(90), 1))
        panel.addView(row)
        root.addView(panel, lp(MATCH, WRAP))
        setContentView(root)
    }

    private fun play(f: File) {
        stopPlay()
        try {
            player = MediaPlayer().apply { setDataSource(f.path); prepare(); start(); setOnCompletionListener { runOnUiThread { stopPlay(); render() } } }
            playing = f
        } catch (e: Exception) { toast("Cannot play") }
    }

    private fun stopPlay() { try { player?.release() } catch (e: Exception) { }; player = null; playing = null }

    private fun startRec() {
        stopPlay()
        try {
            val f = File(dir, "Recording " + SimpleDateFormat("yyyy-MM-dd HH.mm.ss", Locale.US).format(Date()) + ".m4a")
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC); r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128000); r.setAudioSamplingRate(44100); r.setOutputFile(f.path)
            r.prepare(); r.start()
            rec = r; paused = false; accum = 0; startAt = System.currentTimeMillis()
            render()
        } catch (e: Exception) { toast("Cannot start recording"); rec = null }
    }

    private fun togglePause() {
        val r = rec ?: return
        if (paused) { r.resume(); startAt = System.currentTimeMillis() } else { r.pause(); accum += System.currentTimeMillis() - startAt }
        paused = !paused
        render()
    }

    private fun stopRec() {
        try { rec?.stop() } catch (e: Exception) { }
        try { rec?.release() } catch (e: Exception) { }
        rec = null; wave = null; timeView = null
        render()
    }
}
