package com.pocketos

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.text.format.DateUtils
import android.text.format.Formatter
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object FileIcons {
    private val cache = LruCache<String, Bitmap>(200)
    fun kind(f: File): String {
        if (f.isDirectory) return "folder"
        return when (f.extension.lowercase()) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic" -> "image"
            "mp4", "mkv", "mov", "avi", "3gp", "webm" -> "video"
            "mp3", "m4a", "wav", "flac", "ogg", "aac", "opus" -> "audio"
            "pdf" -> "pdf"
            "doc", "docx", "txt", "md", "rtf", "odt" -> "doc"
            "xls", "xlsx", "csv", "ods" -> "sheet"
            "ppt", "pptx", "odp" -> "slides"
            "zip", "rar", "7z", "tar", "gz" -> "zip"
            "apk" -> "apk"
            "json", "xml", "html", "js", "kt", "java", "py", "css" -> "code"
            else -> "file"
        }
    }
    private fun color(k: String) = when (k) {
        "image" -> 0xFF5E5CE6; "video" -> 0xFFFF375F; "audio" -> 0xFFFF2D55; "pdf" -> 0xFFFF3B30; "doc" -> 0xFF0A84FF
        "sheet" -> 0xFF34C759; "slides" -> 0xFFFF9F0A; "zip" -> 0xFF8E8E93; "apk" -> 0xFF30D158; "code" -> 0xFF64D2FF; else -> 0xFF8E8E93
    }.toInt()

    fun icon(f: File, w: Int, h: Int): Bitmap {
        val key = f.path + f.lastModified()
        cache.get(key)?.let { return it }
        val k = kind(f)
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        if (k == "folder") {
            p.color = 0xFF0A6FDB.toInt(); c.drawRoundRect(RectF(w * .05f, h * .22f, w * .5f, h * .5f), w * .06f, w * .06f, p)
            c.drawRoundRect(RectF(w * .05f, h * .3f, w * .95f, h * .85f), w * .08f, w * .08f, p)
            p.color = 0xFF5AA9FF.toInt(); c.drawRoundRect(RectF(w * .05f, h * .42f, w * .95f, h * .85f), w * .08f, w * .08f, p)
        } else {
            p.color = Color.WHITE
            val body = Path().apply { moveTo(w * .15f, h * .05f); lineTo(w * .65f, h * .05f); lineTo(w * .85f, h * .25f); lineTo(w * .85f, h * .95f); lineTo(w * .15f, h * .95f); close() }
            c.drawPath(body, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = w * .02f; p.color = 0xFFC7C7CC.toInt(); c.drawPath(body, p)
            p.style = Paint.Style.FILL; p.color = 0xFFE5E5EA.toInt()
            val fold = Path().apply { moveTo(w * .65f, h * .05f); lineTo(w * .65f, h * .25f); lineTo(w * .85f, h * .25f); close() }
            c.drawPath(fold, p)
            p.color = color(k)
            c.drawRect(w * .15f, h * .62f, w * .85f, h * .85f, p)
            p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.isFakeBoldText = true; p.textSize = h * .15f
            c.drawText(f.extension.uppercase().take(4), w * .5f, h * .795f, p)
            if (k == "image") {
                try {
                    val o = BitmapFactory.Options(); o.inJustDecodeBounds = true; BitmapFactory.decodeFile(f.path, o)
                    o.inSampleSize = (Math.max(o.outWidth, o.outHeight) / 160).coerceAtLeast(1); o.inJustDecodeBounds = false
                    val th = BitmapFactory.decodeFile(f.path, o)
                    if (th != null) { val t = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val tc = Canvas(t); tc.drawColor(0xFFE5E5EA.toInt())
                        val s = Math.max(w.toFloat() / th.width, h.toFloat() / th.height); val dw = th.width * s; val dh = th.height * s
                        tc.drawBitmap(th, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), null); cache.put(key, t); return t }
                } catch (e: Exception) { }
            }
        }
        cache.put(key, b)
        return b
    }
}

class FilesActivity : Base() {
    private val root: File = Environment.getExternalStorageDirectory()
    private var dir: File? = null
    private var query = ""
    private var sort = 0
    private var clip: File? = null
    private var move = false
    private val ex = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) { super.onCreate(b); prep() }
    override fun onResume() { super.onResume(); show() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val d = dir
        if (d == null) super.onBackPressed()
        else { dir = if (d.path == root.path || d.parentFile == null) null else d.parentFile; query = ""; show() }
    }

    private fun hasAccess() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 3)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { show() }

    private fun show() {
        if (!hasAccess()) {
            setContentView(page {
                addView(largeTitle("Files"))
                addView(txt("Allow file access to browse your storage.", 15f, T.sub), lp(WRAP, WRAP, 0f, dp(4), 0, 0, dp(12)))
                addView(btn("Grant Access", Color.WHITE, true) { requestAccess() }.apply { gravity = Gravity.CENTER; background = shape(T.blue, dpf(12f)) })
            })
            return
        }
        val d = dir
        if (d == null) home() else folder(d)
    }

    private fun home() {
        setContentView(page {
            addView(largeTitle("Browse"))
            val sf = StatFs(root.path)
            val total = sf.totalBytes; val free = sf.availableBytes
            val g0 = Group(this@FilesActivity)
            val box = LinearLayout(this@FilesActivity)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(16), dp(14), dp(16), dp(14))
            box.addView(txt("Storage", 13f, T.sub))
            box.addView(txt(Formatter.formatShortFileSize(this@FilesActivity, total - free) + " of " + Formatter.formatShortFileSize(this@FilesActivity, total) + " used", 17f))
            val bar = LinearLayout(this@FilesActivity)
            bar.background = shape(T.fill, dpf(4f))
            val used = View(this@FilesActivity); used.background = shape(T.blue, dpf(4f))
            bar.addView(used, lp(0, dp(8), (total - free).toFloat()))
            bar.addView(View(this@FilesActivity), lp(0, dp(8), free.toFloat()))
            box.addView(bar, lp(MATCH, dp(8), 0f, 0, dp(8), 0, 0))
            g0.add(box)
            addView(g0)
            addView(section("Locations"))
            val g = Group(this@FilesActivity)
            val locs = listOf("On My Phone" to root, "Downloads" to File(root, "Download"), "Camera" to File(root, "DCIM"), "Pictures" to File(root, "Pictures"),
                "Documents" to File(root, "Documents"), "Music" to File(root, "Music"), "Movies" to File(root, "Movies"))
            for ((n, f) in locs) if (f.exists()) g.row(n, null, iconTile("folder", T.blue), true) { dir = f; show() }
            addView(g)
        })
    }

    private fun sorted(l: List<File>): List<File> {
        val c: Comparator<File> = when (sort) { 1 -> compareByDescending<File> { it.lastModified() }; 2 -> compareByDescending<File> { if (it.isDirectory) 0L else it.length() }; else -> compareBy<File> { it.name.lowercase() } }
        return l.sortedWith(compareBy<File> { !it.isDirectory }.then(c))
    }

    private fun folder(d: File) {
        val all = sorted((d.listFiles() ?: emptyArray()).filter { !it.name.startsWith(".") && (query.isEmpty() || it.name.contains(query, true)) })
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(T.bg)
        col.setPadding(dp(16), dp(8), dp(16), 0)
        col.addView(navRow(btn("‹ Back") { onBackPressed() }, glyphBtn("more") {
            sheet(d.name, Act("New Folder") { prompt("New Folder", "Name") { n -> if (n.isNotEmpty()) { File(d, n).mkdirs(); show() } } },
                Act("Sort by Name") { sort = 0; show() }, Act("Sort by Date") { sort = 1; show() }, Act("Sort by Size") { sort = 2; show() })
        }))
        col.addView(largeTitle(if (d.path == root.path) "On My Phone" else d.name))
        col.addView(searchBar("Search") { q -> query = q; ui.removeCallbacksAndMessages(null); ui.postDelayed({ show() }, 350) }, lp(MATCH, dp(44), 0f, 0, 0, 0, dp(8)))
        clip?.let { c ->
            val t = btn("Paste \"${c.name}\" here", Color.WHITE, true) { paste(d) }
            t.gravity = Gravity.CENTER; t.background = shape(T.blue, dpf(12f))
            col.addView(t, lp(MATCH, WRAP, 0f, 0, 0, 0, dp(8)))
        }
        val lv = ListView(this)
        lv.divider = null
        lv.setBackgroundColor(T.bg)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = all.size
            override fun getItem(p: Int) = all[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, par: ViewGroup?): View {
                val f = all[p]
                val r = LinearLayout(this@FilesActivity)
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(4), dp(8), dp(4), dp(8))
                val iv = ImageView(this@FilesActivity)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                iv.setImageBitmap(null)
                ex.execute { val b = FileIcons.icon(f, 120, 140); ui.post { iv.setImageBitmap(b) } }
                r.addView(iv, lp(dp(44), dp(50), 0f, 0, 0, dp(12), 0))
                val c = LinearLayout(this@FilesActivity)
                c.orientation = LinearLayout.VERTICAL
                c.addView(txt(f.name, 16f).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                val info = if (f.isDirectory) ((f.list()?.size ?: 0).toString() + " items") else Formatter.formatShortFileSize(this@FilesActivity, f.length())
                c.addView(txt(DateUtils.formatDateTime(this@FilesActivity, f.lastModified(), DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_MONTH) + "  ·  " + info, 13f, T.sub))
                r.addView(c, lp(0, WRAP, 1f))
                if (f.isDirectory) r.addView(glyph("fwd", T.sub, 16), lp(dp(16), dp(16)))
                return r
            }
        }
        lv.setOnItemClickListener { _, _, p, _ ->
            val f = all[p]
            if (f.isDirectory) { dir = f; query = ""; show() } else if (f.extension.lowercase() == "zip") sheet(f.name, Act("Open") { open(f) }, Act("Extract Here") { extract(f) }) else open(f)
        }
        lv.setOnItemLongClickListener { _, _, p, _ -> menu(all[p]); true }
        col.addView(lv, lp(MATCH, 0, 1f))
        setContentView(col)
    }

    private fun open(f: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) { toast("No app can open this file") }
    }

    private fun menu(f: File) {
        sheet(f.name,
            Act("Copy") { clip = f; move = false; show() }, Act("Move") { clip = f; move = true; show() },
            Act("Rename") { prompt("Rename", "Name", f.name) { n -> if (n.isNotEmpty()) { f.renameTo(File(f.parentFile, n)); show() } } },
            Act("Compress") { zip(f) },
            Act("Share") { if (f.isFile) { val u = FileProvider.getUriForFile(this, "$packageName.files", f); startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("*/*").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share")) } else toast("Folders can't be shared") },
            Act("Get Info") { AlertDialog.Builder(this).setTitle(f.name).setMessage(f.path + "\n" + (if (f.isFile) Formatter.formatFileSize(this, f.length()) else "Folder") + "\n" + DateUtils.formatDateTime(this, f.lastModified(), DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME)).setPositiveButton("OK", null).show() },
            Act("Delete", true) { sheet("Delete ${f.name}?", Act("Delete", true) { f.deleteRecursively(); show() }) })
    }

    private fun paste(d: File) {
        val c = clip ?: return
        ex.execute {
            try {
                var t = File(d, c.name)
                var i = 1
                while (t.exists()) t = File(d, c.nameWithoutExtension + " $i" + (if (c.extension.isEmpty()) "" else "." + c.extension)).also { i++ }
                if (move) { if (!c.renameTo(t)) { c.copyRecursively(t); c.deleteRecursively() } } else c.copyRecursively(t)
                ui.post { clip = null; show() }
            } catch (e: Exception) { ui.post { toast("Paste failed") } }
        }
    }

    private fun zip(f: File) {
        ex.execute {
            try {
                val out = File(f.parentFile, f.nameWithoutExtension + ".zip")
                ZipOutputStream(FileOutputStream(out)).use { z ->
                    val base = f.parentFile!!.path.length + 1
                    for (x in (if (f.isDirectory) f.walkTopDown().filter { it.isFile }.toList() else listOf(f))) {
                        z.putNextEntry(ZipEntry(x.path.substring(base))); FileInputStream(x).use { it.copyTo(z) }; z.closeEntry()
                    }
                }
                ui.post { show() }
            } catch (e: Exception) { ui.post { toast("Compress failed") } }
        }
    }

    private fun extract(f: File) {
        ex.execute {
            try {
                val outDir = File(f.parentFile, f.nameWithoutExtension); outDir.mkdirs()
                ZipInputStream(FileInputStream(f)).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val t = File(outDir, e.name)
                        if (t.canonicalPath.startsWith(outDir.canonicalPath)) { if (e.isDirectory) t.mkdirs() else { t.parentFile?.mkdirs(); FileOutputStream(t).use { z.copyTo(it) } } }
                        e = z.nextEntry
                    }
                }
                ui.post { show() }
            } catch (e: Exception) { ui.post { toast("Extract failed") } }
        }
    }
}
