package com.pocketos

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.Spannable
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class Note(val id: String, var text: String, var folder: String, val created: Long, var mod: Long, var pinned: Boolean, var deleted: Long)

class NotesActivity : Base() {
    private var notes = ArrayList<Note>()
    private var folder = "All"
    private var query = ""
    private var cur: Note? = null
    private var editor: EditText? = null
    private val file get() = File(filesDir, "notes.json")

    override fun onCreate(b: Bundle?) { super.onCreate(b); prep(); load(); showFolders() }
    override fun onPause() { saveCur(); super.onPause() }

    private fun load() {
        notes.clear()
        try {
            val a = JSONArray(if (file.exists()) file.readText() else "[]")
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); notes.add(Note(o.getString("id"), o.getString("t"), o.optString("f", "Notes"), o.getLong("c"), o.getLong("m"), o.optBoolean("p"), o.optLong("d"))) }
        } catch (e: Exception) { }
        val cut = System.currentTimeMillis() - 30L * 86400000
        notes.removeAll { it.deleted in 1 until cut }
    }

    private fun persist() {
        val a = JSONArray()
        for (n in notes) a.put(JSONObject().put("id", n.id).put("t", n.text).put("f", n.folder).put("c", n.created).put("m", n.mod).put("p", n.pinned).put("d", n.deleted))
        file.writeText(a.toString())
    }

    private fun folders(): List<String> = (listOf("Notes") + Prefs(this).s("folders").split(",").filter { it.isNotEmpty() }).distinct()

    private fun showFolders() {
        cur = null
        setContentView(page {
            addView(navRow(null, glyphBtn("plus") { prompt("New Folder", "Name") { n -> if (n.isNotEmpty()) { Prefs(this@NotesActivity).put("folders", (folders() + n).distinct().filter { it != "Notes" }.joinToString(",")); showFolders() } } }))
            addView(largeTitle("Folders"))
            addView(searchBar("Search") { q -> query = q; if (q.isNotEmpty()) { folder = "All"; showList() } }, lp(MATCH, dp(44), 0f, 0, 0, 0, dp(8)))
            val g = Group(this@NotesActivity)
            val live = notes.filter { it.deleted == 0L }
            g.row("All Notes", live.size.toString(), iconTile("doc", T.orange), true) { folder = "All"; showList() }
            for (f in folders()) g.row(f, live.count { it.folder == f }.toString(), iconTile("folder", T.orange), true) { folder = f; showList() }
            addView(g, lp(MATCH, WRAP, 0f, 0, dp(8), 0, 0))
            val d = Group(this@NotesActivity)
            d.row("Recently Deleted", notes.count { it.deleted > 0 }.toString(), iconTile("trash", T.sub), true) { folder = "Deleted"; showList() }
            addView(d, lp(MATCH, WRAP, 0f, 0, dp(16), 0, 0))
        })
    }

    private fun title(n: Note) = n.text.lineSequence().firstOrNull { it.isNotBlank() }?.replace("☐ ", "")?.replace("☑ ", "")?.take(60) ?: "New Note"

    private fun bucket(n: Note): String {
        if (n.pinned) return "Pinned"
        val now = System.currentTimeMillis()
        val d = (now - n.mod) / 86400000
        val c = Calendar.getInstance(); c.timeInMillis = n.mod
        val t = Calendar.getInstance()
        return when {
            c.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR) && c.get(Calendar.YEAR) == t.get(Calendar.YEAR) -> "Today"
            d < 2 -> "Yesterday"
            d < 8 -> "Previous 7 Days"
            d < 31 -> "Previous 30 Days"
            else -> SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(n.mod)
        }
    }

    private fun showList() {
        saveCur(); cur = null; editor = null
        val deleted = folder == "Deleted"
        val list = notes.filter { (it.deleted > 0) == deleted && (folder == "All" || deleted || it.folder == folder) && (query.isEmpty() || it.text.contains(query, true)) }.sortedByDescending { it.mod }
        setContentView(page {
            addView(navRow(btn("‹ Folders") { query = ""; showFolders() }, if (deleted) null else glyphBtn("edit") { newNote() }))
            addView(largeTitle(if (folder == "All") "All Notes" else if (deleted) "Recently Deleted" else folder))
            if (list.isEmpty()) addView(txt("No notes", 15f, T.sub), lp(WRAP, WRAP, 0f, dp(4), dp(8), 0, 0))
            var last = ""
            var g: Group? = null
            for (n in list) {
                val b = bucket(n)
                if (b != last) { last = b; addView(section(b)); g = Group(this@NotesActivity); addView(g) }
                val r = LinearLayout(this@NotesActivity)
                r.orientation = LinearLayout.VERTICAL
                r.setPadding(dp(16), dp(10), dp(16), dp(10))
                r.addView(txt(title(n), 17f, T.label, true).apply { maxLines = 1 })
                r.addView(txt(SimpleDateFormat("d MMM", Locale.getDefault()).format(n.mod) + "  " + n.text.lineSequence().drop(1).joinToString(" ").take(70), 14f, T.sub).apply { maxLines = 1 })
                g!!.add(r, 16) { if (deleted) sheet(title(n), Act("Recover") { n.deleted = 0; persist(); showList() }, Act("Delete Forever", true) { notes.remove(n); persist(); showList() }) else openNote(n) }
                r.setOnLongClickListener {
                    if (!deleted) sheet(title(n), Act(if (n.pinned) "Unpin" else "Pin") { n.pinned = !n.pinned; persist(); showList() },
                        Act("Move to Folder") { sheet("Move to", *folders().map { f -> Act(f) { n.folder = f; persist(); showList() } }.toTypedArray()) },
                        Act("Delete", true) { n.deleted = System.currentTimeMillis(); persist(); showList() })
                    true
                }
            }
        })
    }

    private fun newNote() {
        val n = Note(System.currentTimeMillis().toString(), "", if (folder == "All" || folder == "Deleted") "Notes" else folder, System.currentTimeMillis(), System.currentTimeMillis(), false, 0)
        notes.add(n); openNote(n)
    }

    private fun style(e: Editable) {
        for (s in e.getSpans(0, e.length, Any::class.java)) if (s is RelativeSizeSpan || s is StyleSpan || s is StrikethroughSpan || s is ForegroundColorSpan) e.removeSpan(s)
        val nl = e.indexOf('\n').let { if (it < 0) e.length else it }
        if (nl > 0) { e.setSpan(RelativeSizeSpan(1.5f), 0, nl, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); e.setSpan(StyleSpan(Typeface.BOLD), 0, nl, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
        var pos = 0
        for (line in e.toString().split("\n")) {
            if (line.startsWith("☑ ")) { e.setSpan(StrikethroughSpan(), pos, pos + line.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); e.setSpan(ForegroundColorSpan(T.sub), pos, pos + line.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) }
            pos += line.length + 1
        }
    }

    private fun toggleLine(e: EditText, prefix: String) {
        val s = e.text.toString()
        val cur0 = e.selectionStart.coerceAtLeast(0)
        val st = s.lastIndexOf('\n', (cur0 - 1).coerceAtLeast(0)).let { if (it < 0 || (cur0 == 0)) 0 else it + 1 }
        val en = s.indexOf('\n', st).let { if (it < 0) s.length else it }
        val line = s.substring(st, en)
        val rep = when {
            prefix == "☐ " && line.startsWith("☐ ") -> "☑ " + line.drop(2)
            prefix == "☐ " && line.startsWith("☑ ") -> "☐ " + line.drop(2)
            line.startsWith(prefix) -> line.drop(prefix.length)
            else -> prefix + line
        }
        e.text.replace(st, en, rep)
    }

    private fun openNote(n: Note) {
        cur = n
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(T.bg)
        root.setPadding(dp(16), dp(8), dp(16), dp(8))
        val share = glyphBtn("share") { saveCur(); startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, n.text), "Share")) }
        val done = btn("Done", T.blue, true) { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(window.decorView.windowToken, 0); showList() }
        val top = navRow(btn("‹ ${if (folder == "All") "Notes" else folder}") { showList() }, null)
        top.addView(share); top.addView(done)
        root.addView(top)
        val e = EditText(this)
        e.setText(n.text)
        e.gravity = Gravity.TOP
        e.background = null
        e.textSize = 17f
        e.setTextColor(T.label)
        e.hint = "Start typing"
        e.setHintTextColor(T.sub)
        e.addTextChangedListener(object : TextWatcher {
            var before = 0
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { before = s?.length ?: 0 }
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s == null) return
                val c = e.selectionStart
                if (s.length == before + 1 && c > 0 && s[c - 1] == '\n') {
                    val prevStart = s.lastIndexOf('\n', c - 2).let { if (it < 0) 0 else it + 1 }
                    val prev = s.substring(prevStart, c - 1)
                    if (prev == "☐ " || prev == "☑ " || prev == "• ") s.delete(prevStart, c)
                    else if (prev.startsWith("☐ ") || prev.startsWith("☑ ")) s.insert(c, "☐ ")
                    else if (prev.startsWith("• ")) s.insert(c, "• ")
                }
                style(s)
            }
        })
        root.addView(e, lp(MATCH, 0, 1f))
        editor = e
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER
        bar.background = shape(T.card, dpf(14f))
        bar.addView(btn("☑ Checklist") { toggleLine(e, "☐ ") }, lp(0, WRAP, 1f))
        bar.addView(btn("• List") { toggleLine(e, "• ") }, lp(0, WRAP, 1f))
        bar.addView(btn(if (n.pinned) "Unpin" else "Pin") { n.pinned = !n.pinned; persist(); toast(if (n.pinned) "Pinned" else "Unpinned") }, lp(0, WRAP, 1f))
        bar.addView(btn("Words") { toast(e.text.split(Regex("\\s+")).count { it.isNotEmpty() }.toString() + " words, " + e.text.length + " characters") }, lp(0, WRAP, 1f))
        root.addView(bar, lp(MATCH, WRAP, 0f, 0, dp(4), 0, 0))
        setContentView(root)
        style(e.text)
    }

    private fun saveCur() {
        val n = cur ?: return
        val e = editor ?: return
        val t = e.text.toString()
        if (t.isBlank()) { notes.remove(n) } else if (t != n.text) { n.text = t; n.mod = System.currentTimeMillis() }
        persist()
    }
}
