package com.pocketos

import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class Alarm(val id: Int, var h: Int, var m: Int, var days: Int, var label: String, var on: Boolean)

object Alarms {
    fun all(c: Context): MutableList<Alarm> {
        val out = ArrayList<Alarm>()
        try {
            val a = JSONArray(Prefs(c).s("alarms", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Alarm(o.getInt("id"), o.getInt("h"), o.getInt("m"), o.getInt("d"), o.getString("l"), o.getBoolean("on")))
            }
        } catch (e: Exception) { }
        return out
    }

    fun save(c: Context, l: List<Alarm>) {
        val a = JSONArray()
        for (x in l) a.put(JSONObject().put("id", x.id).put("h", x.h).put("m", x.m).put("d", x.days).put("l", x.label).put("on", x.on))
        Prefs(c).put("alarms", a.toString())
    }

    fun next(a: Alarm): Long {
        val now = System.currentTimeMillis()
        for (add in 0..7) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, add)
            cal.set(Calendar.HOUR_OF_DAY, a.h); cal.set(Calendar.MINUTE, a.m); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            val dayBit = 1 shl (cal.get(Calendar.DAY_OF_WEEK) - 1)
            if (cal.timeInMillis > now && (a.days == 0 || (a.days and dayBit) != 0)) return cal.timeInMillis
        }
        return now + 86400000L
    }

    private fun pi(c: Context, code: Int, label: String, type: String): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).setAction("com.pocketos.ALARM").putExtra("id", code).putExtra("label", label).putExtra("type", type)
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun setAt(c: Context, code: Int, at: Long, label: String, type: String) {
        val am = c.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(c, 0, Intent(c, ClockActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, code, label, type))
    }

    fun cancelCode(c: Context, code: Int) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, code, "", "alarm"))
    }

    fun schedule(c: Context, a: Alarm) = setAt(c, a.id, next(a), a.label, "alarm")
    fun cancel(c: Context, a: Alarm) = cancelCode(c, a.id)
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        when (i.action) {
            "com.pocketos.ALARM" -> {
                val id = i.getIntExtra("id", 0)
                var label = i.getStringExtra("label") ?: "Alarm"
                if (i.getStringExtra("type") == "alarm") {
                    val list = Alarms.all(ctx)
                    val a = list.firstOrNull { it.id == id }
                    if (a != null) {
                        if (a.days == 0) a.on = false else Alarms.schedule(ctx, a)
                        Alarms.save(ctx, list)
                        label = if (a.label.isEmpty()) "Alarm" else a.label
                    }
                } else if (i.getStringExtra("type") == "timer") { Prefs(ctx).put("timer_end", "0"); label = "Timer" }
                val svc = Intent(ctx, AlarmService::class.java).putExtra("label", label)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(svc) else ctx.startService(svc)
            }
            "com.pocketos.SNOOZE" -> {
                ctx.stopService(Intent(ctx, AlarmService::class.java))
                Alarms.setAt(ctx, 9001, System.currentTimeMillis() + 9 * 60000L, i.getStringExtra("label") ?: "Alarm", "snooze")
            }
            "com.pocketos.STOP" -> ctx.stopService(Intent(ctx, AlarmService::class.java))
            Intent.ACTION_BOOT_COMPLETED -> Alarms.all(ctx).filter { it.on }.forEach { Alarms.schedule(ctx, it) }
        }
    }
}

class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val label = i?.getStringExtra("label") ?: "Alarm"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("alarm", "Alarms", NotificationManager.IMPORTANCE_HIGH))
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val full = PendingIntent.getActivity(this, 1, Intent(this, RingActivity::class.java).putExtra("label", label).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags)
        val snooze = PendingIntent.getBroadcast(this, 2, Intent(this, AlarmReceiver::class.java).setAction("com.pocketos.SNOOZE").putExtra("label", label), flags)
        val stop = PendingIntent.getBroadcast(this, 3, Intent(this, AlarmReceiver::class.java).setAction("com.pocketos.STOP"), flags)
        val n = Notification.Builder(this, "alarm").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(label).setContentText(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()))
            .setCategory(Notification.CATEGORY_ALARM).setOngoing(true).setFullScreenIntent(full, true).setContentIntent(full)
            .addAction(Notification.Action.Builder(null, "Snooze", snooze).build())
            .addAction(Notification.Action.Builder(null, "Stop", stop).build()).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(42, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(42, n)
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(this@AlarmService, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                isLooping = true
                prepare(); start()
            }
        } catch (e: Exception) { }
        try { getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0)) } catch (e: Exception) { }
        h.postDelayed({ stopSelf() }, 120000)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { player?.stop(); player?.release() } catch (e: Exception) { }
        try { getSystemService(Vibrator::class.java).cancel() } catch (e: Exception) { }
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}

class RingActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        val label = intent?.getStringExtra("label") ?: "Alarm"
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(dp(24), dp(24), dp(24), dp(24))
        root.addView(txt(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 72f, Color.WHITE, true))
        root.addView(txt(label, 22f, 0xFFFF9F0A.toInt()), lp(WRAP, WRAP, 0f, 0, dp(4), 0, dp(60)))
        val row = LinearLayout(this)
        row.addView(pill("Snooze", 0xFF333333.toInt()) {
            sendBroadcast(Intent(this, AlarmReceiver::class.java).setAction("com.pocketos.SNOOZE").putExtra("label", label)); finish()
        }, lp(0, dp(64), 1f, 0, 0, dp(8), 0))
        row.addView(pill("Stop", 0xFFFF9F0A.toInt()) {
            sendBroadcast(Intent(this, AlarmReceiver::class.java).setAction("com.pocketos.STOP")); finish()
        }, lp(0, dp(64), 1f, dp(8), 0, 0, 0))
        root.addView(row, lp(MATCH, WRAP))
        setContentView(root)
    }

    private fun pill(s: String, bg: Int, f: () -> Unit) = txt(s, 20f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER; background = shape(bg, dpf(32f)); setOnClickListener { f() }
    }
}
