package com.pocketos

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class DialerActivity : Base() {
    private lateinit var shell: Shell
    private var tab = 1
    private var query = ""
    private var contacts: List<Contact> = emptyList()
    private val num = StringBuilder()
    private var keypad: View? = null
    private lateinit var numView: TextView
    private lateinit var sugg: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        shell = Shell(this)
        intent?.data?.schemeSpecificPart?.let { num.append(it) }
        shell.tabs(listOf("star" to "Favorites", "clock" to "Recents", "person" to "Contacts"), tab) { tab = it; render() }
        setContentView(shell.root)
        val fab = circleBtn(T.blue, 60, glyph("keypad", Color.WHITE, 26)) { openKeypad() }
        fab.elevation = dpf(6f)
        shell.root.addView(fab, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(24), dp(104)) })
        ask(listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG)) { load() }
        if (num.isNotEmpty()) openKeypad()
    }

    override fun onResume() { super.onResume(); if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == 0) load() }

    private fun load() { contacts = Repo.contacts(this); render() }

    private fun render() {
        val sv = page {
            val search = searchBar("Search contacts") { q -> query = q; render2() }
            addView(search, lp(MATCH, dp(48), 0f, 0, dp(4), 0, dp(8)))
            addView(txt("", 1f))
            body(this)
        }
        shell.show(sv)
    }

    private fun render2() { render() }

    private fun body(col: LinearLayout) {
        if (query.isNotEmpty()) {
            val g = Group(this)
            contacts.filter { it.name.contains(query, true) || it.numbers.any { n -> n.contains(query) } }.take(50).forEach { c -> g.add(contactRow(c), 66) }
            col.addView(g)
            return
        }
        when (tab) {
            0 -> favorites(col)
            1 -> recents(col)
            else -> {
                val g = Group(this)
                contacts.forEach { c -> g.add(contactRow(c), 66) }
                if (contacts.isEmpty()) col.addView(txt("No contacts", 15f, T.sub)) else col.addView(g)
            }
        }
    }

    private fun contactRow(c: Contact): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(8), dp(16), dp(8))
        r.addView(avatar(c.name), lp(dp(40), dp(40), 0f, 0, 0, dp(12), 0))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(txt(c.name, 17f))
        col.addView(txt(c.numbers.firstOrNull() ?: "", 13f, T.sub))
        r.addView(col, lp(0, WRAP, 1f))
        r.onTap { if (c.numbers.size == 1) call(c.numbers[0]) else sheet(c.name, *c.numbers.map { n -> Act(n) { call(n) } }.toTypedArray()) }
        return r
    }

    private fun favorites(col: LinearLayout) {
        val fav = contacts.filter { it.starred }
        if (fav.isEmpty()) { col.addView(txt("Star contacts in Contacts to see them here.", 15f, T.sub), lp(WRAP, WRAP, 0f, dp(8), dp(24), 0, 0)); return }
        var row: LinearLayout? = null
        fav.forEachIndexed { i, c ->
            if (i % 3 == 0) { row = LinearLayout(this); col.addView(row, lp(MATCH, WRAP, 0f, 0, 0, 0, dp(16))) }
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            val a = avatar(c.name); a.textSize = 28f
            cell.addView(a, lp(dp(76), dp(76)))
            val n = txt(c.name, 13f, T.label); n.maxLines = 1; n.gravity = Gravity.CENTER
            cell.addView(n, lp(MATCH, WRAP, 0f, 0, dp(6), 0, 0))
            cell.onTap { if (c.numbers.isNotEmpty()) call(c.numbers[0]) }
            row?.addView(cell, lp(0, WRAP, 1f))
        }
    }

    private fun recents(col: LinearLayout) {
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != 0) { col.addView(txt("Allow call-log permission to see recents.", 15f, T.sub)); return }
        val g = Group(this)
        try {
            contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.CACHED_NAME),
                null, null, CallLog.Calls.DATE + " DESC LIMIT 100")?.use { q ->
                while (q.moveToNext()) {
                    val number = q.getString(0) ?: ""
                    val type = q.getInt(1)
                    val date = q.getLong(2)
                    val name = q.getString(3) ?: Repo.nameFor(this, number) ?: number.ifEmpty { "Unknown" }
                    val missed = type == CallLog.Calls.MISSED_TYPE || type == CallLog.Calls.REJECTED_TYPE
                    val r = LinearLayout(this)
                    r.gravity = Gravity.CENTER_VERTICAL
                    r.setPadding(dp(16), dp(8), dp(16), dp(8))
                    r.addView(avatar(name), lp(dp(40), dp(40), 0f, 0, 0, dp(12), 0))
                    val c2 = LinearLayout(this)
                    c2.orientation = LinearLayout.VERTICAL
                    c2.addView(txt(name, 17f, if (missed) T.red else T.label))
                    val kind = when (type) { CallLog.Calls.INCOMING_TYPE -> "Incoming"; CallLog.Calls.OUTGOING_TYPE -> "Outgoing"; CallLog.Calls.MISSED_TYPE -> "Missed"; else -> "Call" }
                    c2.addView(txt(kind, 13f, T.sub))
                    r.addView(c2, lp(0, WRAP, 1f))
                    r.addView(txt(DateUtils.getRelativeTimeSpanString(date, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(), 13f, T.sub))
                    g.add(r, 68) { call(number) }
                    r.setOnLongClickListener {
                        sheet(name, Act("Call") { call(number) }, Act("Message") { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))) },
                            Act("Copy number") { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("n", number)) })
                        true
                    }
                }
            }
        } catch (e: Exception) { }
        col.addView(g)
    }

    private fun call(n: String) {
        if (n.isEmpty()) return
        val uri = Uri.parse("tel:" + Uri.encode(n))
        ask(listOf(Manifest.permission.CALL_PHONE)) { try { startActivity(Intent(Intent.ACTION_CALL, uri)) } catch (e: Exception) { startActivity(Intent(Intent.ACTION_DIAL, uri)) } }
    }

    // ---------- Keypad (iPhone-style keys, standard dialer layout) ----------
    private val letters = mapOf('1' to "", '2' to "ABC", '3' to "DEF", '4' to "GHI", '5' to "JKL", '6' to "MNO", '7' to "PQRS", '8' to "TUV", '9' to "WXYZ", '0' to "+", '*' to "", '#' to "")

    private fun t9(name: String): String = name.uppercase().map { ch ->
        letters.entries.firstOrNull { it.value.contains(ch) && it.value.length > 1 }?.key ?: ch
    }.joinToString("")

    private fun openKeypad() {
        if (keypad != null) return
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(T.bg)
        root.setPadding(dp(16), dp(8), dp(16), dp(20))
        root.isClickable = true
        root.addView(navRow(null, glyphBtn("down", T.sub) { closeKeypad() }))
        sugg = LinearLayout(this)
        sugg.orientation = LinearLayout.VERTICAL
        root.addView(sugg, lp(MATCH, 0, 1f))
        numView = txt(num.toString(), 38f, T.label)
        numView.gravity = Gravity.CENTER
        numView.maxLines = 1
        root.addView(numView, lp(MATCH, WRAP, 0f, 0, dp(8), 0, dp(8)))
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
        val size = (resources.displayMetrics.widthPixels - dp(32) - dp(48)) / 3
        for (r in 0..3) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER
            for (k in 0..2) {
                val key = keys[r * 3 + k]
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER
                cell.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(T.fill) }
                cell.addView(txt(key, 32f, T.label))
                val sub = letters[key[0]] ?: ""
                if (sub.isNotEmpty()) cell.addView(txt(sub, 10f, T.label, true))
                cell.setOnClickListener { it.tap(); num.append(key); refreshKeypad() }
                if (key == "0") cell.setOnLongClickListener { num.append("+"); refreshKeypad(); true }
                row.addView(cell, lp(size, size, 0f, dp(8), dp(6), dp(8), dp(6)))
            }
            root.addView(row)
        }
        val bottom = LinearLayout(this)
        bottom.gravity = Gravity.CENTER
        bottom.addView(View(this), lp(size, size, 0f, dp(8), 0, dp(8), 0))
        bottom.addView(circleBtn(T.green, size / 1, glyph("call", Color.WHITE, 32)) { call(num.toString()) }, lp(size, size, 0f, dp(8), dp(6), dp(8), 0))
        val del = circleBtn(T.bg, size, glyph("close", T.sub, 28)) {
            if (num.isNotEmpty()) num.deleteCharAt(num.length - 1); refreshKeypad()
        }
        del.setOnLongClickListener { num.setLength(0); refreshKeypad(); true }
        bottom.addView(del, lp(size, size, 0f, dp(8), dp(6), dp(8), 0))
        root.addView(bottom)
        keypad = root
        shell.root.addView(root, FrameLayout.LayoutParams(MATCH, MATCH))
        refreshKeypad()
    }

    private fun closeKeypad() { keypad?.let { shell.root.removeView(it) }; keypad = null }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (keypad != null) closeKeypad() else super.onBackPressed() }

    private fun refreshKeypad() {
        numView.text = num.toString()
        sugg.removeAllViews()
        if (num.isEmpty()) return
        val q = num.toString()
        val hits = contacts.filter { c -> t9(c.name).contains(q) || c.numbers.any { n -> n.replace(" ", "").replace("-", "").contains(q) } }.take(3)
        for (c in hits) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(8), dp(6), dp(8), dp(6))
            r.addView(avatar(c.name), lp(dp(36), dp(36), 0f, 0, 0, dp(12), 0))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(txt(c.name, 16f)); col.addView(txt(c.numbers.firstOrNull() ?: "", 12f, T.sub))
            r.addView(col)
            r.onTap { num.setLength(0); num.append(c.numbers.firstOrNull() ?: ""); refreshKeypad() }
            sugg.addView(r)
        }
    }
}
