package com.pocketos

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout

class MainActivity : Activity() {
    private lateinit var prefs: Prefs

    override fun onCreate(b: Bundle?) { super.onCreate(b); prefs = Prefs(this) }
    override fun onResume() { super.onResume(); build() }

    private fun safe(i: Intent) { try { startActivity(i) } catch (e: Exception) { toast("Not available on this device") } }

    private fun build() {
        prep()
        setContentView(page {
            addView(largeTitle("PocketOS"))
            addView(section("Apps"))
            val g = Group(this@MainActivity)
            for (a in IconFactory.apps) {
                if (a.id == "hub") continue
                val iv = ImageView(this@MainActivity)
                iv.setImageBitmap(IconFactory.appIcon(this@MainActivity, a.id, prefs.pack, dp(60)))
                g.row(a.label, null, iv, true) { openApp(a.cls) }
            }
            addView(g)

            addView(section("Icon Pack"))
            val ip = Group(this@MainActivity)
            for (p in IconFactory.packs) {
                val r = LinearLayout(this@MainActivity)
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(16), dp(10), dp(16), dp(10))
                for (id in listOf("dialer", "messages", "camera", "calc")) {
                    val iv = ImageView(this@MainActivity); iv.setImageBitmap(IconFactory.appIcon(this@MainActivity, id, p.id, dp(44)))
                    r.addView(iv, lp(dp(44), dp(44), 0f, 0, 0, dp(8), 0))
                }
                r.addView(txt(p.name, 17f, T.label, true), lp(0, WRAP, 1f, dp(8), 0, 0, 0))
                if (p.id == prefs.pack) r.addView(glyph("check", T.blue, 22), lp(dp(22), dp(22)))
                ip.add(r, 16) { prefs.pack = p.id; build() }
            }
            addView(ip)
            val pin = Group(this@MainActivity)
            pin.row("Pin all icons to home screen", null, null, true, T.blue) { IconFactory.apps.forEach { Shortcuts.pinApp(this@MainActivity, it, prefs.pack) } }
            addView(pin, lp(MATCH, WRAP, 0f, 0, dp(10), 0, 0))
            addView(txt("PocketOS Launcher applies the pack to every icon instantly. Other launchers use pinned shortcuts.", 12f, T.sub), lp(MATCH, WRAP, 0f, dp(16), dp(6), dp(16), 0))

            addView(section("Web Apps"))
            val w = Group(this@MainActivity)
            val urlEt = EditText(this@MainActivity); urlEt.hint = "https://example.com"; urlEt.setSingleLine(); urlEt.background = null
            urlEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI; urlEt.setPadding(dp(16), dp(14), dp(16), dp(14)); urlEt.setTextColor(T.label); urlEt.setHintTextColor(T.sub)
            val nameEt = EditText(this@MainActivity); nameEt.hint = "Name (optional)"; nameEt.setSingleLine(); nameEt.background = null
            nameEt.setPadding(dp(16), dp(14), dp(16), dp(14)); nameEt.setTextColor(T.label); nameEt.setHintTextColor(T.sub)
            w.add(urlEt); w.add(nameEt)
            w.row("Create App", null, null, false, T.blue) { createWeb(urlEt.text.toString(), nameEt.text.toString()) }
            for ((t, u) in prefs.webApps()) {
                val r = w.row(t, Uri.parse(u).host, null, false, T.label) { startActivity(Shortcuts.webIntent(this@MainActivity, t, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                r.setOnLongClickListener { sheet(t, Act("Pin to Home Screen") { pinWeb(t, u) }, Act("Remove", true) { prefs.removeWeb(u); build() }); true }
            }
            addView(w)

            addView(section("System"))
            val s = Group(this@MainActivity)
            s.row("Set PocketOS Launcher as Home", null, iconTile("grid", T.blue), true) { safe(Intent(Settings.ACTION_HOME_SETTINGS)) }
            s.row("Default Apps (Phone, SMS)", null, iconTile("phone", T.green), true) { safe(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
            s.row("Recent Apps Access", null, iconTile("clock", T.orange), true) { safe(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            s.row("Control Center", null, iconTile("sliders", T.sub), true) { openApp(ControlCenterActivity::class.java) }
            s.row("Recents", null, iconTile("tabs", T.red), true) { openApp(RecentsActivity::class.java) }
            addView(s)
        })
    }

    private fun createWeb(rawUrl: String, rawName: String) {
        var u = rawUrl.trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
        val host = Uri.parse(u).host
        if (host.isNullOrEmpty()) { toast("Invalid URL"); return }
        val name = rawName.trim().ifEmpty { host.removePrefix("www.").substringBeforeLast('.').replaceFirstChar { it.uppercase() } }
        prefs.addWeb(name, u)
        pinWeb(name, u)
    }

    private fun pinWeb(name: String, u: String) {
        val host = Uri.parse(u).host ?: return
        Thread {
            val fav = Shortcuts.favicon(host)
            runOnUiThread { Shortcuts.pinWeb(this, name, u, IconFactory.webIcon(name, fav, prefs.pack, 192)); build() }
        }.start()
    }
}
