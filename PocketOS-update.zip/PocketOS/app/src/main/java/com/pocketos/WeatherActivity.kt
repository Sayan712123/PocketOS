package com.pocketos

import android.Manifest
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale

class WxIcon(c: Context, val code: Int, val day: Boolean) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun cloud(cv: Canvas, w: Float, h: Float, col: Int) {
        p.style = Paint.Style.FILL; p.color = col
        cv.drawCircle(w * .38f, h * .55f, h * .2f, p); cv.drawCircle(w * .6f, h * .48f, h * .26f, p)
        cv.drawRoundRect(RectF(w * .2f, h * .52f, w * .82f, h * .76f), h * .12f, h * .12f, p)
    }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val clear = code == 0; val part = code in 1..2
        if (clear || part) {
            p.style = Paint.Style.FILL; p.color = if (day) 0xFFFFD60A.toInt() else 0xFFE5E5EA.toInt()
            cv.drawCircle(if (part) w * .36f else w * .5f, if (part) h * .36f else h * .5f, w * .2f, p)
        }
        if (clear) return
        val grey = if (code == 3 || code in 45..48 || code >= 51) 0xFFE5E5EA.toInt() else Color.WHITE
        cloud(cv, w, h, grey)
        p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = w * .05f
        if (code in 51..67 || code in 80..82 || code >= 95) { p.color = 0xFF64D2FF.toInt(); p.style = Paint.Style.STROKE; for (i in 0..2) cv.drawLine(w * (.32f + i * .17f), h * .8f, w * (.28f + i * .17f), h * .92f, p) }
        if (code in 71..77 || code in 85..86) { p.style = Paint.Style.FILL; p.color = Color.WHITE; for (i in 0..2) cv.drawCircle(w * (.32f + i * .17f), h * .87f, w * .035f, p) }
        if (code >= 95) { p.style = Paint.Style.FILL; p.color = 0xFFFFD60A.toInt(); cv.drawRect(w * .46f, h * .72f, w * .54f, h * .9f, p) }
        if (code in 45..48) { p.style = Paint.Style.STROKE; p.color = Color.WHITE; for (i in 0..1) cv.drawLine(w * .2f, h * (.82f + i * .08f), w * .8f, h * (.82f + i * .08f), p) }
    }
}

class WeatherActivity : Base() {
    private var celsius = true
    private lateinit var prefs: Prefs
    private var data: JSONObject? = null
    private var city = ""

    private fun cities(): MutableList<Triple<String, Double, Double>> =
        prefs.s("wx_cities").split("\n").filter { it.contains("|") }.mapNotNull { l -> val p = l.split("|"); if (p.size == 3) Triple(p[0], p[1].toDouble(), p[2].toDouble()) else null }.toMutableList()
    private fun saveCities(l: List<Triple<String, Double, Double>>) = prefs.put("wx_cities", l.joinToString("\n") { "${it.first}|${it.second}|${it.third}" })

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        celsius = prefs.s("wx_unit", "C") == "C"
        window.statusBarColor = 0xFF2C6FB7.toInt(); window.navigationBarColor = 0xFF2C6FB7.toInt()
        setContentView(txt("Loading…", 17f, T.sub).apply { gravity = Gravity.CENTER })
        val l = cities()
        if (l.isNotEmpty()) fetch(l[0]) else if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == 0) locate() else addCity()
    }

    private fun locate() {
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
            if (loc != null) { val c = Triple("My Location", loc.latitude, loc.longitude); saveCities(listOf(c)); fetch(c); return }
        } catch (e: Exception) { }
        addCity()
    }

    private fun http(u: String): String? = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.inputStream.bufferedReader().use { it.readText() }
    } catch (e: Exception) { null }

    private fun fetch(c: Triple<String, Double, Double>) {
        city = c.first
        Thread {
            val j = http("https://api.open-meteo.com/v1/forecast?latitude=${c.second}&longitude=${c.third}&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day,pressure_msl" +
                "&hourly=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max&timezone=auto&forecast_days=7")
            runOnUiThread { if (j == null) { toast("No internet"); setContentView(txt("Can't load weather", 17f, T.sub).apply { gravity = Gravity.CENTER; setOnClickListener { fetch(c) } }) } else { data = JSONObject(j); render() } }
        }.start()
    }

    private fun addCity() {
        prompt("Add City", "City name") { q ->
            if (q.isEmpty()) return@prompt
            Thread {
                val j = http("https://geocoding-api.open-meteo.com/v1/search?count=6&name=" + URLEncoder.encode(q, "UTF-8"))
                runOnUiThread {
                    val r = try { JSONObject(j ?: "{}").optJSONArray("results") } catch (e: Exception) { null }
                    if (r == null || r.length() == 0) { toast("City not found"); return@runOnUiThread }
                    val acts = (0 until r.length()).map { i ->
                        val o = r.getJSONObject(i)
                        Act(o.getString("name") + ", " + o.optString("country", "")) {
                            val l = cities(); val c = Triple(o.getString("name"), o.getDouble("latitude"), o.getDouble("longitude")); l.add(0, c); saveCities(l.distinctBy { it.first }); fetch(c)
                        }
                    }
                    sheet("Choose", *acts.toTypedArray())
                }
            }.start()
        }
    }

    private fun temp(c: Double): String = Math.round(if (celsius) c else c * 9 / 5 + 32).toString() + "°"

    private fun cond(code: Int) = when (code) {
        0 -> "Clear"; 1 -> "Mostly Clear"; 2 -> "Partly Cloudy"; 3 -> "Overcast"; 45, 48 -> "Fog"; in 51..57 -> "Drizzle"; in 61..67 -> "Rain"
        in 71..77 -> "Snow"; in 80..82 -> "Showers"; 85, 86 -> "Snow Showers"; in 95..99 -> "Thunderstorm"; else -> "—"
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = shape(0x33FFFFFF, dpf(18f))
    }

    private fun render() {
        val d = data ?: return
        val cur = d.getJSONObject("current")
        val code = cur.getInt("weather_code"); val day = cur.getInt("is_day") == 1
        val top = if (day) (if (code >= 51) 0xFF5C6B7A else 0xFF2C6FB7) else 0xFF0B1A33
        val bot = if (day) (if (code >= 51) 0xFF8FA0B0 else 0xFF6FB4F0) else 0xFF2A3F66
        window.statusBarColor = top.toInt(); window.navigationBarColor = bot.toInt()
        val sv = ScrollView(this)
        sv.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top.toInt(), bot.toInt()))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(24), dp(16), dp(32))
        sv.addView(col)
        val daily = d.getJSONObject("daily")
        val nav = navRow(btn("°" + if (celsius) "C" else "F", Color.WHITE, true) { celsius = !celsius; prefs.put("wx_unit", if (celsius) "C" else "F"); render() }, null)
        nav.addView(glyphBtn("plus", Color.WHITE) { addCity() })
        nav.addView(glyphBtn("list", Color.WHITE) {
            val l = cities()
            sheet("Cities", *l.map { c -> Act(c.first) { fetch(c) } }.toTypedArray(), Act("Use my location") { ask(listOf(Manifest.permission.ACCESS_COARSE_LOCATION)) { locate() } }, Act("Remove current", true) { saveCities(cities().filter { it.first != city }); val n = cities(); if (n.isNotEmpty()) fetch(n[0]) else addCity() })
        })
        col.addView(nav)
        col.addView(txt(city, 32f, Color.WHITE).apply { gravity = Gravity.CENTER })
        col.addView(txt(temp(cur.getDouble("temperature_2m")), 96f, Color.WHITE).apply { gravity = Gravity.CENTER })
        col.addView(txt(cond(code), 20f, Color.WHITE).apply { gravity = Gravity.CENTER })
        col.addView(txt("H:" + temp(daily.getJSONArray("temperature_2m_max").getDouble(0)) + "  L:" + temp(daily.getJSONArray("temperature_2m_min").getDouble(0)), 18f, Color.WHITE).apply { gravity = Gravity.CENTER }, lp(MATCH, WRAP, 0f, 0, 0, 0, dp(16)))

        val hc = card()
        hc.addView(txt("HOURLY FORECAST", 12f, 0xCCFFFFFF.toInt()))
        val hs = HorizontalScrollView(this); hs.isHorizontalScrollBarEnabled = false
        val hr = LinearLayout(this)
        val ht = d.getJSONObject("hourly"); val times = ht.getJSONArray("time"); val tt = ht.getJSONArray("temperature_2m"); val hcodes = ht.getJSONArray("weather_code")
        val nowStr = cur.getString("time").take(13)
        var start = 0
        for (i in 0 until times.length()) if (times.getString(i).take(13) == nowStr) { start = i; break }
        for (i in start until minOf(start + 24, times.length())) {
            val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.CENTER; c.setPadding(dp(8), dp(8), dp(8), 0)
            c.addView(txt(if (i == start) "Now" else times.getString(i).substring(11, 13), 14f, Color.WHITE))
            c.addView(WxIcon(this, hcodes.getInt(i), day), lp(dp(34), dp(34), 0f, 0, dp(6), 0, dp(6)))
            c.addView(txt(temp(tt.getDouble(i)), 16f, Color.WHITE, true))
            hr.addView(c)
        }
        hs.addView(hr); hc.addView(hs)
        col.addView(hc, lp(MATCH, WRAP, 0f, 0, 0, 0, dp(12)))

        val dc = card()
        dc.addView(txt("7-DAY FORECAST", 12f, 0xCCFFFFFF.toInt()))
        val dt = daily.getJSONArray("time"); val mx = daily.getJSONArray("temperature_2m_max"); val mn = daily.getJSONArray("temperature_2m_min"); val dcodes = daily.getJSONArray("weather_code")
        var lo = 100.0; var hi = -100.0
        for (i in 0 until dt.length()) { lo = Math.min(lo, mn.getDouble(i)); hi = Math.max(hi, mx.getDouble(i)) }
        for (i in 0 until dt.length()) {
            val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(0, dp(6), 0, dp(6))
            val dn = if (i == 0) "Today" else SimpleDateFormat("EEE", Locale.getDefault()).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dt.getString(i))!!)
            r.addView(txt(dn, 17f, Color.WHITE), lp(dp(60), WRAP))
            r.addView(WxIcon(this, dcodes.getInt(i), true), lp(dp(30), dp(30), 0f, 0, 0, dp(8), 0))
            r.addView(txt(temp(mn.getDouble(i)), 17f, 0xCCFFFFFF.toInt()), lp(dp(44), WRAP))
            val bar = FrameBar(this, ((mn.getDouble(i) - lo) / (hi - lo + 0.001)).toFloat(), ((mx.getDouble(i) - lo) / (hi - lo + 0.001)).toFloat())
            r.addView(bar, lp(0, dp(6), 1f, dp(4), 0, dp(4), 0))
            r.addView(txt(temp(mx.getDouble(i)), 17f, Color.WHITE, true), lp(dp(44), WRAP))
            dc.addView(r)
        }
        col.addView(dc, lp(MATCH, WRAP, 0f, 0, 0, 0, dp(12)))

        val sunrise = daily.getJSONArray("sunrise").getString(0).takeLast(5); val sunset = daily.getJSONArray("sunset").getString(0).takeLast(5)
        val tiles = listOf(
            "FEELS LIKE" to temp(cur.getDouble("apparent_temperature")), "HUMIDITY" to cur.getInt("relative_humidity_2m").toString() + "%",
            "WIND" to Math.round(cur.getDouble("wind_speed_10m")).toString() + " km/h", "UV INDEX" to Math.round(daily.getJSONArray("uv_index_max").getDouble(0)).toString(),
            "PRESSURE" to Math.round(cur.getDouble("pressure_msl")).toString() + " hPa", "SUN" to "↑ $sunrise  ↓ $sunset"
        )
        for (r in tiles.chunked(2)) {
            val row = LinearLayout(this)
            for (t in r) { val c = card(); c.addView(txt(t.first, 12f, 0xCCFFFFFF.toInt())); c.addView(txt(t.second, 24f, Color.WHITE)); row.addView(c, lp(0, WRAP, 1f, dp(4), dp(4), dp(4), dp(4))) }
            col.addView(row)
        }
        setContentView(sv)
    }
}

class FrameBar(c: Context, val a: Float, val b: Float) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val h = height.toFloat(); val w = width.toFloat()
        p.color = 0x33FFFFFF; cv.drawRoundRect(RectF(0f, 0f, w, h), h / 2, h / 2, p)
        p.color = 0xFFFFD60A.toInt(); cv.drawRoundRect(RectF(w * a, 0f, Math.max(w * b, w * a + h), h), h / 2, h / 2, p)
    }
}
