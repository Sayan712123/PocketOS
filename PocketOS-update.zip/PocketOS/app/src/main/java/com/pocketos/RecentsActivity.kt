package com.pocketos

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout

class RecentsActivity : Base() {
    private fun granted(): Boolean {
        val ops = getSystemService(AppOpsManager::class.java)
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    override fun onResume() { super.onResume(); build() }

    private fun build() {
        window.statusBarColor = Color.TRANSPARENT
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(0xEE000000.toInt())
        root.setOnClickListener { finish() }
        if (!granted()) {
            root.addView(txt("Allow usage access to show recent apps", 17f, Color.WHITE).apply { gravity = Gravity.CENTER })
            root.addView(btn("Open Settings", Color.WHITE, true) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }.apply { background = shape(T.blue, dpf(12f)); gravity = Gravity.CENTER }, lp(WRAP, WRAP, 0f, 0, dp(16), 0, 0))
            setContentView(root)
            return
        }
        val pm = packageManager
        val us = getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val hidden = Prefs(this).s("recents_hidden").split(",").toSet()
        val launchable = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).map { it.activityInfo.packageName }.toSet()
        val recent = (us.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 3 * 86400000L, now) ?: emptyList())
            .filter { it.lastTimeUsed > 0 && it.packageName in launchable && it.packageName != packageName && it.packageName !in hidden }
            .sortedByDescending { it.lastTimeUsed }.distinctBy { it.packageName }.take(12)
        if (recent.isEmpty()) { root.addView(txt("No recent apps", 17f, Color.WHITE)); setContentView(root); return }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.setPadding(dp(24), 0, dp(24), 0)
        val w = (resources.displayMetrics.widthPixels * 0.62f).toInt()
        for (s in recent) {
            val ai = try { pm.getApplicationInfo(s.packageName, 0) } catch (e: PackageManager.NameNotFoundException) { continue }
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER
            card.background = shape(0xFF1C1C1E.toInt(), dpf(28f))
            val iv = ImageView(this)
            iv.setImageBitmap(IconFactory.masked(ai.loadIcon(pm), Prefs(this).pack, dp(96)))
            card.addView(iv, lp(dp(96), dp(96)))
            card.addView(txt(ai.loadLabel(pm).toString(), 16f, Color.WHITE, true), lp(WRAP, WRAP, 0f, 0, dp(12), 0, 0))
            var y0 = 0f
            card.setOnTouchListener { v, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> y0 = ev.rawY
                    MotionEvent.ACTION_UP -> {
                        if (y0 - ev.rawY > dp(80)) { Prefs(this).put("recents_hidden", (hidden + s.packageName).joinToString(",")); build() }
                        else if (Math.abs(y0 - ev.rawY) < dp(10)) { v.performClick(); startActivity(pm.getLaunchIntentForPackage(s.packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); finish() }
                    }
                }
                true
            }
            row.addView(card, lp(w, (w * 1.6f).toInt(), 0f, dp(8), 0, dp(8), 0))
        }
        hs.addView(row)
        root.addView(hs, lp(MATCH, WRAP))
        root.addView(txt("Swipe a card up to remove it", 13f, 0xFF8E8E93.toInt()), lp(WRAP, WRAP, 0f, 0, dp(16), 0, 0))
        root.addView(btn("Clear All", Color.WHITE, true) { Prefs(this).put("recents_hidden", recent.joinToString(",") { it.packageName }); build() }, lp(WRAP, WRAP, 0f, 0, dp(8), 0, 0))
        setContentView(root)
    }
}
