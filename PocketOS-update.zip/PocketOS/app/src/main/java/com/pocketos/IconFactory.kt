package com.pocketos

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import java.util.Calendar

object IconFactory {
    class Pack(val id: String, val name: String, val mode: Int)
    class AppDef(val id: String, val label: String, val res: Int, val cls: Class<*>)

    val packs = listOf(Pack("default", "Default", 0), Pack("dark", "Dark", 1), Pack("mono", "Mono", 2), Pack("tint", "Tinted", 3))

    val apps = listOf(
        AppDef("dialer", "Phone", R.drawable.ic_dialer, DialerActivity::class.java),
        AppDef("messages", "Messages", R.drawable.ic_messages, MessagesActivity::class.java),
        AppDef("contacts", "Contacts", R.drawable.ic_contacts, ContactsActivity::class.java),
        AppDef("camera", "Camera", R.drawable.ic_camera, CameraActivity::class.java),
        AppDef("gallery", "Photos", R.drawable.ic_gallery, GalleryActivity::class.java),
        AppDef("calendar", "Calendar", R.drawable.ic_calendar, CalendarActivity::class.java),
        AppDef("clock", "Clock", R.drawable.ic_clock, ClockActivity::class.java),
        AppDef("weather", "Weather", R.drawable.ic_weather, WeatherActivity::class.java),
        AppDef("notes", "Notes", R.drawable.ic_notes, NotesActivity::class.java),
        AppDef("music", "Music", R.drawable.ic_music, MusicActivity::class.java),
        AppDef("recorder", "Recorder", R.drawable.ic_recorder, RecorderActivity::class.java),
        AppDef("compass", "Compass", R.drawable.ic_compass, CompassActivity::class.java),
        AppDef("browser", "Browser", R.drawable.ic_browser, BrowserActivity::class.java),
        AppDef("calc", "Calculator", R.drawable.ic_calc, CalculatorActivity::class.java),
        AppDef("files", "Files", R.drawable.ic_files, FilesActivity::class.java),
        AppDef("hub", "PocketOS", R.drawable.ic_hub, MainActivity::class.java)
    )

    fun pack(id: String): Pack = packs.firstOrNull { it.id == id } ?: packs[0]

    private fun squircle(s: Float): Path = Path().apply { addRoundRect(RectF(0f, 0f, s, s), s * 0.2344f, s * 0.2344f, Path.Direction.CW) }

    private fun matrix(mode: Int): ColorMatrix = when (mode) {
        1 -> ColorMatrix(floatArrayOf(.55f, 0f, 0f, 0f, 0f, 0f, .55f, 0f, 0f, 0f, 0f, 0f, .6f, 0f, 0f, 0f, 0f, 0f, 1f, 0f))
        2 -> ColorMatrix().apply { setSaturation(0f) }
        else -> ColorMatrix().apply { setSaturation(0f); postConcat(ColorMatrix(floatArrayOf(.45f, 0f, 0f, 0f, 0f, 0f, .62f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f, 0f))) }
    }

    private fun filtered(src: Bitmap, mode: Int): Bitmap {
        if (mode == 0) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.colorFilter = ColorMatrixColorFilter(matrix(mode))
        Canvas(out).drawBitmap(src, 0f, 0f, p)
        return out
    }

    fun appIcon(ctx: Context, id: String, packId: String, size: Int): Bitmap {
        val app = apps.first { it.id == id }
        val base = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(base)
        if (id == "calendar") {
            val d = ctx.getDrawable(R.drawable.ic_calendar_base)!!
            d.setBounds(0, 0, size, size); d.draw(c)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = 0xFF1C1C1E.toInt(); p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = size * 0.46f
            c.drawText(Calendar.getInstance().get(Calendar.DAY_OF_MONTH).toString(), size / 2f, size * 0.82f, p)
        } else {
            val d = ctx.getDrawable(app.res)!!
            d.setBounds(0, 0, size, size); d.draw(c)
        }
        return filtered(base, pack(packId).mode)
    }

    fun webIcon(title: String, fav: Bitmap?, packId: String, size: Int): Bitmap {
        val s = size.toFloat()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val palette = intArrayOf(0xFF0A84FF.toInt(), 0xFF34C759.toInt(), 0xFFFF9F0A.toInt(), 0xFFFF375F.toInt(), 0xFF5E5CE6.toInt(), 0xFF30B0C7.toInt())
        val col = palette[(title.hashCode() and 0x7fffffff) % palette.size]
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = if (fav != null) Color.WHITE else col
        c.drawPath(squircle(s), paint)
        if (fav != null) {
            val d = s * 0.58f
            c.drawBitmap(fav, null, RectF((s - d) / 2, (s - d) / 2, (s + d) / 2, (s + d) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            val t = Paint(Paint.ANTI_ALIAS_FLAG)
            t.color = Color.WHITE; t.textSize = s * 0.5f; t.textAlign = Paint.Align.CENTER; t.isFakeBoldText = true
            c.drawText(title.take(1).uppercase(), s / 2, s / 2 - (t.ascent() + t.descent()) / 2, t)
        }
        return filtered(bmp, pack(packId).mode)
    }

    fun masked(d: Drawable, packId: String, size: Int): Bitmap {
        val tmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(tmp)
        if (d is AdaptiveIconDrawable) {
            val o = (size * 0.25f).toInt()
            d.background?.let { it.setBounds(-o, -o, size + o, size + o); it.draw(cv) }
            d.foreground?.let { it.setBounds(-o, -o, size + o, size + o); it.draw(cv) }
        } else {
            cv.drawColor(Color.WHITE)
            val i = (size * 0.12f).toInt()
            d.setBounds(i, i, size - i, size - i); d.draw(cv)
        }
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = BitmapShader(tmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        Canvas(out).drawPath(squircle(size.toFloat()), paint)
        return filtered(out, pack(packId).mode)
    }
}
