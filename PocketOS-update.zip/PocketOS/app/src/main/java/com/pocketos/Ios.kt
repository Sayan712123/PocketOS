package com.pocketos

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.graphics.PathParser

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object T {
    var dark = false
    fun init(c: Context) { dark = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES }
    val bg: Int get() = if (dark) 0xFF000000.toInt() else 0xFFF2F2F7.toInt()
    val card: Int get() = if (dark) 0xFF1C1C1E.toInt() else 0xFFFFFFFF.toInt()
    val label: Int get() = if (dark) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
    val sub: Int get() = 0xFF8E8E93.toInt()
    val sep: Int get() = if (dark) 0xFF38383A.toInt() else 0xFFD1D1D6.toInt()
    val fill: Int get() = if (dark) 0xFF2C2C2E.toInt() else 0xFFE5E5EA.toInt()
    val blue: Int get() = if (dark) 0xFF0A84FF.toInt() else 0xFF007AFF.toInt()
    val green: Int get() = if (dark) 0xFF30D158.toInt() else 0xFF34C759.toInt()
    val red: Int get() = if (dark) 0xFFFF453A.toInt() else 0xFFFF3B30.toInt()
    val orange: Int get() = if (dark) 0xFFFF9F0A.toInt() else 0xFFFF9500.toInt()
    val glass: Int get() = if (dark) 0xE62C2C2E.toInt() else 0xE6F9F9F9.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun shape(color: Int, r: Float): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = r }
fun lp(w: Int, h: Int, wt: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h, wt).apply { setMargins(l, t, r, b) }
fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
fun Context.openApp(cls: Class<*>) { startActivity(Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
fun View.tap() { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

fun Context.txt(s: CharSequence, size: Float = 17f, color: Int = T.label, bold: Boolean = false): TextView =
    TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }

fun Context.ripple(): Drawable? {
    val a = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground))
    val d = a.getDrawable(0)
    a.recycle()
    return d
}

fun View.onTap(f: () -> Unit) { isClickable = true; foreground = context.ripple(); setOnClickListener { f() } }

fun Activity.prep() {
    T.init(this)
    window.statusBarColor = T.bg
    window.navigationBarColor = T.bg
    @Suppress("DEPRECATION")
    window.decorView.systemUiVisibility = if (T.dark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
    window.decorView.setBackgroundColor(T.bg)
}

open class Base : Activity() {
    private var pending: (() -> Unit)? = null
    fun ask(perms: List<String>, ok: () -> Unit) {
        val miss = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isEmpty()) ok() else { pending = ok; requestPermissions(miss.toTypedArray(), 99) }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = pending
        pending = null
        if (ok != null) { if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) ok() else toast("Permission needed") }
    }
}

fun mediaPerms(): List<String> =
    if (Build.VERSION.SDK_INT >= 33) listOf("android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO")
    else listOf("android.permission.READ_EXTERNAL_STORAGE")

// ---------- Glyphs (24x24 stroke icons) ----------
object Glyphs {
    val FILLED = setOf("play", "pause", "next", "prev", "keypad", "more", "starf")
    private fun dot(cx: Float, cy: Float, r: Float = 1.8f) = "M${cx - r},${cy}a$r,$r 0 1,0 ${2 * r},0a$r,$r 0 1,0 ${-2 * r},0Z"
    private val D: Map<String, String> = mapOf(
        "back" to "M15,5L8,12L15,19", "fwd" to "M9,5L16,12L9,19", "down" to "M5,9L12,16L19,9",
        "up" to "M12,19V5M6,11L12,5L18,11", "plus" to "M12,5V19M5,12H19", "close" to "M6,6L18,18M18,6L6,18",
        "check" to "M5,12.5L10,17.5L19,7",
        "search" to "M4.5,11a6.5,6.5 0 1,0 13,0a6.5,6.5 0 1,0 -13,0M16,16L20.5,20.5",
        "star" to "M12,3L14.6,9L21,9.6L16.2,13.8L17.7,20L12,16.7L6.3,20L7.8,13.8L3,9.6L9.4,9Z",
        "starf" to "M12,3L14.6,9L21,9.6L16.2,13.8L17.7,20L12,16.7L6.3,20L7.8,13.8L3,9.6L9.4,9Z",
        "clock" to "M3,12a9,9 0 1,0 18,0a9,9 0 1,0 -18,0M12,7V12L15.5,14",
        "person" to "M5,20Q5,14 12,14Q19,14 19,20M8,8a4,4 0 1,0 8,0a4,4 0 1,0 -8,0",
        "phone" to "M6.5,3.5H10L11.8,8L9.5,9.8Q11.2,13.8 14.2,14.5L16,12.3L20.5,14.2V17.5Q20.5,20.5 17.5,20.5Q5,19.5 3.5,6.5Q3.5,3.5 6.5,3.5Z",
        "trash" to "M4,7H20M9,7V4H15V7M6.5,7L7.5,20H16.5L17.5,7",
        "share" to "M12,15V3M8,7L12,3L16,7M6,11H5V21H19V11H18",
        "doc" to "M6,3H14L19,8V21H6ZM14,3V8H19", "folder" to "M3,6H10L12,8H21V19H3Z",
        "list" to "M8,6H20M8,12H20M8,18H20M4,6V6.1M4,12V12.1M4,18V18.1",
        "gridview" to "M4,4H10V10H4ZM14,4H20V10H14ZM4,14H10V20H4ZM14,14H20V20H14Z",
        "play" to "M7,4L19,12L7,20Z", "pause" to "M7,5H11V19H7ZM13,5H17V19H13Z",
        "next" to "M6,5L15,12L6,19ZM17,5H19V19H17Z", "prev" to "M18,5L9,12L18,19ZM5,5H7V19H5Z",
        "shuffle" to "M3,7H7L17,17H21M3,17H7L10,14M14,10L17,7H21M18,4L21,7L18,10M18,14L21,17L18,20",
        "repeat" to "M4,11V9Q4,7 6,7H19M16,4L19,7L16,10M20,13V15Q20,17 18,17H5M8,14L5,17L8,20",
        "mic" to "M9,6a3,3 0 0,1 6,0V12a3,3 0 0,1 -6,0ZM6,11Q6,17 12,17Q18,17 18,11M12,17V21",
        "flash" to "M13,2L5,14H12L11,22L19,10H12Z",
        "flip" to "M20,12a8,8 0 0,0 -14,-5M4,12a8,8 0 0,0 14,5M6,3V7H10M18,21V17H14",
        "grid" to "M3,3H21V21H3ZM9,3V21M15,3V21M3,9H21M3,15H21",
        "location" to "M12,21Q5,13 5,9a7,7 0 0,1 14,0Q19,13 12,21ZM9.5,9a2.5,2.5 0 1,0 5,0a2.5,2.5 0 1,0 -5,0",
        "alarm" to "M5,13a7,7 0 1,0 14,0a7,7 0 1,0 -14,0M12,9V13L14.5,14.5M4,6L7,3M20,6L17,3",
        "stopwatch" to "M5,14a7,7 0 1,0 14,0a7,7 0 1,0 -14,0M12,14L15,10M10,3H14",
        "timer" to "M5,13a7,7 0 1,0 14,0a7,7 0 1,0 -14,0M12,13V9M10,2H14",
        "globe" to "M3,12a9,9 0 1,0 18,0a9,9 0 1,0 -18,0M3,12H21M12,3Q7,12 12,21M12,3Q17,12 12,21",
        "bookmark" to "M6,3H18V21L12,16L6,21Z", "tabs" to "M4,7H17V20H4ZM7,4H20V17",
        "reload" to "M20,12a8,8 0 1,1 -3,-6.2M20,4V9H15",
        "edit" to "M4,20H8L19,9L15,5L4,16ZM13,7L17,11",
        "sort" to "M7,4V20M3,16L7,20L11,16M17,20V4M13,8L17,4L21,8",
        "info" to "M3,12a9,9 0 1,0 18,0a9,9 0 1,0 -18,0M12,11V16M12,8V8.1",
        "copy" to "M8,8H20V20H8ZM4,16V4H16", "photo" to "M3,5H21V19H3ZM3,16L9,11L14,15L17,12L21,16",
        "msg" to "M4,5H20V16H10L5,20V16H4Z", "music" to "M9,18V5L19,3V16M3,18a3,3 0 1,0 6,0a3,3 0 1,0 -6,0M13,16a3,3 0 1,0 6,0a3,3 0 1,0 -6,0",
        "sliders" to "M4,7H20M4,17H20M9,4V10M15,14V20", "calendar" to "M4,6H20V20H4ZM4,10H20M8,3V8M16,3V8",
        "keypad" to (listOf(6f, 12f, 18f).flatMap { x -> listOf(4f, 9.5f, 15f).map { y -> dot(x, y) } }.joinToString("") + dot(12f, 20.5f)),
        "more" to (dot(5f, 12f) + dot(12f, 12f) + dot(19f, 12f)),
        "call" to "M6.5,3.5H10L11.8,8L9.5,9.8Q11.2,13.8 14.2,14.5L16,12.3L20.5,14.2V17.5Q20.5,20.5 17.5,20.5Q5,19.5 3.5,6.5Q3.5,3.5 6.5,3.5Z"
    )
    private val cache = HashMap<String, Path>()
    fun path(n: String): Path = cache.getOrPut(n) { PathParser.createPathFromPathData(D[n] ?: D["doc"]!!) }
}

class GlyphView(c: Context, val name: String, var tint: Int, private val sw: Float = 1.9f) : View(c) {
    private val path = Glyphs.path(name)
    private val filled = name in Glyphs.FILLED
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val s = minOf(width, height) / 24f
        cv.save()
        cv.translate((width - 24 * s) / 2f, (height - 24 * s) / 2f)
        cv.scale(s, s)
        p.color = tint
        if (filled) p.style = Paint.Style.FILL
        else { p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND }
        cv.drawPath(path, p)
        cv.restore()
    }
}

fun Context.glyph(name: String, color: Int = T.label, size: Int = 24): GlyphView =
    GlyphView(this, name, color).apply { layoutParams = ViewGroup.LayoutParams(dp(size), dp(size)) }

fun Context.glyphBtn(name: String, color: Int = T.blue, f: () -> Unit): View = FrameLayout(this).apply {
    setPadding(dp(10), dp(10), dp(10), dp(10))
    addView(glyph(name, color, 24), FrameLayout.LayoutParams(dp(24), dp(24)))
    onTap(f)
}

fun Context.btn(s: String, color: Int = T.blue, bold: Boolean = false, f: () -> Unit): TextView =
    txt(s, 17f, color, bold).apply { setPadding(dp(8), dp(10), dp(8), dp(10)); onTap(f) }

fun Context.circleBtn(bg: Int, size: Int, inner: View, f: () -> Unit): FrameLayout = FrameLayout(this).apply {
    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bg) }
    addView(inner, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
    layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    isClickable = true
    setOnClickListener { tap(); f() }
}

fun Context.navRow(left: View?, right: View?): LinearLayout {
    val r = LinearLayout(this)
    r.gravity = Gravity.CENTER_VERTICAL
    r.minimumHeight = dp(44)
    if (left != null) r.addView(left)
    r.addView(View(this), lp(0, 1, 1f))
    if (right != null) r.addView(right)
    return r
}

fun Context.largeTitle(s: String): TextView = txt(s, 34f, T.label, true).apply { setPadding(dp(4), dp(2), dp(4), dp(8)) }
fun Context.section(s: String): TextView = txt(s.uppercase(), 13f, T.sub).apply { setPadding(dp(16), dp(20), dp(16), dp(6)) }

fun Context.iconTile(g: String, bg: Int): View = FrameLayout(this).apply {
    background = shape(bg, dpf(7f))
    addView(glyph(g, Color.WHITE, 18), FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
}

fun Context.page(build: LinearLayout.() -> Unit): ScrollView {
    val sv = ScrollView(this)
    sv.isVerticalScrollBarEnabled = false
    sv.setBackgroundColor(T.bg)
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(dp(16), dp(8), dp(16), dp(120))
    col.build()
    sv.addView(col)
    return sv
}

class Group(val c: Context) : LinearLayout(c) {
    private var n = 0
    init {
        orientation = VERTICAL
        background = shape(T.card, c.dpf(12f))
        clipToOutline = true
        outlineProvider = ViewOutlineProvider.BACKGROUND
    }
    fun add(v: View, indent: Int = 16, onClick: (() -> Unit)? = null): View {
        if (n++ > 0) { val s = View(c); s.setBackgroundColor(T.sep); addView(s, lp(MATCH, 1, 0f, c.dp(indent), 0, 0, 0)) }
        addView(v)
        if (onClick != null) v.onTap(onClick)
        return v
    }
    fun row(title: String, detail: String? = null, icon: View? = null, chevron: Boolean = false, color: Int = T.label, onClick: (() -> Unit)? = null): LinearLayout {
        val r = LinearLayout(c)
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = c.dp(48)
        r.setPadding(c.dp(16), c.dp(8), c.dp(12), c.dp(8))
        if (icon != null) r.addView(icon, lp(c.dp(30), c.dp(30), 0f, 0, 0, c.dp(12), 0))
        r.addView(c.txt(title, 17f, color), lp(0, WRAP, 1f))
        if (detail != null) r.addView(c.txt(detail, 17f, T.sub))
        if (chevron) r.addView(c.glyph("fwd", T.sub, 16), lp(c.dp(16), c.dp(16), 0f, c.dp(6), 0, 0, 0))
        add(r, if (icon != null) 58 else 16, onClick)
        return r
    }
}

class TabBar(val c: Context, items: List<Pair<String, String>>, sel: Int, val onSel: (Int) -> Unit) : LinearLayout(c) {
    private val gl = ArrayList<GlyphView>()
    private val lb = ArrayList<TextView>()
    init {
        background = shape(T.glass, c.dpf(30f))
        elevation = c.dpf(8f)
        setPadding(c.dp(6), c.dp(4), c.dp(6), c.dp(4))
        for ((i, it0) in items.withIndex()) {
            val col = LinearLayout(c)
            col.orientation = VERTICAL
            col.gravity = Gravity.CENTER
            col.setPadding(0, c.dp(6), 0, c.dp(4))
            val g = c.glyph(it0.first, T.sub, 24)
            val l = c.txt(it0.second, 10f, T.sub)
            col.addView(g, lp(c.dp(24), c.dp(24)))
            col.addView(l)
            gl.add(g); lb.add(l)
            col.onTap { select(i); onSel(i) }
            addView(col, lp(0, WRAP, 1f))
        }
        select(sel)
    }
    fun select(i: Int) {
        for (k in gl.indices) {
            val col = if (k == i) T.blue else T.sub
            gl[k].tint = col; gl[k].invalidate(); lb[k].setTextColor(col)
        }
    }
}

class Segmented(val c: Context, opts: List<String>, var sel: Int, val onSel: (Int) -> Unit) : LinearLayout(c) {
    private val tvs = ArrayList<TextView>()
    init {
        background = shape(T.fill, c.dpf(10f))
        setPadding(c.dp(2), c.dp(2), c.dp(2), c.dp(2))
        for ((i, o) in opts.withIndex()) {
            val t = c.txt(o, 13f, T.label, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, c.dp(7), 0, c.dp(7))
            t.onTap { set(i); onSel(i) }
            tvs.add(t)
            addView(t, lp(0, WRAP, 1f))
        }
        set(sel)
    }
    fun set(i: Int) {
        sel = i
        for ((k, t) in tvs.withIndex()) t.background = if (k == i) shape(T.card, c.dpf(8f)) else null
    }
}

class IosSwitch(c: Context, on: Boolean, val onChange: (Boolean) -> Unit) : View(c) {
    var checked = on
    private var pos = if (on) 1f else 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    init { setOnClickListener { set(!checked, true) } }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(context.dp(51), context.dp(31)) }
    fun set(v: Boolean, notify: Boolean) {
        checked = v
        val a = ValueAnimator.ofFloat(pos, if (v) 1f else 0f)
        a.duration = 180
        a.addUpdateListener { pos = it.animatedValue as Float; invalidate() }
        a.start()
        if (notify) onChange(v)
    }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.color = ArgbEvaluator().evaluate(pos, T.fill, T.green) as Int
        cv.drawRoundRect(0f, 0f, w, h, h / 2, h / 2, p)
        p.color = Color.WHITE
        cv.drawCircle(h / 2 + pos * (w - h), h / 2, h / 2 - context.dpf(2f), p)
    }
}

class Shell(val a: Activity) {
    val root = FrameLayout(a)
    val holder = FrameLayout(a)
    init { a.prep(); root.setBackgroundColor(T.bg); root.addView(holder, FrameLayout.LayoutParams(MATCH, MATCH)) }
    fun show(v: View) { holder.removeAllViews(); holder.addView(v, FrameLayout.LayoutParams(MATCH, MATCH)) }
    fun tabs(items: List<Pair<String, String>>, sel: Int, onSel: (Int) -> Unit): TabBar {
        val tb = TabBar(a, items, sel, onSel)
        root.addView(tb, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })
        return tb
    }
}

fun Context.searchBar(hint: String, onChange: (String) -> Unit): LinearLayout {
    val r = LinearLayout(this)
    r.gravity = Gravity.CENTER_VERTICAL
    r.background = shape(T.fill, dpf(12f))
    r.setPadding(dp(10), 0, dp(10), 0)
    r.addView(glyph("search", T.sub, 18), lp(dp(18), dp(18), 0f, 0, 0, dp(8), 0))
    val e = EditText(this)
    e.hint = hint
    e.setSingleLine()
    e.background = null
    e.textSize = 17f
    e.setTextColor(T.label)
    e.setHintTextColor(T.sub)
    e.addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(s: Editable?) { onChange(s?.toString() ?: "") }
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    })
    r.addView(e, lp(0, dp(40), 1f))
    return r
}

class Act(val label: String, val destructive: Boolean = false, val run: () -> Unit)

fun Activity.sheet(title: String?, vararg acts: Act) {
    val d = Dialog(this)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val root = LinearLayout(this)
    root.orientation = LinearLayout.VERTICAL
    root.setPadding(dp(10), 0, dp(10), dp(14))
    val g = Group(this)
    if (title != null) g.add(txt(title, 13f, T.sub).apply { gravity = Gravity.CENTER; setPadding(dp(16), dp(14), dp(16), dp(10)) })
    for (a in acts) {
        val t = txt(a.label, 20f, if (a.destructive) T.red else T.blue)
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(16), 0, dp(16))
        g.add(t, 0) { d.dismiss(); a.run() }
    }
    root.addView(g)
    val cancel = txt("Cancel", 20f, T.blue, true)
    cancel.gravity = Gravity.CENTER
    cancel.setPadding(0, dp(16), 0, dp(16))
    cancel.background = shape(T.card, dpf(12f))
    cancel.onTap { d.dismiss() }
    root.addView(cancel, lp(MATCH, WRAP, 0f, 0, dp(8), 0, 0))
    d.setContentView(root)
    d.window?.apply { setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); setGravity(Gravity.BOTTOM); setLayout(MATCH, WRAP) }
    d.show()
}

fun Activity.prompt(title: String, hint: String, initial: String = "", ok: (String) -> Unit) {
    val e = EditText(this)
    e.hint = hint
    e.setText(initial)
    e.setSingleLine()
    val pad = FrameLayout(this)
    pad.setPadding(dp(20), dp(8), dp(20), 0)
    pad.addView(e)
    AlertDialog.Builder(this).setTitle(title).setView(pad)
        .setPositiveButton("OK") { _, _ -> ok(e.text.toString().trim()) }
        .setNegativeButton("Cancel", null).show()
}

fun initials(n: String): String {
    val w = n.trim().split(" ").filter { it.isNotEmpty() }
    return when { w.isEmpty() -> "#"; w.size == 1 -> w[0].take(1).uppercase(); else -> (w[0].take(1) + w.last().take(1)).uppercase() }
}

fun Context.avatar(name: String): TextView {
    val t = txt(initials(name), 16f, Color.WHITE, true)
    t.gravity = Gravity.CENTER
    t.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFFA6ACB6.toInt(), 0xFF868B96.toInt())).apply { shape = GradientDrawable.OVAL }
    return t
}

class LazyAdapter(val n: Int, val make: (Int) -> View) : androidx.viewpager.widget.PagerAdapter() {
    override fun getCount() = n
    override fun isViewFromObject(v: View, o: Any) = v === o
    override fun instantiateItem(c: ViewGroup, p: Int): Any { val v = make(p); c.addView(v); return v }
    override fun destroyItem(c: ViewGroup, p: Int, o: Any) { c.removeView(o as View) }
}
