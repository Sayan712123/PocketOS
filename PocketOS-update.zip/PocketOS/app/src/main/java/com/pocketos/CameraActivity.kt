package com.pocketos

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GridOverlay(c: android.content.Context) : View(c) {
    private val p = Paint().apply { color = 0x66FFFFFF; strokeWidth = 2f }
    override fun onDraw(cv: Canvas) {
        for (i in 1..2) { cv.drawLine(width * i / 3f, 0f, width * i / 3f, height.toFloat(), p); cv.drawLine(0f, height * i / 3f, width.toFloat(), height * i / 3f, p) }
    }
}

class CameraActivity : ComponentActivity() {
    private lateinit var pv: PreviewView
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var camera: Camera? = null
    private var recording: Recording? = null
    private var front = false
    private var videoMode = false
    private var flash = ImageCapture.FLASH_MODE_OFF
    private var timerSec = 0
    private lateinit var shutterInner: View
    private lateinit var count: TextView
    private lateinit var thumb: ImageView
    private lateinit var grid: GridOverlay
    private lateinit var modeLabel: TextView
    private val h = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        pv = PreviewView(this)
        root.addView(pv, FrameLayout.LayoutParams(MATCH, MATCH))
        grid = GridOverlay(this); grid.visibility = View.GONE
        root.addView(grid, FrameLayout.LayoutParams(MATCH, MATCH))
        count = TextView(this); count.textSize = 90f; count.setTextColor(Color.WHITE); count.gravity = Gravity.CENTER
        root.addView(count, FrameLayout.LayoutParams(MATCH, MATCH))

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER
        top.setBackgroundColor(0x55000000)
        val flashBtn = glyphBtn("flash", Color.WHITE) { }
        flashBtn.setOnClickListener {
            flash = when (flash) { ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO; ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON; else -> ImageCapture.FLASH_MODE_OFF }
            imageCapture?.flashMode = flash
            toast(when (flash) { ImageCapture.FLASH_MODE_ON -> "Flash on"; ImageCapture.FLASH_MODE_AUTO -> "Flash auto"; else -> "Flash off" })
        }
        top.addView(flashBtn, lp(0, WRAP, 1f))
        top.addView(glyphBtn("timer", Color.WHITE) { timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 }; toast(if (timerSec == 0) "Timer off" else "Timer ${timerSec}s") }, lp(0, WRAP, 1f))
        top.addView(glyphBtn("grid", Color.WHITE) { grid.visibility = if (grid.visibility == View.GONE) View.VISIBLE else View.GONE }, lp(0, WRAP, 1f))
        top.addView(glyphBtn("flip", Color.WHITE) { front = !front; bind() }, lp(0, WRAP, 1f))
        root.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.setBackgroundColor(0x88000000.toInt())
        bottom.setPadding(0, dp(8), 0, dp(20))
        val modes = LinearLayout(this)
        modes.gravity = Gravity.CENTER
        modeLabel = TextView(this)
        for ((i, n) in listOf("PHOTO", "VIDEO").withIndex()) {
            val t = TextView(this); t.text = n; t.textSize = 14f; t.setTextColor(if ((i == 1) == videoMode) 0xFFFFD60A.toInt() else Color.WHITE); t.setPadding(dp(16), dp(8), dp(16), dp(8))
            t.setOnClickListener { videoMode = i == 1; recreateUi() }
            modes.addView(t)
        }
        bottom.addView(modes)
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        thumb = ImageView(this)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.background = shape(0xFF333333.toInt(), dpf(10f))
        thumb.clipToOutline = true
        thumb.setOnClickListener { startActivity(Intent(this, GalleryActivity::class.java)) }
        row.addView(thumb, lp(dp(52), dp(52), 0f, dp(32), 0, 0, 0))
        row.addView(View(this), lp(0, 1, 1f))
        val outer = FrameLayout(this)
        outer.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(dp(4), Color.WHITE); setColor(Color.TRANSPARENT) }
        shutterInner = View(this)
        setInner()
        outer.addView(shutterInner, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER))
        outer.setOnClickListener { shutter() }
        row.addView(outer, lp(dp(76), dp(76)))
        row.addView(View(this), lp(0, 1, 1f))
        row.addView(View(this), lp(dp(52), dp(52), 0f, 0, 0, dp(32), 0))
        bottom.addView(row, lp(MATCH, WRAP, 0f, 0, dp(8), 0, 0))
        root.addView(bottom, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        val sg = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val z = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f
                camera?.cameraControl?.setZoomRatio(z * d.scaleFactor); return true
            }
        })
        pv.setOnTouchListener { v, ev ->
            sg.onTouchEvent(ev)
            if (ev.action == android.view.MotionEvent.ACTION_UP && !sg.isInProgress) {
                val pt = pv.meteringPointFactory.createPoint(ev.x, ev.y)
                camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build()); v.performClick()
            }
            true
        }
        setContentView(root)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) bind()
        else requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 11)
    }

    private fun recreateUi() { recreate() }

    private fun setInner() {
        shutterInner.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (videoMode) 0xFFFF3B30.toInt() else Color.WHITE) }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) bind() else toast("Camera permission needed")
    }

    private fun bind() {
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            val p = fut.get()
            val preview = Preview.Builder().build()
            preview.setSurfaceProvider(pv.surfaceProvider)
            imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
            imageCapture?.flashMode = flash
            val rec = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))).build()
            videoCapture = VideoCapture.withOutput(rec)
            val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            p.unbindAll()
            try {
                camera = if (videoMode) p.bindToLifecycle(this, sel, preview, videoCapture!!) else p.bindToLifecycle(this, sel, preview, imageCapture!!)
            } catch (e: Exception) { toast("Camera unavailable") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun name(prefix: String) = prefix + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun shutter() {
        if (videoMode) { toggleVideo(); return }
        if (timerSec > 0) {
            var left = timerSec
            val r = object : Runnable { override fun run() { if (left > 0) { count.text = left.toString(); left--; h.postDelayed(this, 1000) } else { count.text = ""; capture() } } }
            h.post(r)
        } else capture()
    }

    private fun capture() {
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name("IMG_"))
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
        val opts = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build()
        imageCapture?.takePicture(opts, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) { showThumb(r.savedUri) }
            override fun onError(e: ImageCaptureException) { toast("Capture failed") }
        })
    }

    private fun toggleVideo() {
        val rc = recording
        if (rc != null) { rc.stop(); recording = null; return }
        val cv = ContentValues()
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name("VID_"))
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
        val out = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(cv).build()
        var pr = videoCapture?.output?.prepareRecording(this, out) ?: return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pr = pr.withAudioEnabled()
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            if (ev is VideoRecordEvent.Finalize) { recording = null; showThumb(ev.outputResults.outputUri) }
        }
        toast("Recording…")
    }

    private fun showThumb(u: Uri?) {
        if (u == null) return
        try { if (Build.VERSION.SDK_INT >= 29) thumb.setImageBitmap(contentResolver.loadThumbnail(u, Size(200, 200), null)) } catch (e: Exception) { }
    }

    override fun onDestroy() { recording?.stop(); h.removeCallbacksAndMessages(null); super.onDestroy() }
}
