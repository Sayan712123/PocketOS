package com.pocketos

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.viewpager.widget.ViewPager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LauncherActivity : Activity() {
    private lateinit var prefs: Prefs
    private val cache = HashMap<String, Bitmap>()
    private var lastPack = ""
    private var lastCount = -1
    private var downX = 0f
    private var downY = 0f
    private var search: View? = null
    private var items: List<ResolveInfo> = emptyList()
    private var pager: ViewPager? = null

    override fun onCreate(b: Bundle?) { super.onCreate(b); prefs = Prefs(this) }

    private fun list(): List<ResolveInfo> {
        val pm = packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).sortedBy { it.loadLabel(pm).toString().lowercase() }
    }

    override fun onResume() {
        super.onResume()
        val l = list()
        if (pager == null || prefs.pack != lastPack || l.size != lastCount) { items = l; build() }
    }

    override fun onNewIntent(intent: Intent?) { super.onNewIntent(intent); closeSearch(); pager?.currentItem = 0 }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (search != null) closeSearch() }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = ev.x; downY = ev.y }
            MotionEvent.ACTION_UP -> {
                val w = resources.displayMetrics.widthPixels; val h = resources.displayMetrics.heightPixels
                val dy = ev.y - downY; val dx = ev.x - downX
                if (search == null && Math.abs(dx) < Math.abs(dy) / 2) {
                    if (dy > dp(90) && downY < h * 0.4f) { if (downX > w / 2) openApp(ControlCenterActivity::class.java) else openSearch() }
                    else if (dy < -dp(110) && downY > h * 0.8f) openApp(RecentsActivity::class.java)
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun iconFor(ri: ResolveInfo, packId: String, px: Int): Bitmap {
        val key = ri.activityInfo.packageName + "/" + ri.activityInfo.name + "/" + packId
        return cache.getOrPut(key) {
            val own = IconFactory.apps.firstOrNull { it.cls.name == ri.activityInfo.name }
            if (ri.activityInfo.packageName == packageName && own != null) IconFactory.appIcon(this, own.id, packId, px)
            else IconFactory.masked(ri.loadIcon(packageManager), packId, px)
        }
    }

    private fun build() {
        val packId = prefs.pack
        if (packId != lastPack) { cache.clear(); lastPack = packId }
        lastCount = items.size
        val root = FrameLayout(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, dp(12), 0, dp(10))
        val perPage = 20
        val pages = items.chunked(perPage)
        val views = pages.mapIndexed { pi, pgItems ->
            val grid = LinearLayout(this)
            grid.orientation = LinearLayout.VERTICAL
            grid.setPadding(dp(8), dp(8), dp(8), 0)
            if (pi == 0) {
                val clock = LinearLayout(this); clock.orientation = LinearLayout.VERTICAL; clock.setPadding(dp(16), dp(8), dp(16), dp(16))
                clock.addView(txt(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 15f, Color.WHITE, true).apply { setShadowLayer(4f, 0f, 1f, 0x99000000.toInt()) })
                clock.addView(txt(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 56f, Color.WHITE).apply { setShadowLayer(6f, 0f, 2f, 0x99000000.toInt()) })
                grid.addView(clock)
            }
            for (row in pgItems.chunked(4)) {
                val r = LinearLayout(this)
                row.forEach { r.addView(cell(it, packId), lp(0, WRAP, 1f)) }
                repeat(4 - row.size) { r.addView(View(this), lp(0, 1, 1f)) }
                grid.addView(r, lp(MATCH, WRAP, 0f, 0, 0, 0, dp(18)))
            }
            grid as View
        }
        val vp = ViewPager(this)
        vp.adapter = LazyAdapter(views.size) { views[it] }
        pager = vp
        col.addView(vp, lp(MATCH, 0, 1f))
        val dots = LinearLayout(this)
        dots.gravity = Gravity.CENTER
        fun paint(sel: Int) { dots.removeAllViews(); for (i in views.indices) { val d = View(this); d.background = shape(if (i == sel) Color.WHITE else 0x66FFFFFF, dpf(3f)); dots.addView(d, lp(dp(6), dp(6), 0f, dp(3), 0, dp(3), 0)) } }
        paint(0)
        vp.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() { override fun onPageSelected(p: Int) { paint(p) } })
        col.addView(dots, lp(MATCH, WRAP, 0f, 0, dp(4), 0, dp(10)))
        val dock = LinearLayout(this)
        dock.gravity = Gravity.CENTER
        dock.setPadding(dp(8), dp(12), dp(8), dp(12))
        dock.background = shape(0x55FFFFFF, dpf(30f))
        for (id in listOf("dialer", "messages", "browser", "music")) {
            val a = IconFactory.apps.first { it.id == id }
            val iv = ImageView(this)
            iv.setImageBitmap(IconFactory.appIcon(this, id, packId, dp(60)))
            iv.setOnClickListener { openApp(a.cls) }
            dock.addView(iv, lp(0, dp(60), 1f))
        }
        col.addView(dock, lp(MATCH, WRAP, 0f, dp(12), 0, dp(12), 0))
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
    }

    private fun cell(ri: ResolveInfo, packId: String): View {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER_HORIZONTAL
        val iv = ImageView(this)
        iv.setImageBitmap(iconFor(ri, packId, dp(60)))
        l.addView(iv, lp(dp(60), dp(60)))
        val t = txt(ri.loadLabel(packageManager).toString(), 11f, Color.WHITE)
        t.gravity = Gravity.CENTER; t.maxLines = 1; t.ellipsize = TextUtils.TruncateAt.END
        t.setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
        l.addView(t, lp(MATCH, WRAP, 0f, dp(2), dp(4), dp(2), 0))
        l.setOnClickListener { launch(ri) }
        l.setOnLongClickListener {
            val pkg = ri.activityInfo.packageName
            sheet(ri.loadLabel(packageManager).toString(), Act("App Info") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) },
                Act("Uninstall", true) { if (pkg != packageName) startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))) })
            true
        }
        return l
    }

    private fun launch(ri: ResolveInfo) {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(ri.activityInfo.packageName, ri.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { toast("Cannot open") }
    }

    // ---------- Spotlight search ----------
    private fun openSearch() {
        T.init(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(0xDD000000.toInt())
        box.setPadding(dp(16), dp(48), dp(16), dp(16))
        box.isClickable = true
        val e = EditText(this)
        e.hint = "Search"; e.setSingleLine(); e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF8E8E93.toInt()); e.textSize = 18f
        e.background = shape(0x33FFFFFF, dpf(14f)); e.setPadding(dp(16), dp(10), dp(16), dp(10))
        val results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        e.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                results.removeAllViews()
                val q = s?.toString()?.trim() ?: ""
                if (q.isEmpty()) return
                for (ri in items.filter { it.loadLabel(packageManager).toString().contains(q, true) }.take(6)) {
                    val r = LinearLayout(this@LauncherActivity); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(0, dp(8), 0, dp(8))
                    val iv = ImageView(this@LauncherActivity); iv.setImageBitmap(iconFor(ri, lastPack, dp(44)))
                    r.addView(iv, lp(dp(44), dp(44), 0f, 0, 0, dp(12), 0)); r.addView(txt(ri.loadLabel(packageManager).toString(), 17f, Color.WHITE))
                    r.setOnClickListener { closeSearch(); launch(ri) }
                    results.addView(r)
                }
                val web = txt("Search web for \"$q\"", 17f, 0xFF64D2FF.toInt()); web.setPadding(0, dp(16), 0, 0)
                web.setOnClickListener { closeSearch(); startActivity(Intent(this@LauncherActivity, BrowserActivity::class.java).setData(Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                results.addView(web)
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        box.addView(e)
        box.addView(ScrollView(this).apply { addView(results) }, lp(MATCH, 0, 1f, 0, dp(12), 0, 0))
        search = box
        (window.decorView as FrameLayout).addView(box, FrameLayout.LayoutParams(MATCH, MATCH))
        e.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(e, 0)
    }

    private fun closeSearch() {
        search?.let { (window.decorView as FrameLayout).removeView(it) }
        search = null
    }
}
