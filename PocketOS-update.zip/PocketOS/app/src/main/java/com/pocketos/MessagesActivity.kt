package com.pocketos

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Notification
import android.app.Service
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Telephony
import android.telephony.SmsManager
import android.text.TextUtils
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val by = LinkedHashMap<String, StringBuilder>()
        for (m in msgs) by.getOrPut(m.displayOriginatingAddress ?: "") { StringBuilder() }.append(m.displayMessageBody ?: "")
        val nm = c.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("sms", "Messages", NotificationManager.IMPORTANCE_HIGH))
        for ((addr, body) in by) {
            try {
                val cv = ContentValues()
                cv.put(Telephony.Sms.ADDRESS, addr); cv.put(Telephony.Sms.BODY, body.toString())
                cv.put(Telephony.Sms.DATE, System.currentTimeMillis()); cv.put(Telephony.Sms.READ, 0)
                c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, cv)
            } catch (e: Exception) { }
            val pi = PendingIntent.getActivity(c, addr.hashCode(), Intent(c, MessagesActivity::class.java).putExtra("addr", addr), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(c, "sms").setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(Repo.nameFor(c, addr) ?: addr).setContentText(body.toString()).setContentIntent(pi).setAutoCancel(true).build()
            try { nm.notify(addr.hashCode(), n) } catch (e: Exception) { }
        }
    }
}

class MmsReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }
class RespondService : Service() { override fun onBind(i: Intent?): IBinder? = null }

class MessagesActivity : Base() {
    private class Msg(val thread: Long, val addr: String, val body: String, val date: Long, val mine: Boolean, val read: Boolean)
    private var inThread = false
    private var query = ""

    private fun isDefault() = Telephony.Sms.getDefaultSmsPackage(this) == packageName

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prep()
        ask(listOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS)) { start() }
    }

    private fun start() {
        val a = intent?.getStringExtra("addr") ?: intent?.data?.schemeSpecificPart ?: ""
        if (a.isNotEmpty()) showThread(a, -1) else showList()
    }

    override fun onResume() { super.onResume(); if (!inThread && checkSelfPermission(Manifest.permission.READ_SMS) == 0) showList() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (inThread) showList() else super.onBackPressed() }

    private fun makeDefault() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_SMS)) startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 5)
        } else startActivity(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName))
    }

    private fun load(where: String?, args: Array<String>?, order: String): List<Msg> {
        val out = ArrayList<Msg>()
        try {
            contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("thread_id", "address", "body", "date", "type", "read"), where, args, order)?.use { c ->
                while (c.moveToNext()) out.add(Msg(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3), c.getInt(4) == 2, c.getInt(5) == 1))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun showList() {
        inThread = false
        val seen = LinkedHashMap<Long, Msg>()
        val unread = HashMap<Long, Int>()
        for (m in load(null, null, "date DESC LIMIT 600")) {
            if (!seen.containsKey(m.thread)) seen[m.thread] = m
            if (!m.read && !m.mine) unread[m.thread] = (unread[m.thread] ?: 0) + 1
        }
        setContentView(page {
            addView(navRow(btn("Edit") { toast("Long-press a conversation to delete") }, glyphBtn("edit") { showThread("", -1) }))
            addView(largeTitle("Messages"))
            addView(searchBar("Search") { q -> query = q; showList() }, lp(MATCH, dp(44), 0f, 0, 0, 0, dp(8)))
            if (!isDefault()) {
                val g0 = Group(this@MessagesActivity)
                g0.row("Set PocketOS as default SMS app", "Receive & delete", null, true, T.blue) { makeDefault() }
                addView(g0, lp(MATCH, WRAP, 0f, 0, 0, 0, dp(12)))
            }
            val g = Group(this@MessagesActivity)
            for (m in seen.values) {
                val name = Repo.nameFor(this@MessagesActivity, m.addr) ?: m.addr
                if (query.isNotEmpty() && !name.contains(query, true) && !m.body.contains(query, true)) continue
                val r = LinearLayout(this@MessagesActivity)
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(8), dp(10), dp(16), dp(10))
                val dot = View(this@MessagesActivity)
                dot.background = shape(if ((unread[m.thread] ?: 0) > 0) T.blue else Color.TRANSPARENT, dpf(5f))
                r.addView(dot, lp(dp(10), dp(10), 0f, 0, 0, dp(4), 0))
                r.addView(avatar(name), lp(dp(48), dp(48), 0f, 0, 0, dp(12), 0))
                val col = LinearLayout(this@MessagesActivity)
                col.orientation = LinearLayout.VERTICAL
                val top = LinearLayout(this@MessagesActivity)
                top.addView(txt(name, 17f, T.label, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, lp(0, WRAP, 1f))
                top.addView(txt(DateUtils.getRelativeTimeSpanString(m.date, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(), 13f, T.sub))
                col.addView(top)
                col.addView(txt(m.body, 15f, T.sub).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
                r.addView(col, lp(0, WRAP, 1f))
                g.add(r, 82) { showThread(m.addr, m.thread) }
                r.setOnLongClickListener {
                    sheet(name, Act("Delete Conversation", true) {
                        if (isDefault()) { contentResolver.delete(Telephony.Sms.CONTENT_URI, "thread_id=?", arrayOf(m.thread.toString())); showList() } else makeDefault()
                    }); true
                }
            }
            addView(g)
        })
    }

    private fun bubble(box: LinearLayout, text: String, mine: Boolean) {
        val t = txt(text, 16f, if (mine) Color.WHITE else T.label)
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        t.background = shape(if (mine) T.green else T.fill, dpf(18f))
        t.maxWidth = (resources.displayMetrics.widthPixels * 0.75f).toInt()
        box.addView(t, lp(WRAP, WRAP, 0f, 0, dp(3), 0, dp(3)).apply { gravity = if (mine) Gravity.END else Gravity.START })
    }

    @Suppress("DEPRECATION")
    private fun sms(): SmsManager = if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun showThread(addr0: String, thread: Long) {
        inThread = true
        val msgs = if (thread >= 0) load("thread_id=?", arrayOf(thread.toString()), "date ASC")
            else if (addr0.isNotEmpty()) load("address=?", arrayOf(addr0), "date ASC") else emptyList()
        if (isDefault() && thread >= 0) { try { val cv = ContentValues(); cv.put("read", 1); contentResolver.update(Telephony.Sms.CONTENT_URI, cv, "thread_id=?", arrayOf(thread.toString())) } catch (e: Exception) { } }
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(T.bg)
        root.setPadding(dp(12), dp(8), dp(12), dp(8))
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(glyphBtn("back") { showList() })
        var addrEt: EditText? = null
        if (addr0.isEmpty()) {
            addrEt = EditText(this); addrEt.hint = "To:"; addrEt.setSingleLine(); addrEt.inputType = android.text.InputType.TYPE_CLASS_PHONE
            top.addView(addrEt, lp(0, WRAP, 1f))
        } else top.addView(txt(Repo.nameFor(this, addr0) ?: addr0, 20f, T.label, true), lp(0, WRAP, 1f))
        root.addView(top)
        val sv = ScrollView(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(8), dp(4), dp(8))
        sv.addView(box)
        var lastDay = -1L
        for (m in msgs) {
            val day = m.date / 86400000L
            if (day != lastDay) { lastDay = day; box.addView(txt(DateUtils.formatDateTime(this, m.date, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME), 12f, T.sub).apply { gravity = Gravity.CENTER }, lp(MATCH, WRAP, 0f, 0, dp(8), 0, dp(4))) }
            bubble(box, m.body, m.mine)
        }
        root.addView(sv, lp(MATCH, 0, 1f))
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        val input = EditText(this)
        input.hint = "Text Message"
        input.maxLines = 4
        input.background = shape(T.fill, dpf(20f))
        input.setPadding(dp(14), dp(8), dp(14), dp(8))
        bar.addView(input, lp(0, WRAP, 1f, 0, 0, dp(8), 0))
        bar.addView(circleBtn(T.green, 40, glyph("up", Color.WHITE, 22)) {
            val to = (addrEt?.text?.toString() ?: addr0).trim()
            val body = input.text.toString()
            if (to.isNotEmpty() && body.isNotBlank()) {
                try {
                    val m = sms()
                    m.sendMultipartTextMessage(to, null, m.divideMessage(body), null, null)
                    if (isDefault()) { val cv = ContentValues(); cv.put(Telephony.Sms.ADDRESS, to); cv.put(Telephony.Sms.BODY, body); cv.put(Telephony.Sms.DATE, System.currentTimeMillis()); contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, cv) }
                    bubble(box, body, true)
                    input.setText("")
                    sv.post { sv.fullScroll(View.FOCUS_DOWN) }
                } catch (e: Exception) { toast("Send failed") }
            }
        })
        root.addView(bar, lp(MATCH, WRAP, 0f, 0, dp(6), 0, dp(6)))
        setContentView(root)
    }
}
