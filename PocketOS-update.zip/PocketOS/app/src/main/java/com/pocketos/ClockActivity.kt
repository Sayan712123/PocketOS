package com.pocketos

import android.Manifest
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.NumberPicker
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class RingView(c: Context) : View(c) {
    var frac = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val s = context.dpf(8f)
        val r = RectF(s, s, width - s, height - s)
        p.style = Paint.Style.STROKE; p.strokeWidth = s; p.color = T.fill
        cv.drawArc(r, 0f, 360f, false, p)
        p.color = T.orange; p.strokeCap = Paint.Cap.ROUND
        cv.drawArc(r, -90f, 360f * frac, false, p)
    }
}

class ClockActivity : Base() {
    private lateinit var shell: Shell
    private lateinit var prefs: Prefs
    private val h = Handler(Looper.getMainLooper())
    private var tab = 1
    private val zoneViews = ArrayList<Pair<TimeZone, TextView>>()
    // stopwatch
    private var swRun = false; private var swStart = 0L; private var swAcc = 0L; private var lapBase = 0L
    private val laps = ArrayList<Long>()
    private var swText: TextView? = null
    // timer
    private var tmText: TextView? = null
    private var tmRing: RingView? = null
    private val tick = object : Runnable { override fun run() { update(); h.postDelayed(this, 50) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        shell = Shell(this)
        shell.tabs(listOf("globe" to "World Clock", "alarm" to "Alarms", "stopwatch" to "Stopwatch", "timer" to "Timer"), tab) { tab = it; render() }
        setContentView(shell.root)
        if (Build.VERSION.SDK_INT >= 33) ask(listOf(Manifest.permission.POST_NOTIFICATIONS)) { }
        render()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }

    private fun render() {
        zoneViews.clear(); swText = null; tmText = null; tmRing = null
        shell.show(when (tab) { 0 -> world(); 1 -> alarms(); 2 -> stopwatch(); else -> timer() })
    }

    private fun zones(): MutableList<String> {
        val z = prefs.s("zones", TimeZone.getDefault().id).split(",").filter { it.isNotEmpty() }.toMutableList()
        if (z.isEmpty()) z.add(TimeZone.getDefault().id)
        return z
    }

    // ---------- World clock ----------
    private fun world(): View = page {
        addView(navRow(null, glyphBtn("plus") { addZone() }))
        addView(largeTitle("World Clock"))
        val g = Group(this@ClockActivity)
        for (id in zones()) {
            val tz = TimeZone.getTimeZone(id)
            val r = LinearLayout(this@ClockActivity)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(16), dp(12), dp(16), dp(12))
            val col = LinearLayout(this@ClockActivity)
            col.orientation = LinearLayout.VERTICAL
            col.addView(txt(dayDiff(tz), 13f, T.sub))
            col.addView(txt(id.substringAfter('/').replace('_', ' '), 22f, T.label))
            r.addView(col, lp(0, WRAP, 1f))
            val t = txt("", 40f, T.label)
            r.addView(t)
            zoneViews.add(tz to t)
            g.add(r, 16) {}
            r.setOnLongClickListener {
                if (zones().size > 1) sheet(id, Act("Remove", true) { prefs.put("zones", zones().filter { z -> z != id }.joinToString(",")); render() })
                true
            }
        }
        addView(g)
        update()
    }

    private fun dayDiff(tz: TimeZone): String {
        val now = System.currentTimeMillis()
        val d = (tz.getOffset(now) - TimeZone.getDefault().getOffset(now)) / 3600000.0
        val a = Calendar.getInstance(tz); val b = Calendar.getInstance()
        val day = if (a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)) "Today" else if (a.timeInMillis > b.timeInMillis) "Tomorrow" else "Yesterday"
        val hrs = if (d == Math.floor(d)) d.toInt().toString() else d.toString()
        return "$day, ${if (d >= 0) "+" else ""}$hrs HRS"
    }

    private fun addZone() {
        val all = TimeZone.getAvailableIDs().filter { it.contains('/') && !it.startsWith("Etc") }.sorted()
        val shown = ArrayList(all)
        val ad = ArrayAdapter(this, android.R.layout.simple_list_item_1, shown)
        val lv = ListView(this)
        lv.adapter = ad
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), 0)
        box.addView(searchBar("Search city") { q ->
            shown.clear(); shown.addAll(all.filter { it.replace('_', ' ').contains(q, true) }); ad.notifyDataSetChanged()
        })
        box.addView(lv, lp(MATCH, dp(360)))
        val d = AlertDialog.Builder(this).setTitle("Choose a City").setView(box).setNegativeButton("Cancel", null).show()
        lv.setOnItemClickListener { _, _, p, _ ->
            val z = zones(); z.add(shown[p]); prefs.put("zones", z.distinct().joinToString(",")); d.dismiss(); render()
        }
    }

    // ---------- Alarms ----------
    private fun fmtTime(hh: Int, mm: Int): String {
        val c = Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY, hh); c.set(Calendar.MINUTE, mm)
        return SimpleDateFormat(if (DateFormat.is24HourFormat(this)) "HH:mm" else "h:mm a", Locale.getDefault()).format(c.time)
    }

    private fun dayText(d: Int): String {
        if (d == 0) return "Once"
        if (d == 127) return "Every day"
        val n = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        return n.filterIndexed { i, _ -> (d and (1 shl i)) != 0 }.joinToString(" ")
    }

    private fun alarms(): View = page {
        addView(navRow(null, glyphBtn("plus") { editAlarm(null) }))
        addView(largeTitle("Alarms"))
        val list = Alarms.all(this@ClockActivity)
        if (list.isEmpty()) addView(txt("No alarms. Tap + to add one.", 15f, T.sub), lp(WRAP, WRAP, 0f, dp(4), dp(8), 0, 0))
        val g = Group(this@ClockActivity)
        for (a in list.sortedWith(compareBy({ it.h }, { it.m }))) {
            val r = LinearLayout(this@ClockActivity)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(16), dp(12), dp(16), dp(12))
            val col = LinearLayout(this@ClockActivity)
            col.orientation = LinearLayout.VERTICAL
            col.addView(txt(fmtTime(a.h, a.m), 44f, if (a.on) T.label else T.sub))
            col.addView(txt((if (a.label.isEmpty()) "Alarm" else a.label) + ", " + dayText(a.days), 14f, T.sub))
            r.addView(col, lp(0, WRAP, 1f))
            r.addView(IosSwitch(this@ClockActivity, a.on) { on ->
                a.on = on
                if (on) Alarms.schedule(this@ClockActivity, a) else Alarms.cancel(this@ClockActivity, a)
                Alarms.save(this@ClockActivity, list)
            })
            g.add(r, 16) { editAlarm(a) }
            r.setOnLongClickListener {
                sheet(null, Act("Delete Alarm", true) {
                    Alarms.cancel(this@ClockActivity, a); Alarms.save(this@ClockActivity, list.filter { it.id != a.id }); render()
                }); true
            }
        }
        addView(g)
    }

    private fun editAlarm(old: Alarm?) {
        val now = Calendar.getInstance()
        val hh = old?.h ?: now.get(Calendar.HOUR_OF_DAY)
        val mm = old?.m ?: now.get(Calendar.MINUTE)
        TimePickerDialog(this, { _, h2, m2 ->
            val checked = BooleanArray(7) { i -> old != null && (old.days and (1 shl i)) != 0 }
            val names = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
            AlertDialog.Builder(this).setTitle("Repeat").setMultiChoiceItems(names, checked) { _, i, v -> checked[i] = v }
                .setPositiveButton("Next") { _, _ ->
                    var days = 0
                    for (i in 0..6) if (checked[i]) days = days or (1 shl i)
                    prompt("Label", "Alarm", old?.label ?: "") { label ->
                        val list = Alarms.all(this)
                        val a = old?.let { o -> list.firstOrNull { it.id == o.id } } ?: Alarm((Math.random() * 1000000).toInt() + 1, h2, m2, days, label, true).also { list.add(it) }
                        a.h = h2; a.m = m2; a.days = days; a.label = label; a.on = true
                        Alarms.schedule(this, a)
                        Alarms.save(this, list)
                        render()
                    }
                }.setNegativeButton("Cancel", null).show()
        }, hh, mm, DateFormat.is24HourFormat(this)).show()
    }

    // ---------- Stopwatch ----------
    private fun swElapsed(): Long = swAcc + (if (swRun) SystemClock.elapsedRealtime() - swStart else 0L)
    private fun fmtSw(e: Long): String = String.format(Locale.US, "%02d:%02d.%02d", e / 60000, (e / 1000) % 60, (e / 10) % 100)

    private fun stopwatch(): View = page {
        addView(largeTitle("Stopwatch"))
        val t = txt(fmtSw(swElapsed()), 76f, T.label)
        t.gravity = Gravity.CENTER
        swText = t
        addView(t, lp(MATCH, WRAP, 0f, 0, dp(24), 0, dp(24)))
        val row = LinearLayout(this@ClockActivity)
        row.gravity = Gravity.CENTER
        val left = txt(if (swRun) "Lap" else "Reset", 17f, T.label, true)
        left.gravity = Gravity.CENTER
        val lb = circleBtn(T.fill, 84, left) {
            if (swRun) { val e = swElapsed(); laps.add(0, e - lapBase); lapBase = e } else { swAcc = 0; lapBase = 0; laps.clear() }
            render()
        }
        val right = txt(if (swRun) "Stop" else "Start", 17f, Color.WHITE, true)
        right.gravity = Gravity.CENTER
        val rb = circleBtn(if (swRun) T.red else T.green, 84, right) {
            if (swRun) { swAcc += SystemClock.elapsedRealtime() - swStart; swRun = false }
            else { swStart = SystemClock.elapsedRealtime(); swRun = true }
            render()
        }
        row.addView(lb, lp(dp(84), dp(84), 0f, 0, 0, dp(80), 0))
        row.addView(rb, lp(dp(84), dp(84)))
        addView(row, lp(MATCH, WRAP, 0f, 0, 0, 0, dp(20)))
        if (laps.isNotEmpty()) {
            val g = Group(this@ClockActivity)
            val best = laps.minOrNull() ?: 0L
            val worst = laps.maxOrNull() ?: 0L
            laps.forEachIndexed { i, l ->
                val c = if (laps.size > 1 && l == best) T.green else if (laps.size > 1 && l == worst) T.red else T.label
                g.row("Lap ${laps.size - i}", fmtSw(l), null, false, c)
            }
            addView(g)
        }
    }

    // ---------- Timer ----------
    private val hp by lazy { picker(23) }
    private val mp by lazy { picker(59) }
    private val sp by lazy { picker(59) }
    private fun picker(max: Int) = NumberPicker(this).apply { minValue = 0; maxValue = max; setFormatter { String.format("%02d", it) } }

    private fun timerEnd(): Long = prefs.s("timer_end", "0").toLongOrNull() ?: 0L
    private fun timerTotal(): Long = prefs.s("timer_total", "0").toLongOrNull() ?: 0L

    private fun timer(): View = page {
        addView(largeTitle("Timer"))
        val running = timerEnd() > System.currentTimeMillis()
        if (running) {
            val box = android.widget.FrameLayout(this@ClockActivity)
            val ring = RingView(this@ClockActivity)
            tmRing = ring
            box.addView(ring, android.widget.FrameLayout.LayoutParams(MATCH, MATCH))
            val t = txt("", 56f, T.label)
            tmText = t
            box.addView(t, android.widget.FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
            addView(box, lp(MATCH, dp(300), 0f, dp(24), dp(8), dp(24), dp(16)))
            val cancel = txt("Cancel", 17f, T.label, true)
            cancel.gravity = Gravity.CENTER
            addView(circleBtn(T.fill, 84, cancel) {
                Alarms.cancelCode(this@ClockActivity, 7777); prefs.put("timer_end", "0"); render()
            }, lp(dp(84), dp(84)))
        } else {
            val row = LinearLayout(this@ClockActivity)
            row.gravity = Gravity.CENTER
            row.addView(hp); row.addView(txt("h", 15f, T.sub)); row.addView(mp); row.addView(txt("min", 15f, T.sub)); row.addView(sp); row.addView(txt("s", 15f, T.sub))
            addView(row, lp(MATCH, WRAP, 0f, 0, dp(8), 0, dp(16)))
            val chips = LinearLayout(this@ClockActivity)
            chips.gravity = Gravity.CENTER
            for (m in listOf(1, 3, 5, 10, 15, 30)) {
                val c = txt("${m}m", 15f, T.blue, true)
                c.setPadding(dp(14), dp(8), dp(14), dp(8))
                c.background = shape(T.fill, dpf(18f))
                c.onTap { hp.value = 0; mp.value = m; sp.value = 0 }
                chips.addView(c, lp(WRAP, WRAP, 0f, dp(4), 0, dp(4), 0))
            }
            addView(chips, lp(MATCH, WRAP, 0f, 0, 0, 0, dp(24)))
            val start = txt("Start", 17f, Color.WHITE, true)
            start.gravity = Gravity.CENTER
            addView(circleBtn(T.green, 84, start) {
                val total = (hp.value * 3600L + mp.value * 60L + sp.value) * 1000
                if (total > 0) {
                    val end = System.currentTimeMillis() + total
                    prefs.put("timer_end", end.toString()); prefs.put("timer_total", total.toString())
                    Alarms.setAt(this@ClockActivity, 7777, end, "Timer", "timer")
                    render()
                } else toast("Set a duration")
            }, lp(dp(84), dp(84)))
        }
    }

    private fun update() {
        val now = System.currentTimeMillis()
        for ((tz, tv) in zoneViews) tv.text = SimpleDateFormat(if (DateFormat.is24HourFormat(this)) "HH:mm" else "h:mm a", Locale.getDefault()).apply { timeZone = tz }.format(Date(now))
        swText?.text = fmtSw(swElapsed())
        val tt = tmText
        if (tt != null) {
            val rem = timerEnd() - now
            if (rem <= 0) { render(); return }
            val s = (rem + 999) / 1000
            tt.text = if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) else String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
            val tot = timerTotal()
            tmRing?.frac = if (tot > 0) rem.toFloat() / tot else 0f
            tmRing?.invalidate()
        }
    }
}
