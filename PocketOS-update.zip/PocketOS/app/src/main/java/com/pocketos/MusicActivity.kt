package com.pocketos

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class Song(val id: Long, val title: String, val artist: String, val album: String, val dur: Long) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
}

object Player {
    var queue: List<Song> = emptyList()
    var idx = -1
    var mp: MediaPlayer? = null
    var shuffle = false
    var repeat = 0
    var onChange: (() -> Unit)? = null
    val cur: Song? get() = queue.getOrNull(idx)
    val playing: Boolean get() = try { mp?.isPlaying == true } catch (e: Exception) { false }

    fun play(ctx: Context, list: List<Song>, i: Int) {
        queue = list; idx = i; start(ctx.applicationContext)
        val it = Intent(ctx, PlaybackService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(it) else ctx.startService(it)
    }

    private fun start(ctx: Context) {
        val s = cur ?: return
        try { mp?.release() } catch (e: Exception) { }
        mp = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            setDataSource(ctx, s.uri); prepare(); start()
            setOnCompletionListener { next(ctx, true) }
        }
        onChange?.invoke()
    }

    fun toggle() { val m = mp ?: return; if (m.isPlaying) m.pause() else m.start(); onChange?.invoke() }

    fun next(ctx: Context, auto: Boolean = false) {
        if (queue.isEmpty()) return
        if (auto && repeat == 2) { start(ctx); return }
        idx = if (shuffle) (Math.random() * queue.size).toInt() else idx + 1
        if (idx >= queue.size) { if (repeat == 1 || !auto) idx = 0 else { idx = queue.size - 1; mp?.pause(); onChange?.invoke(); return } }
        start(ctx)
    }

    fun prev(ctx: Context) {
        if (queue.isEmpty()) return
        val m = mp
        if (m != null && m.currentPosition > 3000) { m.seekTo(0); return }
        idx = if (idx - 1 < 0) queue.size - 1 else idx - 1
        start(ctx)
    }
}

class PlaybackService : Service() {
    private var session: MediaSession? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        when (i?.action) { "toggle" -> Player.toggle(); "next" -> Player.next(this); "prev" -> Player.prev(this) }
        if (session == null) {
            session = MediaSession(this, "PocketOS").apply {
                setCallback(object : MediaSession.Callback() {
                    override fun onPlay() { Player.toggle() }
                    override fun onPause() { Player.toggle() }
                    override fun onSkipToNext() { Player.next(this@PlaybackService) }
                    override fun onSkipToPrevious() { Player.prev(this@PlaybackService) }
                })
                isActive = true
            }
            Player.onChange = { update() }
        }
        update()
        return START_STICKY
    }

    private fun act(a: String, code: Int) = PendingIntent.getService(this, code, Intent(this, PlaybackService::class.java).setAction(a), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun update() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("music", "Music", NotificationManager.IMPORTANCE_LOW))
        val song = Player.cur
        session?.setPlaybackState(PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS)
            .setState(if (Player.playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, Player.mp?.currentPosition?.toLong() ?: 0L, 1f).build())
        val open = PendingIntent.getActivity(this, 0, Intent(this, MusicActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "music").setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(song?.title ?: "Music").setContentText(song?.artist ?: "")
            .setContentIntent(open).setOngoing(Player.playing)
            .addAction(android.R.drawable.ic_media_previous, "Previous", act("prev", 1))
            .addAction(if (Player.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause", act("toggle", 2))
            .addAction(android.R.drawable.ic_media_next, "Next", act("next", 3))
            .setStyle(Notification.MediaStyle().setMediaSession(session?.sessionToken).setShowActionsInCompactView(0, 1, 2)).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(77, n)
    }

    override fun onDestroy() { session?.release(); Player.onChange = null; super.onDestroy() }
}

class MusicActivity : Base() {
    private var songs: List<Song> = emptyList()
    private lateinit var shell: Shell
    private var tab = 0
    private var query = ""
    private var nowView: View? = null
    private val h = Handler(Looper.getMainLooper())
    private var seek: SeekBar? = null
    private var curTime: TextView? = null
    private val tick = object : Runnable {
        override fun run() { val m = Player.mp; val s = seek; if (m != null && s != null) { try { s.progress = m.currentPosition; curTime?.text = fmt(m.currentPosition.toLong()) } catch (e: Exception) { } }; h.postDelayed(this, 500) }
    }

    private fun fmt(ms: Long) = String.format("%d:%02d", ms / 60000, (ms / 1000) % 60)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        shell = Shell(this)
        shell.tabs(listOf("music" to "Songs", "folder" to "Albums", "person" to "Artists"), 0) { tab = it; render() }
        setContentView(shell.root)
        val perm = if (Build.VERSION.SDK_INT >= 33) "android.permission.READ_MEDIA_AUDIO" else "android.permission.READ_EXTERNAL_STORAGE"
        ask(listOf(perm)) { load(); render() }
    }

    override fun onResume() { super.onResume(); h.post(tick); Player.onChange = { runOnUiThread { render() } } }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (nowView != null) closeNow() else super.onBackPressed() }

    private fun load() {
        val out = ArrayList<Song>()
        try {
            contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION),
                MediaStore.Audio.Media.IS_MUSIC + "!=0", null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")?.use { c ->
                while (c.moveToNext()) out.add(Song(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "Unknown Artist", c.getString(3) ?: "", c.getLong(4)))
            }
        } catch (e: Exception) { }
        songs = out
    }

    private fun art(s: Song, size: Int): Bitmap? = try { if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(s.uri, Size(size, size), null) else null } catch (e: Exception) { null }

    private fun songRow(s: Song, list: List<Song>, i: Int): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(12), dp(8), dp(12), dp(8))
        val iv = ImageView(this); iv.scaleType = ImageView.ScaleType.CENTER_CROP; iv.background = shape(T.fill, dpf(6f)); iv.clipToOutline = true
        Thread { val b = art(s, 120); if (b != null) runOnUiThread { iv.setImageBitmap(b) } }.start()
        r.addView(iv, lp(dp(44), dp(44), 0f, 0, 0, dp(12), 0))
        val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL
        c.addView(txt(s.title, 16f, if (Player.cur?.id == s.id) T.red else T.label).apply { maxLines = 1 })
        c.addView(txt(s.artist, 13f, T.sub).apply { maxLines = 1 })
        r.addView(c, lp(0, WRAP, 1f))
        r.onTap { Player.play(this, list, i) }
        return r
    }

    private fun render() {
        val v = page {
            addView(largeTitle(listOf("Songs", "Albums", "Artists")[tab]))
            if (tab == 0) {
                val bar = LinearLayout(this@MusicActivity)
                bar.addView(btn("▶ Play", Color.WHITE, true) { if (songs.isNotEmpty()) Player.play(this@MusicActivity, songs, 0) }.apply { gravity = Gravity.CENTER; background = shape(T.red, dpf(12f)) }, lp(0, WRAP, 1f, 0, 0, dp(6), 0))
                bar.addView(btn("⤮ Shuffle", Color.WHITE, true) { if (songs.isNotEmpty()) { Player.shuffle = true; Player.play(this@MusicActivity, songs, (Math.random() * songs.size).toInt()) } }.apply { gravity = Gravity.CENTER; background = shape(T.red, dpf(12f)) }, lp(0, WRAP, 1f, dp(6), 0, 0, 0))
                addView(bar, lp(MATCH, WRAP, 0f, 0, 0, 0, dp(8)))
                addView(searchBar("Search") { q -> query = q; render() }, lp(MATCH, dp(44), 0f, 0, 0, 0, dp(8)))
                val list = songs.filter { query.isEmpty() || it.title.contains(query, true) || it.artist.contains(query, true) }
                val g = Group(this@MusicActivity)
                list.forEachIndexed { i, s -> g.add(songRow(s, list, i), 68) }
                if (songs.isEmpty()) addView(txt("No music found", 15f, T.sub)) else addView(g)
            } else {
                val groups = songs.groupBy { if (tab == 1) it.album else it.artist }
                val g = Group(this@MusicActivity)
                for ((n, l) in groups) g.row(n.ifEmpty { "Unknown" }, l.size.toString() + " songs", null, true) { Player.play(this@MusicActivity, l, 0) }
                addView(g)
            }
            if (Player.cur != null) addView(View(this@MusicActivity), lp(MATCH, dp(70)))
        }
        shell.show(v)
        val s = Player.cur
        if (s != null && nowView == null) {
            val mini = LinearLayout(this)
            mini.gravity = Gravity.CENTER_VERTICAL
            mini.background = shape(T.glass, dpf(24f)); mini.elevation = dpf(6f)
            mini.setPadding(dp(16), dp(6), dp(8), dp(6))
            mini.addView(txt(s.title, 15f, T.label, true).apply { maxLines = 1 }, lp(0, WRAP, 1f))
            mini.addView(glyphBtn(if (Player.playing) "pause" else "play", T.label) { Player.toggle() })
            mini.addView(glyphBtn("next", T.label) { Player.next(this) })
            mini.onTap { openNow() }
            shell.holder.addView(mini, FrameLayout.LayoutParams(MATCH, dp(52), Gravity.BOTTOM).apply { setMargins(dp(16), 0, dp(16), dp(98)) })
        }
    }

    private fun closeNow() { nowView?.let { shell.root.removeView(it) }; nowView = null; seek = null; render() }

    private fun openNow() {
        val s = Player.cur ?: return
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setBackgroundColor(T.bg)
        root.setPadding(dp(28), dp(8), dp(28), dp(28))
        root.isClickable = true
        root.addView(navRow(null, glyphBtn("down", T.sub) { closeNow() }), lp(MATCH, WRAP))
        val iv = ImageView(this); iv.scaleType = ImageView.ScaleType.CENTER_CROP; iv.background = shape(T.fill, dpf(16f)); iv.clipToOutline = true
        iv.setImageBitmap(art(s, 600))
        val side = resources.displayMetrics.widthPixels - dp(56)
        root.addView(iv, lp(side, side, 0f, 0, dp(16), 0, dp(24)))
        root.addView(txt(s.title, 24f, T.label, true).apply { gravity = Gravity.CENTER; maxLines = 2 })
        root.addView(txt(s.artist, 18f, T.red).apply { gravity = Gravity.CENTER })
        val sb = SeekBar(this); sb.max = s.dur.toInt(); seek = sb
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(x: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) Player.mp?.seekTo(p) }
            override fun onStartTrackingTouch(x: SeekBar) {}
            override fun onStopTrackingTouch(x: SeekBar) {}
        })
        root.addView(sb, lp(MATCH, WRAP, 0f, 0, dp(20), 0, 0))
        val times = LinearLayout(this)
        curTime = txt("0:00", 12f, T.sub)
        times.addView(curTime, lp(0, WRAP, 1f)); times.addView(txt(fmt(s.dur), 12f, T.sub))
        root.addView(times, lp(MATCH, WRAP))
        val ctl = LinearLayout(this)
        ctl.gravity = Gravity.CENTER
        ctl.addView(glyphBtn("prev", T.label) { Player.prev(this) }, lp(dp(64), dp(64)))
        ctl.addView(glyphBtn(if (Player.playing) "pause" else "play", T.label) { Player.toggle(); closeNow(); openNow() }, lp(dp(80), dp(80)))
        ctl.addView(glyphBtn("next", T.label) { Player.next(this) }, lp(dp(64), dp(64)))
        root.addView(ctl, lp(MATCH, WRAP, 0f, 0, dp(12), 0, 0))
        val opts = LinearLayout(this)
        opts.gravity = Gravity.CENTER
        opts.addView(glyphBtn("shuffle", if (Player.shuffle) T.red else T.sub) { Player.shuffle = !Player.shuffle; closeNow(); openNow() }, lp(0, WRAP, 1f))
        opts.addView(glyphBtn("repeat", if (Player.repeat > 0) T.red else T.sub) { Player.repeat = (Player.repeat + 1) % 3; toast(listOf("Repeat off", "Repeat all", "Repeat one")[Player.repeat]); closeNow(); openNow() }, lp(0, WRAP, 1f))
        root.addView(opts)
        nowView = root
        shell.root.addView(root, FrameLayout.LayoutParams(MATCH, MATCH))
    }
}
