package com.pocketos

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.MathContext

class Calc(val s: String, val deg: Boolean) {
    var i = 0
    fun parse(): Double { val v = expr(); if (i != s.length) throw IllegalArgumentException(); return v }
    private fun peek(): Char = if (i < s.length) s[i] else '\u0000'
    private fun az(c: Char) = c in 'a'..'z'
    private fun expr(): Double {
        var v = term()
        while (peek() == '+' || peek() == '-') { val o = s[i++]; val t = term(); v = if (o == '+') v + t else v - t }
        return v
    }
    private fun term(): Double {
        var v = pow()
        while (true) {
            val c = peek()
            if (c == '×' || c == '÷') { i++; val t = pow(); v = if (c == '×') v * t else v / t }
            else if (c == '(' || c == 'π' || c == '√' || az(c)) v *= pow()
            else break
        }
        return v
    }
    private fun pow(): Double { val b = unary(); if (peek() == '^') { i++; return Math.pow(b, pow()) }; return b }
    private fun unary(): Double {
        if (peek() == '-') { i++; return -unary() }
        if (peek() == '+') { i++; return unary() }
        return post()
    }
    private fun post(): Double {
        var v = prim()
        while (true) {
            val c = peek()
            if (c == '!') { i++; v = fact(v) } else if (c == '%') { i++; v /= 100 } else break
        }
        return v
    }
    private fun fact(v: Double): Double {
        if (v < 0 || v != Math.floor(v) || v > 170) throw ArithmeticException()
        var r = 1.0
        for (k in 2..v.toInt()) r *= k
        return r
    }
    private fun prim(): Double {
        val c = peek()
        if (c.isDigit() || c == '.') { val st = i; while (peek().isDigit() || peek() == '.') i++; return s.substring(st, i).toDouble() }
        if (c == '(') { i++; val v = expr(); if (peek() == ')') i++; return v }
        if (c == 'π') { i++; return Math.PI }
        if (c == '√') { i++; return Math.sqrt(unary()) }
        if (az(c)) {
            val st = i
            while (az(peek())) i++
            val n = s.substring(st, i)
            if (n == "e") return Math.E
            if (peek() != '(') throw IllegalArgumentException()
            i++
            val a = expr()
            if (peek() == ')') i++
            return fn(n, a)
        }
        throw IllegalArgumentException()
    }
    private fun rad(a: Double) = if (deg) Math.toRadians(a) else a
    private fun back(a: Double) = if (deg) Math.toDegrees(a) else a
    private fun fn(n: String, a: Double): Double = when (n) {
        "sin" -> Math.sin(rad(a)); "cos" -> Math.cos(rad(a)); "tan" -> Math.tan(rad(a))
        "asin" -> back(Math.asin(a)); "acos" -> back(Math.acos(a)); "atan" -> back(Math.atan(a))
        "ln" -> Math.log(a); "log" -> Math.log10(a); "sqrt" -> Math.sqrt(a); "abs" -> Math.abs(a)
        else -> throw IllegalArgumentException()
    }
}

fun fmtNum(v: Double): String {
    if (v.isNaN() || v.isInfinite()) return "Error"
    if (Math.abs(v) < 1e-12) return "0"
    val bd = BigDecimal(v).round(MathContext(10)).stripTrailingZeros()
    val plain = if (bd.scale() < -9 || bd.precision() - bd.scale() > 15) bd.toString() else bd.toPlainString()
    return groupNum(plain)
}

fun groupNum(p: String): String {
    val neg = p.startsWith("-")
    val s0 = p.removePrefix("-")
    val dot = s0.indexOf('.')
    val ip = if (dot < 0) s0 else s0.substring(0, dot)
    val fp = if (dot < 0) "" else s0.substring(dot)
    if (ip.isEmpty() || !ip.all { it.isDigit() }) return p
    val sb = StringBuilder()
    ip.reversed().forEachIndexed { k, ch -> if (k > 0 && k % 3 == 0) sb.append(','); sb.append(ch) }
    return (if (neg) "-" else "") + sb.reverse().toString() + fp
}

class CalculatorActivity : Base() {
    private var expr = ""
    private var deg = true
    private lateinit var disp: TextView
    private lateinit var prev: TextView
    private lateinit var prefs: Prefs
    private val ops = "+-×÷"
    private val GRAY = 0xFFA5A5A5.toInt()
    private val DIG = 0xFF333333.toInt()
    private val ORG = 0xFFFF9F0A.toInt()
    private val SCI = 0xFF1F1F1F.toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.setBackgroundColor(Color.BLACK)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        ui()
    }

    override fun onConfigurationChanged(n: Configuration) { super.onConfigurationChanged(n); ui() }

    private fun ui() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(dp(12), dp(8), dp(12), dp(14))
        root.addView(navRow(null, glyphBtn("clock", 0xFF8E8E93.toInt()) { history() }))
        disp = txt("0", 70f, Color.WHITE)
        disp.gravity = Gravity.END or Gravity.BOTTOM
        disp.maxLines = 1
        disp.setAutoSizeTextTypeUniformWithConfiguration(30, if (land) 48 else 80, 2, TypedValue.COMPLEX_UNIT_SP)
        var downX = 0f
        disp.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_DOWN) downX = ev.x
            if (ev.action == MotionEvent.ACTION_UP && Math.abs(ev.x - downX) > dp(60)) { expr = expr.dropLast(1); refresh() }
            false
        }
        disp.setOnLongClickListener {
            val t = if (prev.text.isNotEmpty()) prev.text.toString() else disp.text.toString()
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("calc", t))
            toast("Copied"); true
        }
        prev = txt("", 26f, 0xFF8E8E93.toInt())
        prev.gravity = Gravity.END
        root.addView(disp, lp(MATCH, 0, 1f))
        root.addView(prev, lp(MATCH, WRAP, 0f, 0, 0, dp(8), dp(8)))

        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        val rows = listOf(
            listOf(if (expr.isEmpty()) "AC" else "⌫", "±", "%", "÷"), listOf("7", "8", "9", "×"), listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"), listOf("0", ".", "=")
        )
        val w = resources.displayMetrics.widthPixels - dp(24)
        val size = if (land) 0 else (w - dp(30)) / 4
        for (r in rows) {
            val row = LinearLayout(this)
            for (k in r) row.addView(key(k, if (k == "0") 2 else 1, land), if (land) lp(0, MATCH, if (k == "0") 2f else 1f, dp(3), dp(3), dp(3), dp(3))
                else lp(0, size, if (k == "0") 2f else 1f, dp(5), dp(5), dp(5), dp(5)))
            main.addView(row, if (land) lp(MATCH, 0, 1f) else lp(MATCH, WRAP))
        }
        if (land) {
            val body = LinearLayout(this)
            val sci = LinearLayout(this)
            sci.orientation = LinearLayout.VERTICAL
            val srows = listOf(listOf("(", ")", "x²", "x³"), listOf("xʸ", "√", "1/x", "x!"), listOf("sin", "cos", "tan", if (deg) "Rad" else "Deg"), listOf("ln", "log", "e", "π"))
            for (r in srows) {
                val row = LinearLayout(this)
                for (k in r) row.addView(key(k, 1, true), lp(0, MATCH, 1f, dp(3), dp(3), dp(3), dp(3)))
                sci.addView(row, lp(MATCH, 0, 1f))
            }
            body.addView(sci, lp(0, MATCH, 1f))
            body.addView(main, lp(0, MATCH, 1.2f, dp(8), 0, 0, 0))
            root.addView(body, lp(MATCH, 0, 1.6f))
        } else root.addView(main)
        setContentView(root)
        refresh()
    }

    private fun key(k: String, span: Int, land: Boolean): TextView {
        val bg = when (k) {
            "÷", "×", "-", "+", "=" -> ORG
            "AC", "⌫", "±", "%" -> GRAY
            "(", ")", "x²", "x³", "xʸ", "√", "1/x", "x!", "sin", "cos", "tan", "Rad", "Deg", "ln", "log", "e", "π" -> SCI
            else -> DIG
        }
        val t = txt(k, if (land) 20f else 32f, if (bg == GRAY) Color.BLACK else Color.WHITE)
        t.gravity = if (span == 2 && !land) Gravity.CENTER_VERTICAL or Gravity.START else Gravity.CENTER
        if (span == 2 && !land) t.setPadding(dp(32), 0, 0, 0)
        t.background = GradientDrawable().apply { setColor(bg); cornerRadius = 1000f }
        t.setOnClickListener { it.tap(); press(k) }
        return t
    }

    private fun press(k: String) {
        if (expr == "Error") expr = ""
        val before = expr.isEmpty()
        when (k) {
            "AC" -> expr = ""
            "⌫" -> expr = expr.dropLast(1)
            "±" -> expr = if (expr.startsWith("-")) expr.drop(1) else if (expr.isNotEmpty()) "-$expr" else expr
            "=" -> { eq(); return }
            "Rad", "Deg" -> { deg = !deg; ui(); return }
            "x²" -> expr += "^2"
            "x³" -> expr += "^3"
            "xʸ" -> expr += "^"
            "√" -> expr += "√("
            "1/x" -> if (expr.isNotEmpty()) expr = "1÷($expr)"
            "x!" -> expr += "!"
            "sin", "cos", "tan", "ln", "log" -> expr += "$k("
            else -> {
                if (k.length == 1 && ops.contains(k)) {
                    if (expr.isEmpty() && k != "-") return
                    val last = expr.lastOrNull()
                    if (last != null && ops.contains(last)) expr = expr.dropLast(1)
                }
                expr += k
            }
        }
        if (before != expr.isEmpty()) ui() else refresh()
    }

    private fun refresh() {
        disp.text = if (expr.isEmpty()) "0" else expr
        prev.text = ""
        if (expr.isNotEmpty() && expr != "Error") {
            try {
                val f = fmtNum(Calc(expr, deg).parse())
                if (f != "Error" && f != groupNum(expr)) prev.text = f
            } catch (e: Exception) { }
        }
    }

    private fun eq() {
        if (expr.isEmpty()) return
        try {
            val f = fmtNum(Calc(expr, deg).parse())
            if (f == "Error") throw ArithmeticException()
            val h = prefs.s("calc_hist").split("\n").filter { it.isNotEmpty() }.toMutableList()
            h.add(0, "$expr = $f")
            prefs.put("calc_hist", h.take(40).joinToString("\n"))
            expr = f.replace(",", "")
            ui()
        } catch (e: Exception) { expr = "Error"; refresh(); prev.text = "" }
    }

    private fun history() {
        val h = prefs.s("calc_hist").split("\n").filter { it.isNotEmpty() }
        if (h.isEmpty()) { toast("No history yet"); return }
        AlertDialog.Builder(this).setTitle("History").setItems(h.toTypedArray()) { _, i ->
            expr = h[i].substringAfterLast(" = ").replace(",", ""); ui()
        }.setNeutralButton("Clear") { _, _ -> prefs.put("calc_hist", "") }.show()
    }
}
