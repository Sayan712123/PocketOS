package com.pocketos

import android.Manifest
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class DialView(c: Context) : View(c) {
    var heading = 0f
    var pitch = 0f
    var roll = 0f
    var level = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = Math.min(width, height) * 0.42f
        p.textAlign = Paint.Align.CENTER
        if (level) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = 0xFF636366.toInt(); cv.drawCircle(cx, cy, r, p)
            cv.drawLine(cx - r, cy, cx + r, cy, p); cv.drawLine(cx, cy - r, cx, cy + r, p)
            val bx = cx + (roll / 45f).coerceIn(-1f, 1f) * r * 0.8f; val by = cy - (pitch / 45f).coerceIn(-1f, 1f) * r * 0.8f
            p.style = Paint.Style.FILL; val flat = Math.abs(roll) < 1.5f && Math.abs(pitch) < 1.5f
            p.color = if (flat) 0xFF30D158.toInt() else 0xFFFFD60A.toInt(); cv.drawCircle(bx, by, r * 0.12f, p)
            return
        }
        cv.save()
        cv.rotate(-heading, cx, cy)
        p.style = Paint.Style.STROKE
        for (d in 0 until 360 step 5) {
            val major = d % 30 == 0
            p.strokeWidth = if (major) 4f else 2f
            p.color = if (d == 0) 0xFFFF3B30.toInt() else if (major) Color.WHITE else 0xFF8E8E93.toInt()
            cv.save(); cv.rotate(d.toFloat(), cx, cy)
            cv.drawLine(cx, cy - r, cx, cy - r + (if (major) r * 0.1f else r * 0.05f), p)
            cv.restore()
        }
        p.style = Paint.Style.FILL; p.textSize = r * 0.14f
        for ((d, s) in listOf(0 to "N", 90 to "E", 180 to "S", 270 to "W")) {
            cv.save(); cv.rotate(d.toFloat(), cx, cy)
            p.color = if (d == 0) 0xFFFF3B30.toInt() else Color.WHITE
            cv.drawText(s, cx, cy - r * 0.72f, p)
            cv.restore()
        }
        for (d in 30 until 360 step 30) if (d % 90 != 0) {
            cv.save(); cv.rotate(d.toFloat(), cx, cy); p.color = 0xFF8E8E93.toInt(); p.textSize = r * 0.08f
            cv.drawText(d.toString(), cx, cy - r * 0.75f, p); cv.restore()
        }
        cv.restore()
        p.color = Color.WHITE
        val tri = android.graphics.Path(); tri.moveTo(cx, cy - r - 10f); tri.lineTo(cx - 14f, cy - r - 36f); tri.lineTo(cx + 14f, cy - r - 36f); tri.close()
        cv.drawPath(tri, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; cv.drawLine(cx - 20f, cy, cx + 20f, cy, p); cv.drawLine(cx, cy - 20f, cx, cy + 20f, p)
    }
}

class CompassActivity : Base(), SensorEventListener {
    private lateinit var dial: DialView
    private lateinit var head: TextView
    private lateinit var info: TextView
    private lateinit var sm: SensorManager
    private val rot = FloatArray(9)
    private val ori = FloatArray(3)
    private var smooth = 0f
    private var first = true
    private var level = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(dp(16), dp(24), dp(16), dp(24))
        val seg = Segmented(this, listOf("Compass", "Level"), 0) { level = it == 1; dial.level = level; update() }
        root.addView(seg, lp(MATCH, WRAP, 0f, dp(40), 0, dp(40), dp(8)))
        head = txt("0° N", 44f, Color.WHITE, true)
        head.gravity = Gravity.CENTER
        root.addView(head)
        dial = DialView(this)
        root.addView(dial, lp(MATCH, 0, 1f))
        info = txt("", 14f, 0xFF8E8E93.toInt())
        info.gravity = Gravity.CENTER
        root.addView(info)
        setContentView(root)
        ask(listOf(Manifest.permission.ACCESS_COARSE_LOCATION)) { loc() }
    }

    private fun loc() {
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val l = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
            if (l != null) info.text = String.format("%.4f°, %.4f°", l.latitude, l.longitude) + (if (l.hasAltitude()) "   ${Math.round(l.altitude)} m" else "")
        } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
            ?: toast("No compass sensor on this device")
    }
    override fun onPause() { sm.unregisterListener(this); super.onPause() }
    override fun onAccuracyChanged(s: Sensor?, a: Int) { if (a <= SensorManager.SENSOR_STATUS_ACCURACY_LOW && !level) toast("Calibrate: move phone in a figure 8") }

    private fun dir(d: Float): String = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")[((d + 22.5f) / 45f).toInt() % 8]

    override fun onSensorChanged(e: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rot, e.values)
        SensorManager.getOrientation(rot, ori)
        val az = ((Math.toDegrees(ori[0].toDouble()).toFloat()) + 360f) % 360f
        if (first) { smooth = az; first = false }
        var d = az - smooth
        if (d > 180) d -= 360; if (d < -180) d += 360
        smooth = (smooth + d * 0.15f + 360f) % 360f
        dial.heading = smooth
        dial.pitch = Math.toDegrees(ori[1].toDouble()).toFloat()
        dial.roll = Math.toDegrees(ori[2].toDouble()).toFloat()
        update()
    }

    private fun update() {
        head.text = if (level) String.format("%.0f°", Math.max(Math.abs(dial.pitch), Math.abs(dial.roll))) else "${Math.round(smooth) % 360}° ${dir(smooth)}"
        dial.invalidate()
    }
}
