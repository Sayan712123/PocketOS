package com.pocketos

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout

class VSlider(c: Context, val glyphName: String, var value: Float, val onChange: (Float) -> Unit) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val g = Glyphs.path(glyphName)
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = context.dpf(22f)
        p.color = 0x55FFFFFF; cv.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        cv.save(); cv.clipPath(android.graphics.Path().apply { addRoundRect(RectF(0f, 0f, w, h), r, r, android.graphics.Path.Direction.CW) })
        p.color = Color.WHITE; cv.drawRect(0f, h * (1 - value), w, h, p); cv.restore()
        cv.save(); val s = context.dpf(24f) / 24f; cv.translate(w / 2 - context.dpf(12f), h - context.dpf(40f)); cv.scale(s, s)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0xFF636366.toInt(); p.strokeCap = Paint.Cap.ROUND; cv.drawPath(g, p); p.style = Paint.Style.FILL; cv.restore()
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        value = (1f - e.y / height).coerceIn(0f, 1f); invalidate(); onChange(value); return true
    }
}

class ControlCenterActivity : Activity() {
    companion object { var torchOn = false }

    private fun tile(g: String, label: String, on: Boolean, f: (View) -> Unit): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.background = shape(if (on) 0xFF0A84FF.toInt() else 0x66FFFFFF, dpf(22f))
        c.addView(glyph(g, Color.WHITE, 26), lp(dp(26), dp(26)))
        c.addView(txt(label, 11f, Color.WHITE), lp(WRAP, WRAP, 0f, 0, dp(4), 0, 0))
        c.setOnClickListener { it.tap(); f(it) }
        return c
    }

    private fun go(a: String) { try { startActivity(Intent(a)) } catch (e: Exception) { toast("Not available") }; finish() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setBackgroundDrawable(ColorDrawable(0x88000000.toInt()))
        val root = FrameLayout(this)
        root.setOnClickListener { finish() }
        val sheet = LinearLayout(this)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.isClickable = true
        sheet.setPadding(dp(12), dp(12), dp(12), dp(12))
        sheet.background = shape(0xCC1C1C1E.toInt(), dpf(32f))

        val wifi = try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled } catch (e: Exception) { false }
        val bt = try { BluetoothAdapter.getDefaultAdapter()?.isEnabled == true } catch (e: Exception) { false }
        val air = Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        val r1 = LinearLayout(this)
        r1.addView(tile("flash", "Airplane", air) { go(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }, lp(0, dp(80), 1f, dp(4), dp(4), dp(4), dp(4)))
        r1.addView(tile("globe", "Wi-Fi", wifi) { go(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS) }, lp(0, dp(80), 1f, dp(4), dp(4), dp(4), dp(4)))
        r1.addView(tile("share", "Bluetooth", bt) { go(Settings.ACTION_BLUETOOTH_SETTINGS) }, lp(0, dp(80), 1f, dp(4), dp(4), dp(4), dp(4)))
        sheet.addView(r1)

        val mid = LinearLayout(this)
        val np = LinearLayout(this)
        np.orientation = LinearLayout.VERTICAL
        np.gravity = Gravity.CENTER
        np.background = shape(0x66FFFFFF, dpf(22f))
        np.setPadding(dp(8), dp(8), dp(8), dp(8))
        np.addView(txt(Player.cur?.title ?: "Not Playing", 14f, Color.WHITE, true).apply { maxLines = 1; gravity = Gravity.CENTER })
        val ctl = LinearLayout(this); ctl.gravity = Gravity.CENTER
        ctl.addView(glyphBtn("prev", Color.WHITE) { Player.prev(this) })
        ctl.addView(glyphBtn(if (Player.playing) "pause" else "play", Color.WHITE) { Player.toggle(); finish() })
        ctl.addView(glyphBtn("next", Color.WHITE) { Player.next(this) })
        np.addView(ctl)
        mid.addView(np, lp(0, dp(150), 2f, dp(4), dp(4), dp(4), dp(4)))
        val am = getSystemService(AudioManager::class.java)
        val br = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f } catch (e: Exception) { 0.5f }
        mid.addView(VSlider(this, "info", br) { v ->
            if (Settings.System.canWrite(this)) {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, Math.max((v * 255).toInt(), 5))
            } else { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))); finish() }
        }, lp(0, dp(150), 1f, dp(4), dp(4), dp(4), dp(4)))
        val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        mid.addView(VSlider(this, "music", am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / mx) { v -> am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * mx), 0) }, lp(0, dp(150), 1f, dp(4), dp(4), dp(4), dp(4)))
        sheet.addView(mid)

        val r3 = LinearLayout(this)
        r3.addView(tile("flash", "Flashlight", torchOn) { v -> toggleTorch(v) }, lp(0, dp(80), 1f, dp(4), dp(4), dp(4), dp(4)))
        r3.addView(tile("timer", "Timer", false) { openApp(ClockActivity::class.java); finish() }, lp(0, dp(80), 1f, dp(4), dp(4), dp(4), dp(4)))
        r3.addView(tile("grid", "Calculator", false) { openApp(CalculatorActivity::class.java); finish() }, lp(0, dp(80), 1f, dp(4), dp(4), dp(4), dp(4)))
        r3.addView(tile("photo", "Camera", false) { openApp(CameraActivity::class.java); finish() }, lp(0, dp(80), 1f, dp(4), dp(4), dp(4), dp(4)))
        sheet.addView(r3)
        root.addView(sheet, FrameLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(12), dp(36), dp(12), 0) })
        setContentView(root)
    }

    private fun toggleTorch(v: View) {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            v.background = shape(if (torchOn) 0xFF0A84FF.toInt() else 0x66FFFFFF, dpf(22f))
        } catch (e: Exception) { toast("Flashlight unavailable") }
    }
}
