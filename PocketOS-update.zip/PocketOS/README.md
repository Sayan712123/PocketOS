# PocketOS (update)

One lightweight APK, Kotlin + plain Android Views, minSdk 26 (Android 8+), tuned for POCO M4 5G.
Design: iOS 26 style (inset grouped lists, large titles, floating glass tab bar, round keys, action sheets, dark mode).
No Apple assets or fonts are used; icons are the original chart designs.

## Build on GitHub
1. Replace the old repo files with this folder (keep `.github/`).
2. Actions -> Build APK -> download artifact `PocketOS-apk`, install `app-release.apk`.
3. If the build fails, send the red error lines.

## Apps
Phone (Google layout, iPhone-style keys, call log, favorites, T9 search) · Messages (iOS bubbles, default-SMS support, no MMS)
· Contacts (A-Z index, add/edit/delete, favorites) · Camera (CameraX photo/video, flash, timer, grid, pinch zoom, tap focus)
· Photos (library, albums, pinch/double-tap zoom, share, delete) · Calendar (month view, events, add/delete)
· Clock (world clock, real alarms with snooze, stopwatch with laps, timer) · Weather (Open-Meteo: hourly, 7-day, details, °C/°F, city search)
· Notes (folders, pin, checklists, search, recently deleted) · Music (library, mini player, now playing, background playback, lock-screen controls)
· Recorder (waveform, pause/resume, rename, share) · Compass + Level · Browser (tabs, bookmarks, history, desktop site, find, downloads)
· Calculator (iOS layout, scientific in landscape, history, live preview) · Files (file-type icons, thumbnails, copy/move/zip/extract/share)
· Launcher (pages, dock, Spotlight search, Control Center, Recents) · Hub (icon packs, Web Apps, settings)

## Gestures in PocketOS Launcher
- Swipe down on the upper-right: Control Center. Upper-left: Spotlight search. Swipe up from the bottom: Recents.

## Known limits (honest)
- Not compiled/tested by the author on a device; first build may need small fixes.
- Recents shows recently used apps (needs Usage access), not live window snapshots, and cannot replace the system Recents button/gesture.
- Phone has no in-call screen (system one is used). Messages: no MMS. Camera: no HDR/portrait.
- Wi-Fi/Bluetooth toggles open the system panel (Android forbids direct toggling).
- Web Apps share one cookie jar.

See `ANTIGRAVITY_PROMPT.md` to remove default apps safely.
